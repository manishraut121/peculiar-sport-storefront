--
-- PostgreSQL database dump
--

\restrict NUnk8fbzesly8BsJmAuF97TbMc8WRScrYhWwXv4eFLzfsmSubEiYPXpFHoaBYyJ

-- Dumped from database version 16.14 (Homebrew)
-- Dumped by pg_dump version 16.14 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: claim_reason_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.claim_reason_enum AS ENUM (
    'missing_item',
    'wrong_item',
    'production_failure',
    'other'
);


--
-- Name: order_claim_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_claim_type_enum AS ENUM (
    'refund',
    'replace'
);


--
-- Name: order_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_status_enum AS ENUM (
    'pending',
    'completed',
    'draft',
    'archived',
    'canceled',
    'requires_action'
);


--
-- Name: return_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.return_status_enum AS ENUM (
    'open',
    'requested',
    'received',
    'partially_received',
    'canceled'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_holder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_holder (
    id text NOT NULL,
    provider_id text NOT NULL,
    external_id text NOT NULL,
    email text,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    token text NOT NULL,
    salt text NOT NULL,
    redacted text NOT NULL,
    title text NOT NULL,
    type text NOT NULL,
    last_used_at timestamp with time zone,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT api_key_type_check CHECK ((type = ANY (ARRAY['publishable'::text, 'secret'::text])))
);


--
-- Name: application_method_buy_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_method_buy_rules (
    application_method_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


--
-- Name: application_method_target_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_method_target_rules (
    application_method_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


--
-- Name: auth_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_identity (
    id text NOT NULL,
    app_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: auth_mfa_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_mfa_factor (
    id text NOT NULL,
    auth_identity_id text NOT NULL,
    provider text NOT NULL,
    status text NOT NULL,
    provider_metadata jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: auth_mfa_recovery_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_mfa_recovery_code (
    id text NOT NULL,
    auth_identity_id text NOT NULL,
    code_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: auth_verification_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_verification_token (
    id text NOT NULL,
    auth_identity_id text NOT NULL,
    provider_identity_id text NOT NULL,
    entity_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: capture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capture (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    payment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text,
    metadata jsonb
);


--
-- Name: cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart (
    id text NOT NULL,
    region_id text,
    customer_id text,
    sales_channel_id text,
    email text,
    currency_code text NOT NULL,
    shipping_address_id text,
    billing_address_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    completed_at timestamp with time zone,
    locale text
);


--
-- Name: cart_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_address (
    id text NOT NULL,
    customer_id text,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cart_line_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_line_item (
    id text NOT NULL,
    cart_id text NOT NULL,
    title text NOT NULL,
    subtitle text,
    thumbnail text,
    quantity integer NOT NULL,
    variant_id text,
    product_id text,
    product_title text,
    product_description text,
    product_subtitle text,
    product_type text,
    product_collection text,
    product_handle text,
    variant_sku text,
    variant_barcode text,
    variant_title text,
    variant_option_values jsonb,
    requires_shipping boolean DEFAULT true NOT NULL,
    is_discountable boolean DEFAULT true NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb,
    unit_price numeric NOT NULL,
    raw_unit_price jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    product_type_id text,
    is_custom_price boolean DEFAULT false NOT NULL,
    is_giftcard boolean DEFAULT false NOT NULL,
    CONSTRAINT cart_line_item_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


--
-- Name: cart_line_item_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_line_item_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    item_id text,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    CONSTRAINT cart_line_item_adjustment_check CHECK ((amount >= (0)::numeric))
);


--
-- Name: cart_line_item_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_line_item_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate real NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    item_id text
);


--
-- Name: cart_payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_payment_collection (
    cart_id character varying(255) NOT NULL,
    payment_collection_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cart_promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_promotion (
    cart_id character varying(255) NOT NULL,
    promotion_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cart_shipping_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_shipping_method (
    id text NOT NULL,
    cart_id text NOT NULL,
    name text NOT NULL,
    description jsonb,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    shipping_option_id text,
    data jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT cart_shipping_method_check CHECK ((amount >= (0)::numeric))
);


--
-- Name: cart_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_shipping_method_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    shipping_method_id text
);


--
-- Name: cart_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_shipping_method_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate real NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    shipping_method_id text
);


--
-- Name: credit_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_line (
    id text NOT NULL,
    cart_id text NOT NULL,
    reference text,
    reference_id text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: currency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.currency (
    code text NOT NULL,
    symbol text NOT NULL,
    symbol_native text NOT NULL,
    decimal_digits integer DEFAULT 0 NOT NULL,
    rounding numeric DEFAULT 0 NOT NULL,
    raw_rounding jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer (
    id text NOT NULL,
    company_name text,
    first_name text,
    last_name text,
    email text,
    phone text,
    has_account boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text
);


--
-- Name: customer_account_holder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_account_holder (
    customer_id character varying(255) NOT NULL,
    account_holder_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: customer_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_address (
    id text NOT NULL,
    customer_id text NOT NULL,
    address_name text,
    is_default_shipping boolean DEFAULT false NOT NULL,
    is_default_billing boolean DEFAULT false NOT NULL,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: customer_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_group (
    id text NOT NULL,
    name text NOT NULL,
    metadata jsonb,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: customer_group_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_group_customer (
    id text NOT NULL,
    customer_id text NOT NULL,
    customer_group_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


--
-- Name: fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment (
    id text NOT NULL,
    location_id text NOT NULL,
    packed_at timestamp with time zone,
    shipped_at timestamp with time zone,
    delivered_at timestamp with time zone,
    canceled_at timestamp with time zone,
    data jsonb,
    provider_id text,
    shipping_option_id text,
    metadata jsonb,
    delivery_address_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    marked_shipped_by text,
    created_by text,
    requires_shipping boolean DEFAULT true NOT NULL
);


--
-- Name: fulfillment_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_address (
    id text NOT NULL,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: fulfillment_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_item (
    id text NOT NULL,
    title text NOT NULL,
    sku text NOT NULL,
    barcode text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    line_item_id text,
    inventory_item_id text,
    fulfillment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: fulfillment_label; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_label (
    id text NOT NULL,
    tracking_number text NOT NULL,
    tracking_url text NOT NULL,
    label_url text NOT NULL,
    fulfillment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: fulfillment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: fulfillment_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fulfillment_set (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: geo_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.geo_zone (
    id text NOT NULL,
    type text DEFAULT 'country'::text NOT NULL,
    country_code text NOT NULL,
    province_code text,
    city text,
    service_zone_id text NOT NULL,
    postal_expression jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT geo_zone_type_check CHECK ((type = ANY (ARRAY['country'::text, 'province'::text, 'city'::text, 'zip'::text])))
);


--
-- Name: image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image (
    id text NOT NULL,
    url text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    rank integer DEFAULT 0 NOT NULL,
    product_id text NOT NULL
);


--
-- Name: inventory_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_item (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    sku text,
    origin_country text,
    hs_code text,
    mid_code text,
    material text,
    weight integer,
    length integer,
    height integer,
    width integer,
    requires_shipping boolean DEFAULT true NOT NULL,
    description text,
    title text,
    thumbnail text,
    metadata jsonb
);


--
-- Name: inventory_level; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_level (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    inventory_item_id text NOT NULL,
    location_id text NOT NULL,
    stocked_quantity numeric DEFAULT 0 NOT NULL,
    reserved_quantity numeric DEFAULT 0 NOT NULL,
    incoming_quantity numeric DEFAULT 0 NOT NULL,
    metadata jsonb,
    raw_stocked_quantity jsonb,
    raw_reserved_quantity jsonb,
    raw_incoming_quantity jsonb
);


--
-- Name: invite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invite (
    id text NOT NULL,
    email text NOT NULL,
    accepted boolean DEFAULT false NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: invite_rbac_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invite_rbac_role (
    invite_id character varying(255) NOT NULL,
    rbac_role_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: link_module_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.link_module_migrations (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    link_descriptor jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.link_module_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.link_module_migrations_id_seq OWNED BY public.link_module_migrations.id;


--
-- Name: location_fulfillment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_fulfillment_provider (
    stock_location_id character varying(255) NOT NULL,
    fulfillment_provider_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: location_fulfillment_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_fulfillment_set (
    stock_location_id character varying(255) NOT NULL,
    fulfillment_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: mikro_orm_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mikro_orm_migrations (
    id integer NOT NULL,
    name character varying(255),
    executed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mikro_orm_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mikro_orm_migrations_id_seq OWNED BY public.mikro_orm_migrations.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification (
    id text NOT NULL,
    "to" text NOT NULL,
    channel text NOT NULL,
    template text,
    data jsonb,
    trigger_type text,
    resource_id text,
    resource_type text,
    receiver_id text,
    original_notification_id text,
    idempotency_key text,
    external_id text,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    "from" text,
    provider_data jsonb,
    CONSTRAINT notification_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'success'::text, 'failure'::text])))
);


--
-- Name: notification_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_provider (
    id text NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    channels text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."order" (
    id text NOT NULL,
    region_id text,
    display_id integer,
    customer_id text,
    version integer DEFAULT 1 NOT NULL,
    sales_channel_id text,
    status public.order_status_enum DEFAULT 'pending'::public.order_status_enum NOT NULL,
    is_draft_order boolean DEFAULT false NOT NULL,
    email text,
    currency_code text NOT NULL,
    shipping_address_id text,
    billing_address_id text,
    no_notification boolean,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone,
    custom_display_id text,
    locale text
);


--
-- Name: order_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_address (
    id text NOT NULL,
    customer_id text,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_cart (
    order_id character varying(255) NOT NULL,
    cart_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_change; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_change (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    description text,
    status text DEFAULT 'pending'::text NOT NULL,
    internal_note text,
    created_by text,
    requested_by text,
    requested_at timestamp with time zone,
    confirmed_by text,
    confirmed_at timestamp with time zone,
    declined_by text,
    declined_reason text,
    metadata jsonb,
    declined_at timestamp with time zone,
    canceled_by text,
    canceled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    change_type text,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text,
    carry_over_promotions boolean,
    CONSTRAINT order_change_status_check CHECK ((status = ANY (ARRAY['confirmed'::text, 'declined'::text, 'requested'::text, 'pending'::text, 'canceled'::text])))
);


--
-- Name: order_change_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_change_action (
    id text NOT NULL,
    order_id text,
    version integer,
    ordering bigint NOT NULL,
    order_change_id text,
    reference text,
    reference_id text,
    action text NOT NULL,
    details jsonb,
    amount numeric,
    raw_amount jsonb,
    internal_note text,
    applied boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_change_action_ordering_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_change_action_ordering_seq OWNED BY public.order_change_action.ordering;


--
-- Name: order_claim; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_claim (
    id text NOT NULL,
    order_id text NOT NULL,
    return_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    type public.order_claim_type_enum NOT NULL,
    no_notification boolean,
    refund_amount numeric,
    raw_refund_amount jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone,
    created_by text
);


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_claim_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_claim_display_id_seq OWNED BY public.order_claim.display_id;


--
-- Name: order_claim_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_claim_item (
    id text NOT NULL,
    claim_id text NOT NULL,
    item_id text NOT NULL,
    is_additional_item boolean DEFAULT false NOT NULL,
    reason public.claim_reason_enum,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_claim_item_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_claim_item_image (
    id text NOT NULL,
    claim_item_id text NOT NULL,
    url text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_credit_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_credit_line (
    id text NOT NULL,
    order_id text NOT NULL,
    reference text,
    reference_id text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL
);


--
-- Name: order_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_display_id_seq OWNED BY public."order".display_id;


--
-- Name: order_exchange; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_exchange (
    id text NOT NULL,
    order_id text NOT NULL,
    return_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    no_notification boolean,
    allow_backorder boolean DEFAULT false NOT NULL,
    difference_due numeric,
    raw_difference_due jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone,
    created_by text
);


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_exchange_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_exchange_display_id_seq OWNED BY public.order_exchange.display_id;


--
-- Name: order_exchange_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_exchange_item (
    id text NOT NULL,
    exchange_id text NOT NULL,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_fulfillment (
    order_id character varying(255) NOT NULL,
    fulfillment_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_item (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    fulfilled_quantity numeric NOT NULL,
    raw_fulfilled_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    shipped_quantity numeric NOT NULL,
    raw_shipped_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    return_requested_quantity numeric NOT NULL,
    raw_return_requested_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    return_received_quantity numeric NOT NULL,
    raw_return_received_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    return_dismissed_quantity numeric NOT NULL,
    raw_return_dismissed_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    written_off_quantity numeric NOT NULL,
    raw_written_off_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    delivered_quantity numeric DEFAULT 0 NOT NULL,
    raw_delivered_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    unit_price numeric,
    raw_unit_price jsonb,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb
);


--
-- Name: order_line_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_line_item (
    id text NOT NULL,
    totals_id text,
    title text NOT NULL,
    subtitle text,
    thumbnail text,
    variant_id text,
    product_id text,
    product_title text,
    product_description text,
    product_subtitle text,
    product_type text,
    product_collection text,
    product_handle text,
    variant_sku text,
    variant_barcode text,
    variant_title text,
    variant_option_values jsonb,
    requires_shipping boolean DEFAULT true NOT NULL,
    is_discountable boolean DEFAULT true NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb,
    unit_price numeric NOT NULL,
    raw_unit_price jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_custom_price boolean DEFAULT false NOT NULL,
    product_type_id text,
    is_giftcard boolean DEFAULT false NOT NULL
);


--
-- Name: order_line_item_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_line_item_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    item_id text NOT NULL,
    deleted_at timestamp with time zone,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


--
-- Name: order_line_item_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_line_item_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate numeric NOT NULL,
    raw_rate jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    item_id text NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_payment_collection (
    order_id character varying(255) NOT NULL,
    payment_collection_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_promotion (
    order_id character varying(255) NOT NULL,
    promotion_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_shipping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_shipping (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    shipping_method_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


--
-- Name: order_shipping_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_shipping_method (
    id text NOT NULL,
    name text NOT NULL,
    description jsonb,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    shipping_option_id text,
    data jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_custom_amount boolean DEFAULT false NOT NULL
);


--
-- Name: order_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_shipping_method_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shipping_method_id text NOT NULL,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL
);


--
-- Name: order_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_shipping_method_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate numeric NOT NULL,
    raw_rate jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shipping_method_id text NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_summary (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    totals jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: order_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_transaction (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    currency_code text NOT NULL,
    reference text,
    reference_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


--
-- Name: payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    currency_code text NOT NULL,
    provider_id text NOT NULL,
    data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    captured_at timestamp with time zone,
    canceled_at timestamp with time zone,
    payment_collection_id text NOT NULL,
    payment_session_id text NOT NULL,
    metadata jsonb
);


--
-- Name: payment_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_collection (
    id text NOT NULL,
    currency_code text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    authorized_amount numeric,
    raw_authorized_amount jsonb,
    captured_amount numeric,
    raw_captured_amount jsonb,
    refunded_amount numeric,
    raw_refunded_amount jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    completed_at timestamp with time zone,
    status text DEFAULT 'not_paid'::text NOT NULL,
    metadata jsonb,
    CONSTRAINT payment_collection_status_check CHECK ((status = ANY (ARRAY['not_paid'::text, 'awaiting'::text, 'authorized'::text, 'partially_authorized'::text, 'canceled'::text, 'failed'::text, 'partially_captured'::text, 'completed'::text])))
);


--
-- Name: payment_collection_payment_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_collection_payment_providers (
    payment_collection_id text NOT NULL,
    payment_provider_id text NOT NULL
);


--
-- Name: payment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: payment_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_session (
    id text NOT NULL,
    currency_code text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    context jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    authorized_at timestamp with time zone,
    payment_collection_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT payment_session_status_check CHECK ((status = ANY (ARRAY['authorized'::text, 'captured'::text, 'pending'::text, 'requires_more'::text, 'error'::text, 'canceled'::text])))
);


--
-- Name: price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price (
    id text NOT NULL,
    title text,
    price_set_id text NOT NULL,
    currency_code text NOT NULL,
    raw_amount jsonb NOT NULL,
    rules_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    price_list_id text,
    amount numeric NOT NULL,
    min_quantity numeric,
    max_quantity numeric,
    raw_min_quantity jsonb,
    raw_max_quantity jsonb
);


--
-- Name: price_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_list (
    id text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    rules_count integer DEFAULT 0,
    title text NOT NULL,
    description text NOT NULL,
    type text DEFAULT 'sale'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    metadata jsonb,
    CONSTRAINT price_list_status_check CHECK ((status = ANY (ARRAY['active'::text, 'draft'::text]))),
    CONSTRAINT price_list_type_check CHECK ((type = ANY (ARRAY['sale'::text, 'override'::text])))
);


--
-- Name: price_list_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_list_rule (
    id text NOT NULL,
    price_list_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    value jsonb,
    attribute text DEFAULT ''::text NOT NULL
);


--
-- Name: price_preference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_preference (
    id text NOT NULL,
    attribute text NOT NULL,
    value text,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: price_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_rule (
    id text NOT NULL,
    value text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    price_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    attribute text DEFAULT ''::text NOT NULL,
    operator text DEFAULT 'eq'::text NOT NULL,
    CONSTRAINT price_rule_operator_check CHECK ((operator = ANY (ARRAY['gte'::text, 'lte'::text, 'gt'::text, 'lt'::text, 'eq'::text])))
);


--
-- Name: price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_set (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product (
    id text NOT NULL,
    title text NOT NULL,
    handle text NOT NULL,
    subtitle text,
    description text,
    is_giftcard boolean DEFAULT false NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    thumbnail text,
    weight real,
    length real,
    height real,
    width real,
    origin_country text,
    hs_code text,
    mid_code text,
    material text,
    collection_id text,
    type_id text,
    discountable boolean DEFAULT true NOT NULL,
    external_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    metadata jsonb,
    CONSTRAINT product_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'proposed'::text, 'published'::text, 'rejected'::text])))
);


--
-- Name: product_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_category (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    handle text NOT NULL,
    mpath text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    parent_category_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    metadata jsonb,
    external_id text
);


--
-- Name: product_category_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_category_product (
    product_id text NOT NULL,
    product_category_id text NOT NULL
);


--
-- Name: product_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_collection (
    id text NOT NULL,
    title text NOT NULL,
    handle text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    external_id text
);


--
-- Name: product_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_option (
    id text NOT NULL,
    title text NOT NULL,
    product_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_option_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_option_value (
    id text NOT NULL,
    value text NOT NULL,
    option_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_sales_channel (
    product_id character varying(255) NOT NULL,
    sales_channel_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_shipping_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_shipping_profile (
    product_id character varying(255) NOT NULL,
    shipping_profile_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_tag (
    id text NOT NULL,
    value text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    external_id text
);


--
-- Name: product_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_tags (
    product_id text NOT NULL,
    product_tag_id text NOT NULL
);


--
-- Name: product_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_type (
    id text NOT NULL,
    value text NOT NULL,
    metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    external_id text
);


--
-- Name: product_variant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant (
    id text NOT NULL,
    title text NOT NULL,
    sku text,
    barcode text,
    ean text,
    upc text,
    allow_backorder boolean DEFAULT false NOT NULL,
    manage_inventory boolean DEFAULT true NOT NULL,
    hs_code text,
    origin_country text,
    mid_code text,
    material text,
    weight real,
    length real,
    height real,
    width real,
    metadata jsonb,
    variant_rank integer DEFAULT 0,
    product_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    thumbnail text
);


--
-- Name: product_variant_inventory_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_inventory_item (
    variant_id character varying(255) NOT NULL,
    inventory_item_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    required_quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_variant_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_option (
    variant_id text NOT NULL,
    option_value_id text NOT NULL
);


--
-- Name: product_variant_price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_price_set (
    variant_id character varying(255) NOT NULL,
    price_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: product_variant_product_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_product_image (
    id text NOT NULL,
    variant_id text NOT NULL,
    image_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: promotion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion (
    id text NOT NULL,
    code text NOT NULL,
    campaign_id text,
    is_automatic boolean DEFAULT false NOT NULL,
    type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    status text DEFAULT 'draft'::text NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    "limit" integer,
    used integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    CONSTRAINT promotion_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'active'::text, 'inactive'::text]))),
    CONSTRAINT promotion_type_check CHECK ((type = ANY (ARRAY['standard'::text, 'buyget'::text])))
);


--
-- Name: promotion_application_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_application_method (
    id text NOT NULL,
    value numeric,
    raw_value jsonb,
    max_quantity integer,
    apply_to_quantity integer,
    buy_rules_min_quantity integer,
    type text NOT NULL,
    target_type text NOT NULL,
    allocation text,
    promotion_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    currency_code text,
    CONSTRAINT promotion_application_method_allocation_check CHECK ((allocation = ANY (ARRAY['each'::text, 'across'::text, 'once'::text]))),
    CONSTRAINT promotion_application_method_target_type_check CHECK ((target_type = ANY (ARRAY['order'::text, 'shipping_methods'::text, 'items'::text]))),
    CONSTRAINT promotion_application_method_type_check CHECK ((type = ANY (ARRAY['fixed'::text, 'percentage'::text])))
);


--
-- Name: promotion_campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_campaign (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    campaign_identifier text NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: promotion_campaign_budget; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_campaign_budget (
    id text NOT NULL,
    type text NOT NULL,
    campaign_id text NOT NULL,
    "limit" numeric,
    raw_limit jsonb,
    used numeric DEFAULT 0 NOT NULL,
    raw_used jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    currency_code text,
    attribute text,
    CONSTRAINT promotion_campaign_budget_type_check CHECK ((type = ANY (ARRAY['spend'::text, 'usage'::text, 'use_by_attribute'::text, 'spend_by_attribute'::text])))
);


--
-- Name: promotion_campaign_budget_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_campaign_budget_usage (
    id text NOT NULL,
    attribute_value text NOT NULL,
    used numeric DEFAULT 0 NOT NULL,
    budget_id text NOT NULL,
    raw_used jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: promotion_promotion_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_promotion_rule (
    promotion_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


--
-- Name: promotion_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_rule (
    id text NOT NULL,
    description text,
    attribute text NOT NULL,
    operator text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT promotion_rule_operator_check CHECK ((operator = ANY (ARRAY['gte'::text, 'lte'::text, 'gt'::text, 'lt'::text, 'eq'::text, 'ne'::text, 'in'::text])))
);


--
-- Name: promotion_rule_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promotion_rule_value (
    id text NOT NULL,
    promotion_rule_id text NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: property_label; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_label (
    id text NOT NULL,
    entity text NOT NULL,
    property text NOT NULL,
    label text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: provider_identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_identity (
    id text NOT NULL,
    entity_id text NOT NULL,
    provider text NOT NULL,
    auth_identity_id text NOT NULL,
    user_metadata jsonb,
    provider_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: publishable_api_key_sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.publishable_api_key_sales_channel (
    publishable_key_id character varying(255) NOT NULL,
    sales_channel_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: refund; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    payment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text,
    metadata jsonb,
    refund_reason_id text,
    note text
);


--
-- Name: refund_reason; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_reason (
    id text NOT NULL,
    label text NOT NULL,
    description text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    code text NOT NULL
);


--
-- Name: region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.region (
    id text NOT NULL,
    name text NOT NULL,
    currency_code text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    automatic_taxes boolean DEFAULT true NOT NULL
);


--
-- Name: region_country; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.region_country (
    iso_2 text NOT NULL,
    iso_3 text NOT NULL,
    num_code text NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    region_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: region_payment_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.region_payment_provider (
    region_id character varying(255) NOT NULL,
    payment_provider_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: reservation_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reservation_item (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    line_item_id text,
    location_id text NOT NULL,
    quantity numeric NOT NULL,
    external_id text,
    description text,
    created_by text,
    metadata jsonb,
    inventory_item_id text NOT NULL,
    allow_backorder boolean DEFAULT false,
    raw_quantity jsonb
);


--
-- Name: return; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return (
    id text NOT NULL,
    order_id text NOT NULL,
    claim_id text,
    exchange_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    status public.return_status_enum DEFAULT 'open'::public.return_status_enum NOT NULL,
    no_notification boolean,
    refund_amount numeric,
    raw_refund_amount jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    received_at timestamp with time zone,
    canceled_at timestamp with time zone,
    location_id text,
    requested_at timestamp with time zone,
    created_by text
);


--
-- Name: return_display_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.return_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: return_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.return_display_id_seq OWNED BY public.return.display_id;


--
-- Name: return_fulfillment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_fulfillment (
    return_id character varying(255) NOT NULL,
    fulfillment_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: return_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_item (
    id text NOT NULL,
    return_id text NOT NULL,
    reason_id text,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    received_quantity numeric DEFAULT 0 NOT NULL,
    raw_received_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    damaged_quantity numeric DEFAULT 0 NOT NULL,
    raw_damaged_quantity jsonb DEFAULT '{"value": "0", "precision": 20}'::jsonb NOT NULL
);


--
-- Name: return_reason; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.return_reason (
    id character varying NOT NULL,
    value character varying NOT NULL,
    label character varying NOT NULL,
    description character varying,
    metadata jsonb,
    parent_return_reason_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: sales_channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_channel (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    is_disabled boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: sales_channel_stock_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_channel_stock_location (
    sales_channel_id character varying(255) NOT NULL,
    stock_location_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: script_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.script_migrations (
    id integer NOT NULL,
    script_name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    finished_at timestamp with time zone
);


--
-- Name: script_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.script_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: script_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.script_migrations_id_seq OWNED BY public.script_migrations.id;


--
-- Name: service_zone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_zone (
    id text NOT NULL,
    name text NOT NULL,
    metadata jsonb,
    fulfillment_set_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: shipping_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_option (
    id text NOT NULL,
    name text NOT NULL,
    price_type text DEFAULT 'flat'::text NOT NULL,
    service_zone_id text NOT NULL,
    shipping_profile_id text,
    provider_id text,
    data jsonb,
    metadata jsonb,
    shipping_option_type_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT shipping_option_price_type_check CHECK ((price_type = ANY (ARRAY['calculated'::text, 'flat'::text])))
);


--
-- Name: shipping_option_price_set; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_option_price_set (
    shipping_option_id character varying(255) NOT NULL,
    price_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: shipping_option_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_option_rule (
    id text NOT NULL,
    attribute text NOT NULL,
    operator text NOT NULL,
    value jsonb,
    shipping_option_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT shipping_option_rule_operator_check CHECK ((operator = ANY (ARRAY['in'::text, 'eq'::text, 'ne'::text, 'gt'::text, 'gte'::text, 'lt'::text, 'lte'::text, 'nin'::text])))
);


--
-- Name: shipping_option_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_option_type (
    id text NOT NULL,
    label text NOT NULL,
    description text,
    code text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: shipping_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_profile (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: stock_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_location (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    address_id text,
    metadata jsonb
);


--
-- Name: stock_location_address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_location_address (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    address_1 text NOT NULL,
    address_2 text,
    company text,
    city text,
    country_code text NOT NULL,
    phone text,
    province text,
    postal_code text,
    metadata jsonb
);


--
-- Name: store; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store (
    id text NOT NULL,
    name text DEFAULT 'Medusa Store'::text NOT NULL,
    default_sales_channel_id text,
    default_region_id text,
    default_location_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: store_currency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_currency (
    id text NOT NULL,
    currency_code text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    store_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: store_locale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_locale (
    id text NOT NULL,
    locale_code text NOT NULL,
    store_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: tax_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: tax_rate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate (
    id text NOT NULL,
    rate real,
    code text NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_combinable boolean DEFAULT false NOT NULL,
    tax_region_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


--
-- Name: tax_rate_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_rate_rule (
    id text NOT NULL,
    tax_rate_id text NOT NULL,
    reference_id text NOT NULL,
    reference text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


--
-- Name: tax_region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_region (
    id text NOT NULL,
    provider_id text,
    country_code text NOT NULL,
    province_code text,
    parent_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone,
    CONSTRAINT "CK_tax_region_country_top_level" CHECK (((parent_id IS NULL) OR (province_code IS NOT NULL))),
    CONSTRAINT "CK_tax_region_provider_top_level" CHECK (((parent_id IS NULL) OR (provider_id IS NULL)))
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id text NOT NULL,
    first_name text,
    last_name text,
    email text NOT NULL,
    avatar_url text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: user_preference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preference (
    id text NOT NULL,
    user_id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: user_rbac_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_rbac_role (
    user_id character varying(255) NOT NULL,
    rbac_role_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: view_configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.view_configuration (
    id text NOT NULL,
    entity text NOT NULL,
    name text,
    user_id text,
    is_system_default boolean DEFAULT false NOT NULL,
    configuration jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: workflow_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_execution (
    id character varying NOT NULL,
    workflow_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    execution jsonb,
    context jsonb,
    state character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    retention_time integer,
    run_id text DEFAULT '01KXTY5172EDYDTCZAWF97FDBK'::text NOT NULL
);


--
-- Name: link_module_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_module_migrations ALTER COLUMN id SET DEFAULT nextval('public.link_module_migrations_id_seq'::regclass);


--
-- Name: mikro_orm_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mikro_orm_migrations ALTER COLUMN id SET DEFAULT nextval('public.mikro_orm_migrations_id_seq'::regclass);


--
-- Name: order display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."order" ALTER COLUMN display_id SET DEFAULT nextval('public.order_display_id_seq'::regclass);


--
-- Name: order_change_action ordering; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_change_action ALTER COLUMN ordering SET DEFAULT nextval('public.order_change_action_ordering_seq'::regclass);


--
-- Name: order_claim display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_claim ALTER COLUMN display_id SET DEFAULT nextval('public.order_claim_display_id_seq'::regclass);


--
-- Name: order_exchange display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_exchange ALTER COLUMN display_id SET DEFAULT nextval('public.order_exchange_display_id_seq'::regclass);


--
-- Name: return display_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return ALTER COLUMN display_id SET DEFAULT nextval('public.return_display_id_seq'::regclass);


--
-- Name: script_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.script_migrations ALTER COLUMN id SET DEFAULT nextval('public.script_migrations_id_seq'::regclass);


--
-- Data for Name: account_holder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_holder (id, provider_id, external_id, email, data, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, token, salt, redacted, title, type, last_used_at, created_by, created_at, revoked_by, revoked_at, updated_at, deleted_at) FROM stdin;
apk_01KXTY56QD07ZFTYD3K4Z8XMT1	pk_afd4cb6af601da39989d1d354c39d7b7916780107413f045d14baa08fa356f90		pk_afd***f90	OneCurve Storefront	publishable	\N		2026-07-18 08:40:12.909-07	\N	\N	2026-07-18 08:40:12.909-07	\N
\.


--
-- Data for Name: application_method_buy_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_method_buy_rules (application_method_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: application_method_target_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_method_target_rules (application_method_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_identity (id, app_metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: auth_mfa_factor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_mfa_factor (id, auth_identity_id, provider, status, provider_metadata, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: auth_mfa_recovery_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_mfa_recovery_code (id, auth_identity_id, code_hash, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: auth_verification_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_verification_token (id, auth_identity_id, provider_identity_id, entity_id, token_hash, expires_at, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: capture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capture (id, amount, raw_amount, payment_id, created_at, updated_at, deleted_at, created_by, metadata) FROM stdin;
\.


--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart (id, region_id, customer_id, sales_channel_id, email, currency_code, shipping_address_id, billing_address_id, metadata, created_at, updated_at, deleted_at, completed_at, locale) FROM stdin;
\.


--
-- Data for Name: cart_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_address (id, customer_id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_line_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_line_item (id, cart_id, title, subtitle, thumbnail, quantity, variant_id, product_id, product_title, product_description, product_subtitle, product_type, product_collection, product_handle, variant_sku, variant_barcode, variant_title, variant_option_values, requires_shipping, is_discountable, is_tax_inclusive, compare_at_unit_price, raw_compare_at_unit_price, unit_price, raw_unit_price, metadata, created_at, updated_at, deleted_at, product_type_id, is_custom_price, is_giftcard) FROM stdin;
\.


--
-- Data for Name: cart_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_line_item_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, metadata, created_at, updated_at, deleted_at, item_id, is_tax_inclusive) FROM stdin;
\.


--
-- Data for Name: cart_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_line_item_tax_line (id, description, tax_rate_id, code, rate, provider_id, metadata, created_at, updated_at, deleted_at, item_id) FROM stdin;
\.


--
-- Data for Name: cart_payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_payment_collection (cart_id, payment_collection_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_promotion (cart_id, promotion_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_shipping_method (id, cart_id, name, description, amount, raw_amount, is_tax_inclusive, shipping_option_id, data, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_shipping_method_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, metadata, created_at, updated_at, deleted_at, shipping_method_id) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_shipping_method_tax_line (id, description, tax_rate_id, code, rate, provider_id, metadata, created_at, updated_at, deleted_at, shipping_method_id) FROM stdin;
\.


--
-- Data for Name: credit_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_line (id, cart_id, reference, reference_id, amount, raw_amount, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.currency (code, symbol, symbol_native, decimal_digits, rounding, raw_rounding, name, created_at, updated_at, deleted_at) FROM stdin;
usd	$	$	2	0	{"value": "0", "precision": 20}	US Dollar	2026-07-18 08:40:11.496-07	2026-07-18 08:40:11.496-07	\N
cad	CA$	$	2	0	{"value": "0", "precision": 20}	Canadian Dollar	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
eur	€	€	2	0	{"value": "0", "precision": 20}	Euro	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
aed	AED	د.إ.‏	2	0	{"value": "0", "precision": 20}	United Arab Emirates Dirham	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
afn	Af	؋	0	0	{"value": "0", "precision": 20}	Afghan Afghani	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
all	ALL	Lek	0	0	{"value": "0", "precision": 20}	Albanian Lek	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
amd	AMD	դր.	0	0	{"value": "0", "precision": 20}	Armenian Dram	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
ars	AR$	$	2	0	{"value": "0", "precision": 20}	Argentine Peso	2026-07-18 08:40:11.497-07	2026-07-18 08:40:11.497-07	\N
aud	AU$	$	2	0	{"value": "0", "precision": 20}	Australian Dollar	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
azn	man.	ман.	2	0	{"value": "0", "precision": 20}	Azerbaijani Manat	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bam	KM	KM	2	0	{"value": "0", "precision": 20}	Bosnia-Herzegovina Convertible Mark	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bdt	Tk	৳	2	0	{"value": "0", "precision": 20}	Bangladeshi Taka	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bgn	BGN	лв.	2	0	{"value": "0", "precision": 20}	Bulgarian Lev	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bhd	BD	د.ب.‏	3	0	{"value": "0", "precision": 20}	Bahraini Dinar	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bif	FBu	FBu	0	0	{"value": "0", "precision": 20}	Burundian Franc	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bnd	BN$	$	2	0	{"value": "0", "precision": 20}	Brunei Dollar	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bob	Bs	Bs	2	0	{"value": "0", "precision": 20}	Bolivian Boliviano	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
brl	R$	R$	2	0	{"value": "0", "precision": 20}	Brazilian Real	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bwp	BWP	P	2	0	{"value": "0", "precision": 20}	Botswanan Pula	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
byn	Br	руб.	2	0	{"value": "0", "precision": 20}	Belarusian Ruble	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
bzd	BZ$	$	2	0	{"value": "0", "precision": 20}	Belize Dollar	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
cdf	CDF	FrCD	2	0	{"value": "0", "precision": 20}	Congolese Franc	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
chf	CHF	CHF	2	0.05	{"value": "0.05", "precision": 20}	Swiss Franc	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
clp	CL$	$	0	0	{"value": "0", "precision": 20}	Chilean Peso	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
cny	CN¥	CN¥	2	0	{"value": "0", "precision": 20}	Chinese Yuan	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
cop	CO$	$	0	0	{"value": "0", "precision": 20}	Colombian Peso	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
crc	₡	₡	0	0	{"value": "0", "precision": 20}	Costa Rican Colón	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
cve	CV$	CV$	2	0	{"value": "0", "precision": 20}	Cape Verdean Escudo	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
czk	Kč	Kč	2	0	{"value": "0", "precision": 20}	Czech Republic Koruna	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
djf	Fdj	Fdj	0	0	{"value": "0", "precision": 20}	Djiboutian Franc	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
dkk	Dkr	kr	2	0	{"value": "0", "precision": 20}	Danish Krone	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
dop	RD$	RD$	2	0	{"value": "0", "precision": 20}	Dominican Peso	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
dzd	DA	د.ج.‏	2	0	{"value": "0", "precision": 20}	Algerian Dinar	2026-07-18 08:40:11.498-07	2026-07-18 08:40:11.498-07	\N
eek	Ekr	kr	2	0	{"value": "0", "precision": 20}	Estonian Kroon	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
egp	EGP	ج.م.‏	2	0	{"value": "0", "precision": 20}	Egyptian Pound	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
ern	Nfk	Nfk	2	0	{"value": "0", "precision": 20}	Eritrean Nakfa	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
etb	Br	Br	2	0	{"value": "0", "precision": 20}	Ethiopian Birr	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
gbp	£	£	2	0	{"value": "0", "precision": 20}	British Pound Sterling	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
gel	GEL	GEL	2	0	{"value": "0", "precision": 20}	Georgian Lari	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
ghs	GH₵	GH₵	2	0	{"value": "0", "precision": 20}	Ghanaian Cedi	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
gnf	FG	FG	0	0	{"value": "0", "precision": 20}	Guinean Franc	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
gtq	GTQ	Q	2	0	{"value": "0", "precision": 20}	Guatemalan Quetzal	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
hkd	HK$	$	2	0	{"value": "0", "precision": 20}	Hong Kong Dollar	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
hnl	HNL	L	2	0	{"value": "0", "precision": 20}	Honduran Lempira	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
hrk	kn	kn	2	0	{"value": "0", "precision": 20}	Croatian Kuna	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
huf	Ft	Ft	0	0	{"value": "0", "precision": 20}	Hungarian Forint	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
idr	Rp	Rp	0	0	{"value": "0", "precision": 20}	Indonesian Rupiah	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
ils	₪	₪	2	0	{"value": "0", "precision": 20}	Israeli New Sheqel	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
inr	Rs	₹	2	0	{"value": "0", "precision": 20}	Indian Rupee	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
iqd	IQD	د.ع.‏	0	0	{"value": "0", "precision": 20}	Iraqi Dinar	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
irr	IRR	﷼	0	0	{"value": "0", "precision": 20}	Iranian Rial	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
isk	Ikr	kr	0	0	{"value": "0", "precision": 20}	Icelandic Króna	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
jmd	J$	$	2	0	{"value": "0", "precision": 20}	Jamaican Dollar	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
jod	JD	د.أ.‏	3	0	{"value": "0", "precision": 20}	Jordanian Dinar	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
jpy	¥	￥	0	0	{"value": "0", "precision": 20}	Japanese Yen	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
kes	Ksh	Ksh	2	0	{"value": "0", "precision": 20}	Kenyan Shilling	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
khr	KHR	៛	2	0	{"value": "0", "precision": 20}	Cambodian Riel	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
kmf	CF	FC	0	0	{"value": "0", "precision": 20}	Comorian Franc	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
krw	₩	₩	0	0	{"value": "0", "precision": 20}	South Korean Won	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
kwd	KD	د.ك.‏	3	0	{"value": "0", "precision": 20}	Kuwaiti Dinar	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
kzt	KZT	тңг.	2	0	{"value": "0", "precision": 20}	Kazakhstani Tenge	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
lbp	LB£	ل.ل.‏	0	0	{"value": "0", "precision": 20}	Lebanese Pound	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
lkr	SLRs	SL Re	2	0	{"value": "0", "precision": 20}	Sri Lankan Rupee	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
ltl	Lt	Lt	2	0	{"value": "0", "precision": 20}	Lithuanian Litas	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
lvl	Ls	Ls	2	0	{"value": "0", "precision": 20}	Latvian Lats	2026-07-18 08:40:11.499-07	2026-07-18 08:40:11.499-07	\N
lyd	LD	د.ل.‏	3	0	{"value": "0", "precision": 20}	Libyan Dinar	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mad	MAD	د.م.‏	2	0	{"value": "0", "precision": 20}	Moroccan Dirham	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mdl	MDL	MDL	2	0	{"value": "0", "precision": 20}	Moldovan Leu	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mga	MGA	MGA	0	0	{"value": "0", "precision": 20}	Malagasy Ariary	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mkd	MKD	MKD	2	0	{"value": "0", "precision": 20}	Macedonian Denar	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mmk	MMK	K	0	0	{"value": "0", "precision": 20}	Myanma Kyat	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mnt	MNT	₮	0	0	{"value": "0", "precision": 20}	Mongolian Tugrig	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mop	MOP$	MOP$	2	0	{"value": "0", "precision": 20}	Macanese Pataca	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mur	MURs	MURs	0	0	{"value": "0", "precision": 20}	Mauritian Rupee	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mwk	K	K	2	0	{"value": "0", "precision": 20}	Malawian Kwacha	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mxn	MX$	$	2	0	{"value": "0", "precision": 20}	Mexican Peso	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
myr	RM	RM	2	0	{"value": "0", "precision": 20}	Malaysian Ringgit	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
mzn	MTn	MTn	2	0	{"value": "0", "precision": 20}	Mozambican Metical	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
nad	N$	N$	2	0	{"value": "0", "precision": 20}	Namibian Dollar	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
ngn	₦	₦	2	0	{"value": "0", "precision": 20}	Nigerian Naira	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
nio	C$	C$	2	0	{"value": "0", "precision": 20}	Nicaraguan Córdoba	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
nok	Nkr	kr	2	0	{"value": "0", "precision": 20}	Norwegian Krone	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
npr	NPRs	नेरू	2	0	{"value": "0", "precision": 20}	Nepalese Rupee	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
nzd	NZ$	$	2	0	{"value": "0", "precision": 20}	New Zealand Dollar	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
omr	OMR	ر.ع.‏	3	0	{"value": "0", "precision": 20}	Omani Rial	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
pab	B/.	B/.	2	0	{"value": "0", "precision": 20}	Panamanian Balboa	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
pen	S/.	S/.	2	0	{"value": "0", "precision": 20}	Peruvian Nuevo Sol	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
php	₱	₱	2	0	{"value": "0", "precision": 20}	Philippine Peso	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
pkr	PKRs	₨	0	0	{"value": "0", "precision": 20}	Pakistani Rupee	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
pln	zł	zł	2	0	{"value": "0", "precision": 20}	Polish Zloty	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
pyg	₲	₲	0	0	{"value": "0", "precision": 20}	Paraguayan Guarani	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
qar	QR	ر.ق.‏	2	0	{"value": "0", "precision": 20}	Qatari Rial	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
ron	RON	RON	2	0	{"value": "0", "precision": 20}	Romanian Leu	2026-07-18 08:40:11.5-07	2026-07-18 08:40:11.5-07	\N
rsd	din.	дин.	0	0	{"value": "0", "precision": 20}	Serbian Dinar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
rub	RUB	₽.	2	0	{"value": "0", "precision": 20}	Russian Ruble	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
rwf	RWF	FR	0	0	{"value": "0", "precision": 20}	Rwandan Franc	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
sar	SR	ر.س.‏	2	0	{"value": "0", "precision": 20}	Saudi Riyal	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
sdg	SDG	SDG	2	0	{"value": "0", "precision": 20}	Sudanese Pound	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
sek	Skr	kr	2	0	{"value": "0", "precision": 20}	Swedish Krona	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
sgd	S$	$	2	0	{"value": "0", "precision": 20}	Singapore Dollar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
sos	Ssh	Ssh	0	0	{"value": "0", "precision": 20}	Somali Shilling	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
syp	SY£	ل.س.‏	0	0	{"value": "0", "precision": 20}	Syrian Pound	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
thb	฿	฿	2	0	{"value": "0", "precision": 20}	Thai Baht	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
tnd	DT	د.ت.‏	3	0	{"value": "0", "precision": 20}	Tunisian Dinar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
top	T$	T$	2	0	{"value": "0", "precision": 20}	Tongan Paʻanga	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
tjs	TJS	с.	2	0	{"value": "0", "precision": 20}	Tajikistani Somoni	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
try	₺	₺	2	0	{"value": "0", "precision": 20}	Turkish Lira	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
ttd	TT$	$	2	0	{"value": "0", "precision": 20}	Trinidad and Tobago Dollar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
twd	NT$	NT$	2	0	{"value": "0", "precision": 20}	New Taiwan Dollar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
tzs	TSh	TSh	0	0	{"value": "0", "precision": 20}	Tanzanian Shilling	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
uah	₴	₴	2	0	{"value": "0", "precision": 20}	Ukrainian Hryvnia	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
ugx	USh	USh	0	0	{"value": "0", "precision": 20}	Ugandan Shilling	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
uyu	$U	$	2	0	{"value": "0", "precision": 20}	Uruguayan Peso	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
uzs	UZS	UZS	0	0	{"value": "0", "precision": 20}	Uzbekistan Som	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
vef	Bs.F.	Bs.F.	2	0	{"value": "0", "precision": 20}	Venezuelan Bolívar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
vnd	₫	₫	0	0	{"value": "0", "precision": 20}	Vietnamese Dong	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
xaf	FCFA	FCFA	0	0	{"value": "0", "precision": 20}	CFA Franc BEAC	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
xof	CFA	CFA	0	0	{"value": "0", "precision": 20}	CFA Franc BCEAO	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
xpf	₣	₣	0	0	{"value": "0", "precision": 20}	CFP Franc	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
yer	YR	ر.ي.‏	0	0	{"value": "0", "precision": 20}	Yemeni Rial	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
zar	R	R	2	0	{"value": "0", "precision": 20}	South African Rand	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
zmk	ZK	ZK	0	0	{"value": "0", "precision": 20}	Zambian Kwacha	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
zwl	ZWL$	ZWL$	0	0	{"value": "0", "precision": 20}	Zimbabwean Dollar	2026-07-18 08:40:11.501-07	2026-07-18 08:40:11.501-07	\N
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer (id, company_name, first_name, last_name, email, phone, has_account, metadata, created_at, updated_at, deleted_at, created_by) FROM stdin;
\.


--
-- Data for Name: customer_account_holder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_account_holder (customer_id, account_holder_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_address (id, customer_id, address_name, is_default_shipping, is_default_billing, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_group (id, name, metadata, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_group_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_group_customer (id, customer_id, customer_group_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment (id, location_id, packed_at, shipped_at, delivered_at, canceled_at, data, provider_id, shipping_option_id, metadata, delivery_address_id, created_at, updated_at, deleted_at, marked_shipped_by, created_by, requires_shipping) FROM stdin;
\.


--
-- Data for Name: fulfillment_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_address (id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_item (id, title, sku, barcode, quantity, raw_quantity, line_item_id, inventory_item_id, fulfillment_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_label; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_label (id, tracking_number, tracking_url, label_url, fulfillment_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
manual_manual	t	2026-07-18 08:40:11.526-07	2026-07-18 08:40:11.526-07	\N
\.


--
-- Data for Name: fulfillment_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fulfillment_set (id, name, type, metadata, created_at, updated_at, deleted_at) FROM stdin;
fuset_01KXTY56VA5ME38VF19FAAEZ4M	India delivery	shipping	\N	2026-07-18 08:40:13.035-07	2026-07-18 08:40:13.035-07	\N
\.


--
-- Data for Name: geo_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.geo_zone (id, type, country_code, province_code, city, service_zone_id, postal_expression, metadata, created_at, updated_at, deleted_at) FROM stdin;
fgz_01KXTY56V95R560A4E64MRETGQ	country	in	\N	\N	serzo_01KXTY56VAX8GW1RSP5CHCQA44	\N	\N	2026-07-18 08:40:13.035-07	2026-07-18 08:40:13.035-07	\N
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.image (id, url, metadata, created_at, updated_at, deleted_at, rank, product_id) FROM stdin;
img_01KXTY5703AK2MV4MGJB8JB8NP	http://localhost:9000/static/products/vintage.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZYZN081XY0D7WPFF0K
img_01KXTY5705VS8YRKJSHEY09PN9	http://localhost:9000/static/products/seven-horses-orange-players-edition.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZZ9AGNGFB5772Y95NE
img_01KXTY5705CD7HS0AEG2D4NE67	http://localhost:9000/static/products/mn7.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZZR0YMF7DXY0AET7PX
img_01KXTY5706QVNMFAQ7M6F97M34	http://localhost:9000/static/products/original-grade-two.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZZFVF244PE95K6S1DY
img_01KXTY5706YPNZGC182RBEW2NT	http://localhost:9000/static/products/beast-grade-2.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZZJ281DQBMYY1MC6EA
img_01KXTY5707S8ANSPRSWCZ9YZPP	http://localhost:9000/static/products/stallion.jpg	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N	0	prod_01KXTY56ZZ0DSSSQY5EA2S63RT
img_01KXTY5707Q80N59XXH1109K4D	http://localhost:9000/static/products/black-edition.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG
img_01KXTY5708XZDP0GBG3DBK3E56	http://localhost:9000/static/products/hulk-county-edition.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZM9EBR3YBV0D2HA4H
img_01KXTY5709TDV9WMFJ2RNP7T34	http://localhost:9000/static/products/players-edition-pads.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZWS0FZ66NT6X8W10S
img_01KXTY570ATV7R0DJ4RGMW08CR	http://localhost:9000/static/products/academy-pads.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZ5385W56FTM7337MG
img_01KXTY570AVV523Q293HWDWSR6	http://localhost:9000/static/products/limited-edition-pads-black.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZYF8ARCCMXBMSTPM5
img_01KXTY570BC3KN53YCW5S5CBDH	http://localhost:9000/static/products/limited-edition-pads-navy-blue.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZMJ4393NXPWFGWHD4
img_01KXTY570CWT91SKDPZYFP5E5G	http://localhost:9000/static/products/limited-edition-pads-royal-blue.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZFVQPW7BJVC3R0W00
img_01KXTY570CVFK08BHSDR42PZ3M	http://localhost:9000/static/products/limited-edition-pads-black-gold.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZ3G7Y8PDNMV56KDR8
img_01KXTY570D6FBG4MT36DYH6B4K	http://localhost:9000/static/products/limited-edition-pads-blue-gold.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZ00D1KEQMEPBRGY16
img_01KXTY570DJ41TN9MVRMZQVDDT	http://localhost:9000/static/products/limited-edition-pads-white-gold.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZKQCY5YAP5M66E7AK
img_01KXTY570E3WX17HEAX94AP147	http://localhost:9000/static/products/original-gloves-yellow.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZBWNKA6H14MRMGBDX
img_01KXTY570ET9T80AKKZHW5GKZK	http://localhost:9000/static/products/original-gloves-green.jpg	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N	0	prod_01KXTY56ZZ97QDB8R5R659CY3C
img_01KXTY570F6F75TKY75ND17YC5	http://localhost:9000/static/products/original-gloves-blue.jpg	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N	0	prod_01KXTY5700S60ZXNK9ZN9S15YV
img_01KXTY570FT87M5FQQGFJC4T4C	http://localhost:9000/static/products/keeping-gloves-players-edition.jpg	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N	0	prod_01KXTY5700XB2G4GK3RYXGFK9E
img_01KXTY570GSA85TPFEF1WS7VMG	http://localhost:9000/static/products/keeping-pads-international-players-edition.jpg	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N	0	prod_01KXTY5700G8RFWA7Z6BNB6DVJ
img_01KXTY570H9Y7A6CAKPEJKSWXE	http://localhost:9000/static/products/keeping-pads-black-blue.jpg	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N	0	prod_01KXTY5700FZAZ1SR2EGVQM4HY
\.


--
-- Data for Name: inventory_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_item (id, created_at, updated_at, deleted_at, sku, origin_country, hs_code, mid_code, material, weight, length, height, width, requires_shipping, description, title, thumbnail, metadata) FROM stdin;
iitem_01KXTY575YTWRMK6AX9CT4BYPV	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-1	\N	\N	\N	\N	\N	\N	\N	\N	t	Vintage	Vintage	\N	\N
iitem_01KXTY575Y5QD0Q81CX1AGF20K	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-2	\N	\N	\N	\N	\N	\N	\N	\N	t	Seven Horses Orange Players Edition	Seven Horses Orange Players Edition	\N	\N
iitem_01KXTY575Y9AZRVCA15YVEQNTJ	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-3	\N	\N	\N	\N	\N	\N	\N	\N	t	MN7	MN7	\N	\N
iitem_01KXTY575YNM2BB0C2NJ30267V	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-4	\N	\N	\N	\N	\N	\N	\N	\N	t	Original Grade Two	Original Grade Two	\N	\N
iitem_01KXTY575YXMRXV492Y2X4SM6X	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-5	\N	\N	\N	\N	\N	\N	\N	\N	t	Beast Grade 2	Beast Grade 2	\N	\N
iitem_01KXTY575Z7KR8V1E0S828WMJS	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-6	\N	\N	\N	\N	\N	\N	\N	\N	t	Stallion	Stallion	\N	\N
iitem_01KXTY575Z7G2TW5GVMWX9QDMN	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-7	\N	\N	\N	\N	\N	\N	\N	\N	t	Black Edition	Black Edition	\N	\N
iitem_01KXTY575ZGPW4SJDHBNNZ9CNE	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-8	\N	\N	\N	\N	\N	\N	\N	\N	t	Hulk & County Edition	Hulk & County Edition	\N	\N
iitem_01KXTY575Z1S0TMV8XBHWYGGD2	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-9	\N	\N	\N	\N	\N	\N	\N	\N	t	Players Edition Pads	Players Edition Pads	\N	\N
iitem_01KXTY575Z1Y2X9K9VRVGWSTC1	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-10	\N	\N	\N	\N	\N	\N	\N	\N	t	Academy Pads	Academy Pads	\N	\N
iitem_01KXTY575Z808C1YZZDNGA5VAR	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-11	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - Black	Limited Edition Pads - Black	\N	\N
iitem_01KXTY575ZRZV5NM202690W7TK	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-12	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - Navy Blue	Limited Edition Pads - Navy Blue	\N	\N
iitem_01KXTY575ZZ33BDARV4R0MHC20	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-13	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - Royal Blue	Limited Edition Pads - Royal Blue	\N	\N
iitem_01KXTY575ZXAED39PHXAR4GMB6	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-14	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - Black & Gold	Limited Edition Pads - Black & Gold	\N	\N
iitem_01KXTY5760S64MHMDJ1F8JVKTX	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-15	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - Blue & Gold	Limited Edition Pads - Blue & Gold	\N	\N
iitem_01KXTY5760SHEKQ5WRWXSJ2TFW	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-16	\N	\N	\N	\N	\N	\N	\N	\N	t	Limited Edition Pads - White & Gold	Limited Edition Pads - White & Gold	\N	\N
iitem_01KXTY57604Q07RBPEGE5HKAT0	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-17	\N	\N	\N	\N	\N	\N	\N	\N	t	Original Gloves - Yellow	Original Gloves - Yellow	\N	\N
iitem_01KXTY5760ENC2AGHPA5EAD5AJ	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-18	\N	\N	\N	\N	\N	\N	\N	\N	t	Original Gloves - Green	Original Gloves - Green	\N	\N
iitem_01KXTY5760BYZGHG88DXTQ2Y6W	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-19	\N	\N	\N	\N	\N	\N	\N	\N	t	Original Gloves - Blue	Original Gloves - Blue	\N	\N
iitem_01KXTY57602JDFYZ7R1GZMKJ4Q	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-20	\N	\N	\N	\N	\N	\N	\N	\N	t	Keeping Gloves - Players Edition	Keeping Gloves - Players Edition	\N	\N
iitem_01KXTY5760610GHKN9DSSNG6ES	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-21	\N	\N	\N	\N	\N	\N	\N	\N	t	Keeping Pads - International Players Edition	Keeping Pads - International Players Edition	\N	\N
iitem_01KXTY57608B4YYCMVWFHW69H2	2026-07-18 08:40:13.377-07	2026-07-18 08:40:13.377-07	\N	OC-22	\N	\N	\N	\N	\N	\N	\N	\N	t	Keeping Pads - Black & Blue	Keeping Pads - Black & Blue	\N	\N
\.


--
-- Data for Name: inventory_level; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_level (id, created_at, updated_at, deleted_at, inventory_item_id, location_id, stocked_quantity, reserved_quantity, incoming_quantity, metadata, raw_stocked_quantity, raw_reserved_quantity, raw_incoming_quantity) FROM stdin;
ilev_01KXTY579H35J8YT8Z4XYR62DG	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Y5QD0Q81CX1AGF20K	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579HQHSH2347RVX7NN4Q	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Y9AZRVCA15YVEQNTJ	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579HFCG0SKQ8TRWZRNNF	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575YNM2BB0C2NJ30267V	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579HKC7A3EA4DGENQQWY	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575YTWRMK6AX9CT4BYPV	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579H157ZXAP0FVFWKXEM	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575YXMRXV492Y2X4SM6X	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579JJXKSV2RY1HVPYXFK	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Z1S0TMV8XBHWYGGD2	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579J9NZ767B8HBSBXCEF	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Z1Y2X9K9VRVGWSTC1	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579JTYE95KG78A22P22Y	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Z7G2TW5GVMWX9QDMN	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579J3H4SNX6AXG0GSWC2	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Z7KR8V1E0S828WMJS	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579JG70RG07VPJ358BBG	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575Z808C1YZZDNGA5VAR	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579JVRB9D3M9DZN9RJZ1	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575ZGPW4SJDHBNNZ9CNE	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579J2MT84YN3EQKN84DR	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575ZRZV5NM202690W7TK	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579J08JAJ7QHTJYPEW7R	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575ZXAED39PHXAR4GMB6	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579K6YR0YW1RZ8WD5Z70	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY575ZZ33BDARV4R0MHC20	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579K15D86WP0M4E1H6ZM	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY57602JDFYZ7R1GZMKJ4Q	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579K4KE02EC2DRP5KX31	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY57604Q07RBPEGE5HKAT0	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KW6GQ288KPTGB47NE	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY5760610GHKN9DSSNG6ES	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KJE6GKDQSBWK9WPJT	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY57608B4YYCMVWFHW69H2	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KF97NPDNF6VDGP5ZJ	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY5760BYZGHG88DXTQ2Y6W	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KDSKMG7QNS71DNB2K	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY5760ENC2AGHPA5EAD5AJ	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KC6G9Z45H2ESKGBGH	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY5760S64MHMDJ1F8JVKTX	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
ilev_01KXTY579KCFHW168B46A2HQGV	2026-07-18 08:40:13.492-07	2026-07-18 08:40:13.492-07	\N	iitem_01KXTY5760SHEKQ5WRWXSJ2TFW	sloc_01KXTY56TP4V94XCQYG8RD9SMM	12	0	0	\N	{"value": "12", "precision": 20}	{"value": "0", "precision": 20}	{"value": "0", "precision": 20}
\.


--
-- Data for Name: invite; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invite (id, email, accepted, token, expires_at, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: invite_rbac_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invite_rbac_role (invite_id, rbac_role_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: link_module_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.link_module_migrations (id, table_name, link_descriptor, created_at) FROM stdin;
1	cart_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "cart", "fromModule": "cart"}	2026-07-18 08:40:07.657061
2	cart_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "cart", "fromModule": "cart"}	2026-07-18 08:40:07.673804
3	customer_account_holder	{"toModel": "account_holder", "toModule": "payment", "fromModel": "customer", "fromModule": "customer"}	2026-07-18 08:40:07.683021
4	location_fulfillment_provider	{"toModel": "fulfillment_provider", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2026-07-18 08:40:07.690925
5	location_fulfillment_set	{"toModel": "fulfillment_set", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2026-07-18 08:40:07.6984
6	invite_rbac_role	{"toModel": "rbac_role", "toModule": "rbac", "fromModel": "invite", "fromModule": "user"}	2026-07-18 08:40:07.706428
7	order_cart	{"toModel": "cart", "toModule": "cart", "fromModel": "order", "fromModule": "order"}	2026-07-18 08:40:07.71402
8	order_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "order", "fromModule": "order"}	2026-07-18 08:40:07.722271
9	order_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "order", "fromModule": "order"}	2026-07-18 08:40:07.730164
10	order_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "order", "fromModule": "order"}	2026-07-18 08:40:07.738196
11	return_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "return", "fromModule": "order"}	2026-07-18 08:40:07.745397
12	product_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "product", "fromModule": "product"}	2026-07-18 08:40:07.752935
13	product_shipping_profile	{"toModel": "shipping_profile", "toModule": "fulfillment", "fromModel": "product", "fromModule": "product"}	2026-07-18 08:40:07.760518
14	product_variant_inventory_item	{"toModel": "inventory", "toModule": "inventory", "fromModel": "variant", "fromModule": "product"}	2026-07-18 08:40:07.767876
15	product_variant_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "variant", "fromModule": "product"}	2026-07-18 08:40:07.775781
16	publishable_api_key_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "api_key", "fromModule": "api_key"}	2026-07-18 08:40:07.783172
17	region_payment_provider	{"toModel": "payment_provider", "toModule": "payment", "fromModel": "region", "fromModule": "region"}	2026-07-18 08:40:07.791757
18	sales_channel_stock_location	{"toModel": "location", "toModule": "stock_location", "fromModel": "sales_channel", "fromModule": "sales_channel"}	2026-07-18 08:40:07.800293
19	shipping_option_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "shipping_option", "fromModule": "fulfillment"}	2026-07-18 08:40:07.808511
20	user_rbac_role	{"toModel": "rbac_role", "toModule": "rbac", "fromModel": "user", "fromModule": "user"}	2026-07-18 08:40:07.816226
\.


--
-- Data for Name: location_fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_fulfillment_provider (stock_location_id, fulfillment_provider_id, id, created_at, updated_at, deleted_at) FROM stdin;
sloc_01KXTY56TP4V94XCQYG8RD9SMM	manual_manual	locfp_01KXTY56TYJBW71E557MXC90CC	2026-07-18 08:40:13.021888-07	2026-07-18 08:40:13.021888-07	\N
\.


--
-- Data for Name: location_fulfillment_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_fulfillment_set (stock_location_id, fulfillment_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
sloc_01KXTY56TP4V94XCQYG8RD9SMM	fuset_01KXTY56VA5ME38VF19FAAEZ4M	locfs_01KXTY56VP2NSJS66CVRD7NRJX	2026-07-18 08:40:13.046546-07	2026-07-18 08:40:13.046546-07	\N
\.


--
-- Data for Name: mikro_orm_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mikro_orm_migrations (id, name, executed_at) FROM stdin;
1	Migration20240307161216	2026-07-18 08:40:03.955868-07
2	Migration20241210073813	2026-07-18 08:40:03.955868-07
3	Migration20250106142624	2026-07-18 08:40:03.955868-07
4	Migration20250120110820	2026-07-18 08:40:03.955868-07
5	Migration20240307132720	2026-07-18 08:40:04.054598-07
6	Migration20240719123015	2026-07-18 08:40:04.054598-07
7	Migration20241213063611	2026-07-18 08:40:04.054598-07
8	Migration20251010131115	2026-07-18 08:40:04.054598-07
9	InitialSetup20240401153642	2026-07-18 08:40:04.173755-07
10	Migration20240601111544	2026-07-18 08:40:04.173755-07
11	Migration202408271511	2026-07-18 08:40:04.173755-07
12	Migration20241122120331	2026-07-18 08:40:04.173755-07
13	Migration20241125090957	2026-07-18 08:40:04.173755-07
14	Migration20250411073236	2026-07-18 08:40:04.173755-07
15	Migration20250516081326	2026-07-18 08:40:04.173755-07
16	Migration20250910154539	2026-07-18 08:40:04.173755-07
17	Migration20250911092221	2026-07-18 08:40:04.173755-07
18	Migration20250929204438	2026-07-18 08:40:04.173755-07
19	Migration20251008132218	2026-07-18 08:40:04.173755-07
20	Migration20251011090511	2026-07-18 08:40:04.173755-07
21	Migration20260224120000	2026-07-18 08:40:04.173755-07
22	Migration20260301002050	2026-07-18 08:40:04.173755-07
23	Migration20260306120000	2026-07-18 08:40:04.173755-07
24	Migration20230929122253	2026-07-18 08:40:04.524583-07
25	Migration20240322094407	2026-07-18 08:40:04.524583-07
26	Migration20240322113359	2026-07-18 08:40:04.524583-07
27	Migration20240322120125	2026-07-18 08:40:04.524583-07
28	Migration20240626133555	2026-07-18 08:40:04.524583-07
29	Migration20240704094505	2026-07-18 08:40:04.524583-07
30	Migration20241127114534	2026-07-18 08:40:04.524583-07
31	Migration20241127223829	2026-07-18 08:40:04.524583-07
32	Migration20241128055359	2026-07-18 08:40:04.524583-07
33	Migration20241212190401	2026-07-18 08:40:04.524583-07
34	Migration20250408145122	2026-07-18 08:40:04.524583-07
35	Migration20250409122219	2026-07-18 08:40:04.524583-07
36	Migration20251009110625	2026-07-18 08:40:04.524583-07
37	Migration20251112192723	2026-07-18 08:40:04.524583-07
38	Migration20260429163502	2026-07-18 08:40:04.524583-07
39	Migration20240227120221	2026-07-18 08:40:04.784439-07
40	Migration20240617102917	2026-07-18 08:40:04.784439-07
41	Migration20240624153824	2026-07-18 08:40:04.784439-07
42	Migration20241211061114	2026-07-18 08:40:04.784439-07
43	Migration20250113094144	2026-07-18 08:40:04.784439-07
44	Migration20250120110700	2026-07-18 08:40:04.784439-07
45	Migration20250226130616	2026-07-18 08:40:04.784439-07
46	Migration20250508081510	2026-07-18 08:40:04.784439-07
47	Migration20250828075407	2026-07-18 08:40:04.784439-07
48	Migration20250909083125	2026-07-18 08:40:04.784439-07
49	Migration20250916120552	2026-07-18 08:40:04.784439-07
50	Migration20250917143818	2026-07-18 08:40:04.784439-07
51	Migration20250919122137	2026-07-18 08:40:04.784439-07
52	Migration20251006000000	2026-07-18 08:40:04.784439-07
53	Migration20251015113934	2026-07-18 08:40:04.784439-07
54	Migration20251107050148	2026-07-18 08:40:04.784439-07
55	Migration20240124154000	2026-07-18 08:40:05.029472-07
56	Migration20240524123112	2026-07-18 08:40:05.029472-07
57	Migration20240602110946	2026-07-18 08:40:05.029472-07
58	Migration20241211074630	2026-07-18 08:40:05.029472-07
59	Migration20251010130829	2026-07-18 08:40:05.029472-07
60	Migration20240115152146	2026-07-18 08:40:05.129372-07
61	Migration20240222170223	2026-07-18 08:40:05.173599-07
62	Migration20240831125857	2026-07-18 08:40:05.173599-07
63	Migration20241106085918	2026-07-18 08:40:05.173599-07
64	Migration20241205095237	2026-07-18 08:40:05.173599-07
65	Migration20241216183049	2026-07-18 08:40:05.173599-07
66	Migration20241218091938	2026-07-18 08:40:05.173599-07
67	Migration20250120115059	2026-07-18 08:40:05.173599-07
68	Migration20250212131240	2026-07-18 08:40:05.173599-07
69	Migration20250326151602	2026-07-18 08:40:05.173599-07
70	Migration20250508081553	2026-07-18 08:40:05.173599-07
71	Migration20251017153909	2026-07-18 08:40:05.173599-07
72	Migration20251208130704	2026-07-18 08:40:05.173599-07
73	Migration20240205173216	2026-07-18 08:40:05.360814-07
74	Migration20240624200006	2026-07-18 08:40:05.360814-07
75	Migration20250120110744	2026-07-18 08:40:05.360814-07
76	InitialSetup20240221144943	2026-07-18 08:40:05.494766-07
77	Migration20240604080145	2026-07-18 08:40:05.494766-07
78	Migration20241205122700	2026-07-18 08:40:05.494766-07
79	Migration20251015123842	2026-07-18 08:40:05.494766-07
80	InitialSetup20240227075933	2026-07-18 08:40:05.555566-07
81	Migration20240621145944	2026-07-18 08:40:05.555566-07
82	Migration20241206083313	2026-07-18 08:40:05.555566-07
83	Migration20251202184737	2026-07-18 08:40:05.555566-07
84	Migration20251212161429	2026-07-18 08:40:05.555566-07
85	Migration20240227090331	2026-07-18 08:40:05.632666-07
86	Migration20240710135844	2026-07-18 08:40:05.632666-07
87	Migration20240924114005	2026-07-18 08:40:05.632666-07
88	Migration20241212052837	2026-07-18 08:40:05.632666-07
89	InitialSetup20240228133303	2026-07-18 08:40:05.735519-07
90	Migration20240624082354	2026-07-18 08:40:05.735519-07
91	Migration20240225134525	2026-07-18 08:40:05.781593-07
92	Migration20240806072619	2026-07-18 08:40:05.781593-07
93	Migration20241211151053	2026-07-18 08:40:05.781593-07
94	Migration20250115160517	2026-07-18 08:40:05.781593-07
95	Migration20250120110552	2026-07-18 08:40:05.781593-07
96	Migration20250123122334	2026-07-18 08:40:05.781593-07
97	Migration20250206105639	2026-07-18 08:40:05.781593-07
98	Migration20250207132723	2026-07-18 08:40:05.781593-07
99	Migration20250625084134	2026-07-18 08:40:05.781593-07
100	Migration20250924135437	2026-07-18 08:40:05.781593-07
101	Migration20250929124701	2026-07-18 08:40:05.781593-07
102	Migration20240219102530	2026-07-18 08:40:05.944989-07
103	Migration20240604100512	2026-07-18 08:40:05.944989-07
104	Migration20240715102100	2026-07-18 08:40:05.944989-07
105	Migration20240715174100	2026-07-18 08:40:05.944989-07
106	Migration20240716081800	2026-07-18 08:40:05.944989-07
107	Migration20240801085921	2026-07-18 08:40:05.944989-07
108	Migration20240821164505	2026-07-18 08:40:05.944989-07
109	Migration20240821170920	2026-07-18 08:40:05.944989-07
110	Migration20240827133639	2026-07-18 08:40:05.944989-07
111	Migration20240902195921	2026-07-18 08:40:05.944989-07
112	Migration20240913092514	2026-07-18 08:40:05.944989-07
113	Migration20240930122627	2026-07-18 08:40:05.944989-07
114	Migration20241014142943	2026-07-18 08:40:05.944989-07
115	Migration20241106085223	2026-07-18 08:40:05.944989-07
116	Migration20241129124827	2026-07-18 08:40:05.944989-07
117	Migration20241217162224	2026-07-18 08:40:05.944989-07
118	Migration20250326151554	2026-07-18 08:40:05.944989-07
119	Migration20250522181137	2026-07-18 08:40:05.944989-07
120	Migration20250702095353	2026-07-18 08:40:05.944989-07
121	Migration20250704120229	2026-07-18 08:40:05.944989-07
122	Migration20250910130000	2026-07-18 08:40:05.944989-07
123	Migration20251016160403	2026-07-18 08:40:05.944989-07
124	Migration20251016182939	2026-07-18 08:40:05.944989-07
125	Migration20251017155709	2026-07-18 08:40:05.944989-07
126	Migration20251114100559	2026-07-18 08:40:05.944989-07
127	Migration20251125164002	2026-07-18 08:40:05.944989-07
128	Migration20251210112909	2026-07-18 08:40:05.944989-07
129	Migration20251210112924	2026-07-18 08:40:05.944989-07
130	Migration20251225120947	2026-07-18 08:40:05.944989-07
131	Migration20260106185528	2026-07-18 08:40:05.944989-07
132	Migration20250717162007	2026-07-18 08:40:06.470865-07
133	Migration20260127081758	2026-07-18 08:40:06.470865-07
134	Migration20240205025928	2026-07-18 08:40:06.542543-07
135	Migration20240529080336	2026-07-18 08:40:06.542543-07
136	Migration20241202100304	2026-07-18 08:40:06.542543-07
137	Migration20260514083900	2026-07-18 08:40:06.542543-07
138	Migration20260525090000	2026-07-18 08:40:06.542543-07
139	Migration20240214033943	2026-07-18 08:40:06.708729-07
140	Migration20240703095850	2026-07-18 08:40:06.708729-07
141	Migration20241202103352	2026-07-18 08:40:06.708729-07
142	Migration20240311145700_InitialSetupMigration	2026-07-18 08:40:06.785524-07
143	Migration20240821170957	2026-07-18 08:40:06.785524-07
144	Migration20240917161003	2026-07-18 08:40:06.785524-07
145	Migration20241217110416	2026-07-18 08:40:06.785524-07
146	Migration20250113122235	2026-07-18 08:40:06.785524-07
147	Migration20250120115002	2026-07-18 08:40:06.785524-07
148	Migration20250822130931	2026-07-18 08:40:06.785524-07
149	Migration20250825132614	2026-07-18 08:40:06.785524-07
150	Migration20251114133146	2026-07-18 08:40:06.785524-07
151	Migration20240509083918_InitialSetupMigration	2026-07-18 08:40:07.024006-07
152	Migration20240628075401	2026-07-18 08:40:07.024006-07
153	Migration20240830094712	2026-07-18 08:40:07.024006-07
154	Migration20250120110514	2026-07-18 08:40:07.024006-07
155	Migration20251028172715	2026-07-18 08:40:07.024006-07
156	Migration20251121123942	2026-07-18 08:40:07.024006-07
157	Migration20251121150408	2026-07-18 08:40:07.024006-07
158	Migration20231228143900	2026-07-18 08:40:07.222177-07
159	Migration20241206101446	2026-07-18 08:40:07.222177-07
160	Migration20250128174331	2026-07-18 08:40:07.222177-07
161	Migration20250505092459	2026-07-18 08:40:07.222177-07
162	Migration20250819104213	2026-07-18 08:40:07.222177-07
163	Migration20250819110924	2026-07-18 08:40:07.222177-07
164	Migration20250908080305	2026-07-18 08:40:07.222177-07
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification (id, "to", channel, template, data, trigger_type, resource_id, resource_type, receiver_id, original_notification_id, idempotency_key, external_id, provider_id, created_at, updated_at, deleted_at, status, "from", provider_data) FROM stdin;
\.


--
-- Data for Name: notification_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_provider (id, handle, name, is_enabled, channels, created_at, updated_at, deleted_at) FROM stdin;
local	local	local	t	{feed}	2026-07-18 08:40:11.539-07	2026-07-18 08:40:11.539-07	\N
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."order" (id, region_id, display_id, customer_id, version, sales_channel_id, status, is_draft_order, email, currency_code, shipping_address_id, billing_address_id, no_notification, metadata, created_at, updated_at, deleted_at, canceled_at, custom_display_id, locale) FROM stdin;
\.


--
-- Data for Name: order_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_address (id, customer_id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_cart (order_id, cart_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_change; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_change (id, order_id, version, description, status, internal_note, created_by, requested_by, requested_at, confirmed_by, confirmed_at, declined_by, declined_reason, metadata, declined_at, canceled_by, canceled_at, created_at, updated_at, change_type, deleted_at, return_id, claim_id, exchange_id, carry_over_promotions) FROM stdin;
\.


--
-- Data for Name: order_change_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_change_action (id, order_id, version, ordering, order_change_id, reference, reference_id, action, details, amount, raw_amount, internal_note, applied, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: order_claim; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_claim (id, order_id, return_id, order_version, display_id, type, no_notification, refund_amount, raw_refund_amount, metadata, created_at, updated_at, deleted_at, canceled_at, created_by) FROM stdin;
\.


--
-- Data for Name: order_claim_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_claim_item (id, claim_id, item_id, is_additional_item, reason, quantity, raw_quantity, note, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_claim_item_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_claim_item_image (id, claim_item_id, url, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_credit_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_credit_line (id, order_id, reference, reference_id, amount, raw_amount, metadata, created_at, updated_at, deleted_at, version) FROM stdin;
\.


--
-- Data for Name: order_exchange; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_exchange (id, order_id, return_id, order_version, display_id, no_notification, allow_backorder, difference_due, raw_difference_due, metadata, created_at, updated_at, deleted_at, canceled_at, created_by) FROM stdin;
\.


--
-- Data for Name: order_exchange_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_exchange_item (id, exchange_id, item_id, quantity, raw_quantity, note, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_fulfillment (order_id, fulfillment_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_item (id, order_id, version, item_id, quantity, raw_quantity, fulfilled_quantity, raw_fulfilled_quantity, shipped_quantity, raw_shipped_quantity, return_requested_quantity, raw_return_requested_quantity, return_received_quantity, raw_return_received_quantity, return_dismissed_quantity, raw_return_dismissed_quantity, written_off_quantity, raw_written_off_quantity, metadata, created_at, updated_at, deleted_at, delivered_quantity, raw_delivered_quantity, unit_price, raw_unit_price, compare_at_unit_price, raw_compare_at_unit_price) FROM stdin;
\.


--
-- Data for Name: order_line_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_line_item (id, totals_id, title, subtitle, thumbnail, variant_id, product_id, product_title, product_description, product_subtitle, product_type, product_collection, product_handle, variant_sku, variant_barcode, variant_title, variant_option_values, requires_shipping, is_discountable, is_tax_inclusive, compare_at_unit_price, raw_compare_at_unit_price, unit_price, raw_unit_price, metadata, created_at, updated_at, deleted_at, is_custom_price, product_type_id, is_giftcard) FROM stdin;
\.


--
-- Data for Name: order_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_line_item_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, created_at, updated_at, item_id, deleted_at, is_tax_inclusive, version) FROM stdin;
\.


--
-- Data for Name: order_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_line_item_tax_line (id, description, tax_rate_id, code, rate, raw_rate, provider_id, created_at, updated_at, item_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_payment_collection (order_id, payment_collection_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_promotion (order_id, promotion_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_shipping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_shipping (id, order_id, version, shipping_method_id, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: order_shipping_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_shipping_method (id, name, description, amount, raw_amount, is_tax_inclusive, shipping_option_id, data, metadata, created_at, updated_at, deleted_at, is_custom_amount) FROM stdin;
\.


--
-- Data for Name: order_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_shipping_method_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, created_at, updated_at, shipping_method_id, deleted_at, version) FROM stdin;
\.


--
-- Data for Name: order_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_shipping_method_tax_line (id, description, tax_rate_id, code, rate, raw_rate, provider_id, created_at, updated_at, shipping_method_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_summary (id, order_id, version, totals, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_transaction (id, order_id, version, amount, raw_amount, currency_code, reference, reference_id, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment (id, amount, raw_amount, currency_code, provider_id, data, created_at, updated_at, deleted_at, captured_at, canceled_at, payment_collection_id, payment_session_id, metadata) FROM stdin;
\.


--
-- Data for Name: payment_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_collection (id, currency_code, amount, raw_amount, authorized_amount, raw_authorized_amount, captured_amount, raw_captured_amount, refunded_amount, raw_refunded_amount, created_at, updated_at, deleted_at, completed_at, status, metadata) FROM stdin;
\.


--
-- Data for Name: payment_collection_payment_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_collection_payment_providers (payment_collection_id, payment_provider_id) FROM stdin;
\.


--
-- Data for Name: payment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
pp_system_default	t	2026-07-18 08:40:11.537-07	2026-07-18 08:40:11.537-07	\N
\.


--
-- Data for Name: payment_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_session (id, currency_code, amount, raw_amount, provider_id, data, context, status, authorized_at, payment_collection_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price (id, title, price_set_id, currency_code, raw_amount, rules_count, created_at, updated_at, deleted_at, price_list_id, amount, min_quantity, max_quantity, raw_min_quantity, raw_max_quantity) FROM stdin;
price_01KXTY56XFHR8VXAE909KKR9NE	\N	pset_01KXTY56XGYTWCKQYM650MA4ER	inr	{"value": "199", "precision": 20}	0	2026-07-18 08:40:13.104-07	2026-07-18 08:40:13.104-07	\N	\N	199	\N	\N	\N	\N
price_01KXTY56XG6F0E63DDK2F3BZXH	\N	pset_01KXTY56XGYTWCKQYM650MA4ER	inr	{"value": "199", "precision": 20}	1	2026-07-18 08:40:13.105-07	2026-07-18 08:40:13.105-07	\N	\N	199	\N	\N	\N	\N
price_01KXTY5772K49X6PT5BGWR6VWD	\N	pset_01KXTY5772PMCXGWDTEQ210CJA	inr	{"value": "24999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	24999	\N	\N	\N	\N
price_01KXTY5772DWE9P9RFSCM2464Y	\N	pset_01KXTY5772YD0VHAV4Y08T7MZM	inr	{"value": "23999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	23999	\N	\N	\N	\N
price_01KXTY5773XDSPHGKSYYWVR00G	\N	pset_01KXTY57731DATKST5GR0K0FKA	inr	{"value": "26999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	26999	\N	\N	\N	\N
price_01KXTY5773G6VHTBP392H08QSC	\N	pset_01KXTY57736NKFEMYTETKA8P8D	inr	{"value": "16999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	16999	\N	\N	\N	\N
price_01KXTY577320W8X2NBRNM84QA6	\N	pset_01KXTY57738Y30MGWFPAJMW7Q2	inr	{"value": "15999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	15999	\N	\N	\N	\N
price_01KXTY5773XSP1F4F1ABK34N6Y	\N	pset_01KXTY5774C4PEHT3GSERVPP9B	inr	{"value": "9999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	9999	\N	\N	\N	\N
price_01KXTY57746NJYH6WW87YTF4YD	\N	pset_01KXTY57746F7NFZ7E4D7Q66GY	inr	{"value": "4999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	4999	\N	\N	\N	\N
price_01KXTY5774H665RYQ3N1M6J9Y7	\N	pset_01KXTY5774VK2SAEQ2MV5GJAFA	inr	{"value": "8999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	8999	\N	\N	\N	\N
price_01KXTY57743HKJXQ9ZW19RX858	\N	pset_01KXTY57754AJARD2GQ36SY7K5	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57754W4BA3NGYFDXPGP5	\N	pset_01KXTY5775VAJ9QPAB4DTT260Y	inr	{"value": "1999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	1999	\N	\N	\N	\N
price_01KXTY5775G9AFM8AGFZ17VDVF	\N	pset_01KXTY57758VNP696FEJR10886	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY5775K14PG7A8X8V50RZY	\N	pset_01KXTY57751J3G0RM2NVBA9T1Q	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY5775YMVNQ392KN53FKXR	\N	pset_01KXTY577538QPRHE5DSHMNV5H	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57761GQ9SSWKYT5J61FH	\N	pset_01KXTY5776DGBMX1GF0HZQZCVA	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57769H35KQHZ49Q5QAYV	\N	pset_01KXTY5776NX7NE7Q6QBJD2612	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57764DS38B58VRF98KKF	\N	pset_01KXTY5776X3WCJCY3QFYFGCED	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY5776WFZPVHKXH8QA15EN	\N	pset_01KXTY57764KFJAWMPQYJDNJR3	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57765E1YKY70N1ZERG67	\N	pset_01KXTY5776B6PSYEJ30SKV772G	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY5777580FQEKD6Q0K4TR9	\N	pset_01KXTY57774YT6TFP7RRPQQHVM	inr	{"value": "2999", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2999	\N	\N	\N	\N
price_01KXTY57774WDBQS36M6VKY29Q	\N	pset_01KXTY5777ZV2VHM9HAFD0523M	inr	{"value": "3299", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	3299	\N	\N	\N	\N
price_01KXTY57773W2W2RM1YSPC3K5Q	\N	pset_01KXTY5777HKRZX7HXWEK86Y6D	inr	{"value": "3299", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	3299	\N	\N	\N	\N
price_01KXTY5777N3C4JENZ3K807RXV	\N	pset_01KXTY5777WJPYGKEN710DKGH3	inr	{"value": "2499", "precision": 20}	0	2026-07-18 08:40:13.417-07	2026-07-18 08:40:13.417-07	\N	\N	2499	\N	\N	\N	\N
\.


--
-- Data for Name: price_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_list (id, status, starts_at, ends_at, rules_count, title, description, type, created_at, updated_at, deleted_at, metadata) FROM stdin;
\.


--
-- Data for Name: price_list_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_list_rule (id, price_list_id, created_at, updated_at, deleted_at, value, attribute) FROM stdin;
\.


--
-- Data for Name: price_preference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_preference (id, attribute, value, is_tax_inclusive, created_at, updated_at, deleted_at) FROM stdin;
prpref_01KXTY56RSPZNES5N1NVVP2KNG	currency_code	inr	f	2026-07-18 08:40:12.953-07	2026-07-18 08:40:12.953-07	\N
prpref_01KXTY56SRY9CM9PNKDC57C5MA	region_id	reg_01KXTY56S0Q5CK3WYP4X1MCP4B	f	2026-07-18 08:40:12.985-07	2026-07-18 08:40:12.985-07	\N
\.


--
-- Data for Name: price_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_rule (id, value, priority, price_id, created_at, updated_at, deleted_at, attribute, operator) FROM stdin;
prule_01KXTY56XFNYPE3CCY4KWSBBPK	reg_01KXTY56S0Q5CK3WYP4X1MCP4B	0	price_01KXTY56XG6F0E63DDK2F3BZXH	2026-07-18 08:40:13.105-07	2026-07-18 08:40:13.105-07	\N	region_id	eq
\.


--
-- Data for Name: price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_set (id, created_at, updated_at, deleted_at) FROM stdin;
pset_01KXTY56XGYTWCKQYM650MA4ER	2026-07-18 08:40:13.104-07	2026-07-18 08:40:13.104-07	\N
pset_01KXTY5772PMCXGWDTEQ210CJA	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5772YD0VHAV4Y08T7MZM	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57731DATKST5GR0K0FKA	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57736NKFEMYTETKA8P8D	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57738Y30MGWFPAJMW7Q2	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5774C4PEHT3GSERVPP9B	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57746F7NFZ7E4D7Q66GY	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5774VK2SAEQ2MV5GJAFA	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57754AJARD2GQ36SY7K5	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5775VAJ9QPAB4DTT260Y	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57758VNP696FEJR10886	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57751J3G0RM2NVBA9T1Q	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY577538QPRHE5DSHMNV5H	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5776DGBMX1GF0HZQZCVA	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5776NX7NE7Q6QBJD2612	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5776X3WCJCY3QFYFGCED	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57764KFJAWMPQYJDNJR3	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5776B6PSYEJ30SKV772G	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY57774YT6TFP7RRPQQHVM	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5777ZV2VHM9HAFD0523M	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5777HKRZX7HXWEK86Y6D	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
pset_01KXTY5777WJPYGKEN710DKGH3	2026-07-18 08:40:13.416-07	2026-07-18 08:40:13.416-07	\N
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product (id, title, handle, subtitle, description, is_giftcard, status, thumbnail, weight, length, height, width, origin_country, hs_code, mid_code, material, collection_id, type_id, discountable, external_id, created_at, updated_at, deleted_at, metadata) FROM stdin;
prod_01KXTY56ZYZN081XY0D7WPFF0K	Vintage	vintage	\N	The Vintage is a timeless Grade 1+ English Willow bat for the complete batsman. Each cleft is hand-picked and pressed for a big, forgiving sweet spot and a classic mid-profile that rewards orthodox stroke play. Balanced for an effortless pickup so you can drive, pull and cut with control through a long innings.	f	published	http://localhost:9000/static/products/vintage.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.202-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 50000, "badge": "Premium", "grade": "1+", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1180g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"40mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 1+ English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Round Cane\\"}]", "legacy_id": 1, "low_stock_threshold": 3}
prod_01KXTY56ZZ9AGNGFB5772Y95NE	Seven Horses Orange Players Edition	seven-horses-orange-players-edition	\N	The Seven Horses Orange Players Edition is built for the modern strokemaker. Premium Grade 1 English Willow, bold tournament-ready graphics and a mid-to-high middle deliver explosive power without sacrificing balance. The bat of choice when you want to dominate from ball one.	f	published	http://localhost:9000/static/products/seven-horses-orange-players-edition.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 45000, "badge": "Players Edition", "grade": "1", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1170g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid-High\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"42mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 1 English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Oval Cane\\"}]", "legacy_id": 2, "low_stock_threshold": 3}
prod_01KXTY56ZZR0YMF7DXY0AET7PX	MN7	mn7	\N	MN7 is our flagship — meticulously selected Grade 1+ English Willow, hand-pressed and balanced for elite players who demand the very best. A high middle, thick spine and clean grains combine for ping, power and pickup at the highest level of the game.	f	published	http://localhost:9000/static/products/mn7.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 69999, "badge": "Flagship", "grade": "1+", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1160g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"High\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"40mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"High\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 1+ English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Round Cane\\"}]", "legacy_id": 3, "low_stock_threshold": 3}
prod_01KXTY56ZZFVF244PE95K6S1DY	Original Grade Two	original-grade-two	\N	Honest, dependable performance from genuine Grade 2 English Willow. The Original Grade Two is built for serious match cricket — a balanced mid-profile, reliable middle and clean pickup make it a trustworthy companion across every format.	f	published	http://localhost:9000/static/products/original-grade-two.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 39999, "badge": null, "grade": "2", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1180g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"38mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 2 English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Round Cane\\"}]", "legacy_id": 4, "low_stock_threshold": 3}
prod_01KXTY56ZZJ281DQBMYY1MC6EA	Beast Grade 2	beast-grade-2	\N	Unleash the Beast. Thick-edged Grade 2 English Willow engineered for raw power and big hitting, with a low-to-mid sweet spot that punishes anything short. For the batsman who plays with intent and clears the ropes.	f	published	http://localhost:9000/static/products/beast-grade-2.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 27999, "badge": "Power", "grade": "2", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1200g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"44mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Low-Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 2 English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Oval Cane\\"}]", "legacy_id": 5, "low_stock_threshold": 3}
prod_01KXTY56ZZ0DSSSQY5EA2S63RT	Stallion	stallion	\N	The Stallion is a robust Grade 3 English Willow bat for intermediate players stepping up their game. Great pickup, a generous middle and dependable power help you graduate from the nets to match-day with confidence.	f	published	http://localhost:9000/static/products/stallion.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 16999, "badge": null, "grade": "3", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1180g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"38mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 3 English\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Round Cane\\"}]", "legacy_id": 6, "low_stock_threshold": 3}
prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	Black Edition	black-edition	\N	Stealthy looks, honest performance. The Black Edition is the perfect entry-level bat for net sessions and weekend cricket — light, well balanced and ready to play straight out of the wrapper.	f	published	http://localhost:9000/static/products/black-edition.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 7000, "badge": "Best Value", "grade": "4", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1170g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"36mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Kashmir Willow\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Round Cane\\"}]", "legacy_id": 7, "low_stock_threshold": 3}
prod_01KXTY56ZZM9EBR3YBV0D2HA4H	Hulk & County Edition	hulk-county-edition	\N	A true workhorse for club and academy players. The Hulk & County Edition is strong, balanced and built to take a beating session after session, giving developing batsmen a dependable bat at outstanding value.	f	published	http://localhost:9000/static/products/hulk-county-edition.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 12999, "badge": null, "grade": "4", "specs": "[{\\"k\\":\\"Weight\\",\\"v\\":\\"1190g\\"},{\\"k\\":\\"Pickup\\",\\"v\\":\\"Mid\\"},{\\"k\\":\\"Edge\\",\\"v\\":\\"38mm\\"},{\\"k\\":\\"Sweet Spot\\",\\"v\\":\\"Mid-Low\\"},{\\"k\\":\\"Willow\\",\\"v\\":\\"Grade 4 / Kashmir\\"},{\\"k\\":\\"Handle\\",\\"v\\":\\"Oval Cane\\"}]", "legacy_id": 8, "low_stock_threshold": 3}
prod_01KXTY56ZZWS0FZ66NT6X8W10S	Players Edition Pads	players-edition-pads	\N	Players Edition batting pads with lightweight, high-density foam protection and a flexible instep for quick running between the wickets. Premium PU facing and a three-strap velcro fit keep you protected and comfortable all innings. Available in Blue, Black, White and Gold.	f	published	http://localhost:9000/static/products/players-edition-pads.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.203-07	2026-07-18 08:40:13.203-07	\N	{"mrp": 5999, "badge": "Bestseller", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"720g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"High-density foam\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Blue / Black / White / Gold\\"}]", "legacy_id": 9, "low_stock_threshold": 3}
prod_01KXTY56ZZ5385W56FTM7337MG	Academy Pads	academy-pads	\N	Academy batting pads built for everyday training and net sessions. Comfortable, durable and well padded, they deliver excellent protection and value for developing cricketers putting in the hard yards.	f	published	http://localhost:9000/static/products/academy-pads.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 3999, "badge": null, "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"PU Synthetic\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"740g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Foam padding\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"White\\"}]", "legacy_id": 10, "low_stock_threshold": 3}
prod_01KXTY56ZZYF8ARCCMXBMSTPM5	Limited Edition Pads - Black	limited-edition-pads-black	\N	Blacked-out Limited Edition batting pads with dual-layer foam protection and premium strapping in a clean stealth finish. Lightweight, comfortable and built to stand out at the crease.	f	published	http://localhost:9000/static/products/limited-edition-pads-black.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"710g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Black\\"}]", "legacy_id": 11, "low_stock_threshold": 3}
prod_01KXTY56ZZMJ4393NXPWFGWHD4	Limited Edition Pads - Navy Blue	limited-edition-pads-navy-blue	\N	Deep navy Limited Edition batting pads with dual-layer foam protection and a sharp, modern look. Lightweight construction and a secure three-strap fit for confident running and reliable protection.	f	published	http://localhost:9000/static/products/limited-edition-pads-navy-blue.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"710g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Navy Blue\\"}]", "legacy_id": 12, "low_stock_threshold": 3}
prod_01KXTY56ZZFVQPW7BJVC3R0W00	Limited Edition Pads - Royal Blue	limited-edition-pads-royal-blue	\N	Striking royal blue Limited Edition batting pads that stand out at the crease. Dual-layer foam, premium PU facing and a comfortable three-strap fit combine protection with a bold look.	f	published	http://localhost:9000/static/products/limited-edition-pads-royal-blue.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"710g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Royal Blue\\"}]", "legacy_id": 13, "low_stock_threshold": 3}
prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	Limited Edition Pads - Black & Gold	limited-edition-pads-black-gold	\N	Ultimate luxury — black PU with gold accents in a strictly Limited Edition run. Dual-layer protection and premium strapping for the batsman who wants performance and presence.	f	published	http://localhost:9000/static/products/limited-edition-pads-black-gold.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"700g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Black / Gold\\"}]", "legacy_id": 14, "low_stock_threshold": 3}
prod_01KXTY56ZZ00D1KEQMEPBRGY16	Limited Edition Pads - Blue & Gold	limited-edition-pads-blue-gold	\N	Bold blue and gold Limited Edition batting pads with dual-layer protection and statement styling. Lightweight, secure and made to be noticed.	f	published	http://localhost:9000/static/products/limited-edition-pads-blue-gold.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"705g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Blue / Gold\\"}]", "legacy_id": 15, "low_stock_threshold": 3}
prod_01KXTY56ZZKQCY5YAP5M66E7AK	Limited Edition Pads - White & Gold	limited-edition-pads-white-gold	\N	Classic white with gold detailing in a Limited Edition finish. Dual-layer foam protection and a premium three-strap fit make these a clean, stylish choice for the modern batsman.	f	published	http://localhost:9000/static/products/limited-edition-pads-white-gold.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Limited", "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Full\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Weight\\",\\"v\\":\\"700g\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Dual-layer\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"White / Gold\\"}]", "legacy_id": 16, "low_stock_threshold": 3}
prod_01KXTY56ZZBWNKA6H14MRMGBDX	Original Gloves - Yellow	original-gloves-yellow	\N	Original batting gloves with a sweat-absorbent sheep-leather palm and high-density moulded finger protection. A pre-curved fit keeps your hands relaxed and ready. Bright yellow finish.	f	published	http://localhost:9000/static/products/original-gloves-yellow.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": null, "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Sheep Leather Palm\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Moulded foam\\"},{\\"k\\":\\"Fit\\",\\"v\\":\\"Pre-curved\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Yellow\\"}]", "legacy_id": 17, "low_stock_threshold": 3}
prod_01KXTY56ZZ97QDB8R5R659CY3C	Original Gloves - Green	original-gloves-green	\N	Original batting gloves with a sweat-absorbent sheep-leather palm and high-density moulded finger protection. Pre-curved for natural grip and comfort. Green finish.	f	published	http://localhost:9000/static/products/original-gloves-green.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": null, "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Sheep Leather Palm\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Moulded foam\\"},{\\"k\\":\\"Fit\\",\\"v\\":\\"Pre-curved\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Green\\"}]", "legacy_id": 18, "low_stock_threshold": 3}
prod_01KXTY5700S60ZXNK9ZN9S15YV	Original Gloves - Blue	original-gloves-blue	\N	Original batting gloves with a sweat-absorbent sheep-leather palm and high-density moulded finger protection. Pre-curved for a relaxed, ready grip. Blue finish.	f	published	http://localhost:9000/static/products/original-gloves-blue.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": null, "grade": null, "specs": "[{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Sheep Leather Palm\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Moulded foam\\"},{\\"k\\":\\"Fit\\",\\"v\\":\\"Pre-curved\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Blue\\"}]", "legacy_id": 19, "low_stock_threshold": 3}
prod_01KXTY5700XB2G4GK3RYXGFK9E	Keeping Gloves - Players Edition	keeping-gloves-players-edition	\N	International Players Edition wicket-keeping gloves with a premium catching mesh, towelling cuff and reinforced finger protection. Supple, well-padded and built for long days behind the stumps.	f	published	http://localhost:9000/static/products/keeping-gloves-players-edition.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Players Edition", "grade": null, "specs": "[{\\"k\\":\\"Type\\",\\"v\\":\\"Wicket-keeping\\"},{\\"k\\":\\"Size\\",\\"v\\":\\"Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Sheep Leather Palm\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Reinforced fingers\\"},{\\"k\\":\\"Cuff\\",\\"v\\":\\"Towelling\\"}]", "legacy_id": 20, "low_stock_threshold": 3}
prod_01KXTY5700G8RFWA7Z6BNB6DVJ	Keeping Pads - International Players Edition	keeping-pads-international-players-edition	\N	International Players Edition wicket-keeping pads — lightweight with a flexible instep and high-density protection for comfort and confidence over after over. Premium PU facing and a secure three-strap fit.	f	published	http://localhost:9000/static/products/keeping-pads-international-players-edition.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 4999, "badge": "Players Edition", "grade": null, "specs": "[{\\"k\\":\\"Type\\",\\"v\\":\\"Wicket-keeping\\"},{\\"k\\":\\"Size\\",\\"v\\":\\"Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"Premium PU\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"High-density foam\\"},{\\"k\\":\\"Straps\\",\\"v\\":\\"3-strap velcro\\"}]", "legacy_id": 21, "low_stock_threshold": 3}
prod_01KXTY5700FZAZ1SR2EGVQM4HY	Keeping Pads - Black & Blue	keeping-pads-black-blue	\N	Durable wicket-keeping pads in black and blue. Comfortable, well-padded protection built for academy and club keepers who need reliable performance at great value.	f	published	http://localhost:9000/static/products/keeping-pads-black-blue.jpg	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N	{"mrp": 3999, "badge": null, "grade": null, "specs": "[{\\"k\\":\\"Type\\",\\"v\\":\\"Wicket-keeping\\"},{\\"k\\":\\"Size\\",\\"v\\":\\"Youth / Mens\\"},{\\"k\\":\\"Material\\",\\"v\\":\\"PU Synthetic\\"},{\\"k\\":\\"Protection\\",\\"v\\":\\"Foam padding\\"},{\\"k\\":\\"Colour\\",\\"v\\":\\"Black / Blue\\"}]", "legacy_id": 22, "low_stock_threshold": 3}
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_category (id, name, description, handle, mpath, is_active, is_internal, rank, parent_category_id, created_at, updated_at, deleted_at, metadata, external_id) FROM stdin;
pcat_01KXTY56Z4M1CREEA6P2KYM2AE	Bats		bats	pcat_01KXTY56Z4M1CREEA6P2KYM2AE	t	f	0	\N	2026-07-18 08:40:13.157-07	2026-07-18 08:40:13.157-07	\N	\N	\N
pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2	Pads		pads	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2	t	f	1	\N	2026-07-18 08:40:13.157-07	2026-07-18 08:40:13.157-07	\N	\N	\N
pcat_01KXTY56Z5A270DC7TVG4GDA8S	Gloves		gloves	pcat_01KXTY56Z5A270DC7TVG4GDA8S	t	f	2	\N	2026-07-18 08:40:13.157-07	2026-07-18 08:40:13.157-07	\N	\N	\N
\.


--
-- Data for Name: product_category_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_category_product (product_id, product_category_id) FROM stdin;
prod_01KXTY56ZYZN081XY0D7WPFF0K	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZ9AGNGFB5772Y95NE	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZR0YMF7DXY0AET7PX	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZFVF244PE95K6S1DY	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZJ281DQBMYY1MC6EA	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZ0DSSSQY5EA2S63RT	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZM9EBR3YBV0D2HA4H	pcat_01KXTY56Z4M1CREEA6P2KYM2AE
prod_01KXTY56ZZWS0FZ66NT6X8W10S	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZ5385W56FTM7337MG	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZYF8ARCCMXBMSTPM5	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZMJ4393NXPWFGWHD4	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZFVQPW7BJVC3R0W00	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZ00D1KEQMEPBRGY16	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZKQCY5YAP5M66E7AK	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY56ZZBWNKA6H14MRMGBDX	pcat_01KXTY56Z5A270DC7TVG4GDA8S
prod_01KXTY56ZZ97QDB8R5R659CY3C	pcat_01KXTY56Z5A270DC7TVG4GDA8S
prod_01KXTY5700S60ZXNK9ZN9S15YV	pcat_01KXTY56Z5A270DC7TVG4GDA8S
prod_01KXTY5700XB2G4GK3RYXGFK9E	pcat_01KXTY56Z5A270DC7TVG4GDA8S
prod_01KXTY5700G8RFWA7Z6BNB6DVJ	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
prod_01KXTY5700FZAZ1SR2EGVQM4HY	pcat_01KXTY56Z4HN0MBSCAKBZEX3Q2
\.


--
-- Data for Name: product_collection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_collection (id, title, handle, metadata, created_at, updated_at, deleted_at, external_id) FROM stdin;
\.


--
-- Data for Name: product_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_option (id, title, product_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
opt_01KXTY5702KSGW06FK96VR24GF	Type	prod_01KXTY56ZYZN081XY0D7WPFF0K	\N	2026-07-18 08:40:13.204-07	2026-07-18 08:40:13.204-07	\N
opt_01KXTY5704G16BRTJC8HGPN1T7	Type	prod_01KXTY56ZZ9AGNGFB5772Y95NE	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5705CNZ4Y1TRKBFG1SV2	Type	prod_01KXTY56ZZR0YMF7DXY0AET7PX	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5706KFQV014JT961VQFE	Type	prod_01KXTY56ZZFVF244PE95K6S1DY	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5706MQ62MGZ0DDQFRE5X	Type	prod_01KXTY56ZZJ281DQBMYY1MC6EA	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5707JRV19TR6627DPM79	Type	prod_01KXTY56ZZ0DSSSQY5EA2S63RT	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5707WKZ7J50H9C2ZYQZP	Type	prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
opt_01KXTY5708CDAGJT5RRHB3T9AX	Type	prod_01KXTY56ZZM9EBR3YBV0D2HA4H	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY5709KYC6J65W2HVZAZ0A	Type	prod_01KXTY56ZZWS0FZ66NT6X8W10S	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570ABKF2A2G2YCKKVZZG	Type	prod_01KXTY56ZZ5385W56FTM7337MG	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570A00RYJF8G3AWDSY5W	Type	prod_01KXTY56ZZYF8ARCCMXBMSTPM5	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570B8SK355HM75H87NT3	Type	prod_01KXTY56ZZMJ4393NXPWFGWHD4	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570BJ15FX6TYHXNZHHQ6	Type	prod_01KXTY56ZZFVQPW7BJVC3R0W00	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570CSTSQRGARYSAKNRPJ	Type	prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570DT2ECBXSXWM74E12S	Type	prod_01KXTY56ZZ00D1KEQMEPBRGY16	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570DK651D8MT1VR3D614	Type	prod_01KXTY56ZZKQCY5YAP5M66E7AK	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570ER9VQ6NYG3GAFCGSH	Type	prod_01KXTY56ZZBWNKA6H14MRMGBDX	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570ERXF6H43JEPEEPS29	Type	prod_01KXTY56ZZ97QDB8R5R659CY3C	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570F47NF8AJBG4T2J0HS	Type	prod_01KXTY5700S60ZXNK9ZN9S15YV	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
opt_01KXTY570FSK0VFV1HQC5SWQAH	Type	prod_01KXTY5700XB2G4GK3RYXGFK9E	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
opt_01KXTY570GNER5ZM0K5ETEKT9Y	Type	prod_01KXTY5700G8RFWA7Z6BNB6DVJ	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
opt_01KXTY570GQD6J0B4W6YS3ERWC	Type	prod_01KXTY5700FZAZ1SR2EGVQM4HY	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
\.


--
-- Data for Name: product_option_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_option_value (id, value, option_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
optval_01KXTY5702SXKXQ40G2YGKXMTN	Standard	opt_01KXTY5702KSGW06FK96VR24GF	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY5704MTXNH6NVDCSG9BZF	Standard	opt_01KXTY5704G16BRTJC8HGPN1T7	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY5705JQGXAPA86CTXMM8Z	Standard	opt_01KXTY5705CNZ4Y1TRKBFG1SV2	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY57053Q8TAYJXQ2PSBKN8	Standard	opt_01KXTY5706KFQV014JT961VQFE	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY5706WJGN9K8ZR98N042N	Standard	opt_01KXTY5706MQ62MGZ0DDQFRE5X	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY5707PFS1PTX6B758TR40	Standard	opt_01KXTY5707JRV19TR6627DPM79	\N	2026-07-18 08:40:13.205-07	2026-07-18 08:40:13.205-07	\N
optval_01KXTY570731GCPQ4EPS94PASV	Standard	opt_01KXTY5707WKZ7J50H9C2ZYQZP	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY5708TEAPXPTFQKDV4EQ2	Standard	opt_01KXTY5708CDAGJT5RRHB3T9AX	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY57086QCQ866KZPCQF6A9	Standard	opt_01KXTY5709KYC6J65W2HVZAZ0A	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570AW4A2RV7YFKHZHDYP	Standard	opt_01KXTY570ABKF2A2G2YCKKVZZG	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570A1FS3H8QTRCNMN6YH	Standard	opt_01KXTY570A00RYJF8G3AWDSY5W	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570BJ7F18M2FK4SMCWW4	Standard	opt_01KXTY570B8SK355HM75H87NT3	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570BW6HWNFG3NJ750ET2	Standard	opt_01KXTY570BJ15FX6TYHXNZHHQ6	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570CR0C0J6YCE5AQHM28	Standard	opt_01KXTY570CSTSQRGARYSAKNRPJ	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570CR8V08R62K8WGPQ6J	Standard	opt_01KXTY570DT2ECBXSXWM74E12S	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570D52FV8B9XYRVF7NNW	Standard	opt_01KXTY570DK651D8MT1VR3D614	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570EHAQD07BQE5TD2WAV	Standard	opt_01KXTY570ER9VQ6NYG3GAFCGSH	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570ED86AJSRH5FPCJT31	Standard	opt_01KXTY570ERXF6H43JEPEEPS29	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570FH9C1KEAC9TH49YNA	Standard	opt_01KXTY570F47NF8AJBG4T2J0HS	\N	2026-07-18 08:40:13.206-07	2026-07-18 08:40:13.206-07	\N
optval_01KXTY570F64CV04821GAJ2JBQ	Standard	opt_01KXTY570FSK0VFV1HQC5SWQAH	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
optval_01KXTY570GZMA1FYCFB2YQGP2D	Standard	opt_01KXTY570GNER5ZM0K5ETEKT9Y	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
optval_01KXTY570GAANQFFTKX0WZVEJY	Standard	opt_01KXTY570GQD6J0B4W6YS3ERWC	\N	2026-07-18 08:40:13.207-07	2026-07-18 08:40:13.207-07	\N
\.


--
-- Data for Name: product_sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_sales_channel (product_id, sales_channel_id, id, created_at, updated_at, deleted_at) FROM stdin;
prod_01KXTY56ZYZN081XY0D7WPFF0K	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572TA4VRK50RS2M17FWE	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZYZN081XY0D7WPFF0K	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572T9YGZ1FJZCWCD2ACN	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ9AGNGFB5772Y95NE	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572TSY8GFXF2JGWPNHG0	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ9AGNGFB5772Y95NE	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572VYSKKFXH6RBTPYTBV	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZR0YMF7DXY0AET7PX	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572VRQ6B8X0SQ3DT3G70	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZR0YMF7DXY0AET7PX	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572VMEK5CD3T7Q6AEN7W	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZFVF244PE95K6S1DY	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572VGR6RECT8YM125HZC	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZFVF244PE95K6S1DY	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572V7392WER946NBATWV	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZJ281DQBMYY1MC6EA	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572VS2BHF1B1SQN9AV3T	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZJ281DQBMYY1MC6EA	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572V1MFN00HSP85Y22WH	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ0DSSSQY5EA2S63RT	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572VP4C56VFYNJ070DHV	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ0DSSSQY5EA2S63RT	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572WB510MAHF75RFSXF8	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572WCQCHJW01QNXBMW7D	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572W9NR9NQC84GSRCSMP	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZM9EBR3YBV0D2HA4H	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572WYPFSX40763DP2SGX	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZM9EBR3YBV0D2HA4H	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572WZ3F7G6BZS1559PPN	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZWS0FZ66NT6X8W10S	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572WVNZ317ATXA9P924D	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZWS0FZ66NT6X8W10S	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572WYPGAR143K2VJWFC6	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ5385W56FTM7337MG	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572WZM8WN14RNPK6WRYA	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ5385W56FTM7337MG	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572WP2XKGMXHX7JVXFTC	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZYF8ARCCMXBMSTPM5	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572X9CC3FFVPNJ4H560X	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZYF8ARCCMXBMSTPM5	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572XQZ18GBV3C919YJCJ	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZMJ4393NXPWFGWHD4	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572XC8YC9H10T9NR77EF	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZMJ4393NXPWFGWHD4	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572XHYK0069YG2V2N3QQ	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZFVQPW7BJVC3R0W00	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572XES2WJ7CC2Z0QK9EF	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZFVQPW7BJVC3R0W00	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572XF70G602T14022CFT	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572X48GMJYYQPZ1V7WJJ	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572XWNV10Y2VBK4SKMVZ	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ00D1KEQMEPBRGY16	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572XS485ARS1P43P2SHM	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ00D1KEQMEPBRGY16	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572X1RD22QN1B35R24MR	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZKQCY5YAP5M66E7AK	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572Y715K8Q10JHCQH5WA	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZKQCY5YAP5M66E7AK	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572YQKCVDFPFTBJ5KSX4	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZBWNKA6H14MRMGBDX	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572YR5Z7QJNDA3BS7NX9	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZBWNKA6H14MRMGBDX	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572YQFAAG1HMMCHAERWA	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ97QDB8R5R659CY3C	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572YG3R1TX8VTD6GQ3KW	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY56ZZ97QDB8R5R659CY3C	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572YV33VJY4FRSD6VJY4	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700S60ZXNK9ZN9S15YV	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572YTBEAX3W2M07ZM35B	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700S60ZXNK9ZN9S15YV	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572Y8ANBY285HT93HKDB	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700XB2G4GK3RYXGFK9E	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572YJQK07R475ZQMD94P	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700XB2G4GK3RYXGFK9E	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572Y6K3V9HC42G6GHAHZ	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700G8RFWA7Z6BNB6DVJ	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572Z8CKX2XVD0PGT7V6K	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700G8RFWA7Z6BNB6DVJ	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572ZCG9TF9PQWRNBAVVN	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700FZAZ1SR2EGVQM4HY	sc_01KXTY56Q47ATGPEMAKJ32XAGN	prodsc_01KXTY572ZRF1ER7ZSC255RT32	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
prod_01KXTY5700FZAZ1SR2EGVQM4HY	sc_01KXTY56Q4N0G59MDZSHFDFW60	prodsc_01KXTY572Z6C5D09CNED065PJB	2026-07-18 08:40:13.266695-07	2026-07-18 08:40:13.266695-07	\N
\.


--
-- Data for Name: product_shipping_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_shipping_profile (product_id, shipping_profile_id, id, created_at, updated_at, deleted_at) FROM stdin;
prod_01KXTY56ZYZN081XY0D7WPFF0K	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573NWZMX7M678RW3CHRH	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ9AGNGFB5772Y95NE	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573N7XJXDRG0C24087AB	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZR0YMF7DXY0AET7PX	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573NVG17PNF5Q78SDPFK	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZFVF244PE95K6S1DY	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573P8Z3XX705QK7Q94DP	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZJ281DQBMYY1MC6EA	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573PGYFR0V6KPCRCM2S0	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ0DSSSQY5EA2S63RT	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573PYPA8DEN1PC5X8S66	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573PTMV1E3F09BZZH1H5	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZM9EBR3YBV0D2HA4H	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573PAZ7J9S1234CPX4YZ	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZWS0FZ66NT6X8W10S	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573P84SM4MYY4CWC4G9Z	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ5385W56FTM7337MG	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573PBXQK8T5Y7C6Z1E8N	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZYF8ARCCMXBMSTPM5	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573P0VNZ5X12XGM9TPN4	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZMJ4393NXPWFGWHD4	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573Q0V449RNYGPZQCK5X	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZFVQPW7BJVC3R0W00	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573QGN88HGDJTYEQVGQG	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573QC3VKC1VQR6MN2VS4	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ00D1KEQMEPBRGY16	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573QWXNV5Z8SF3TK8PBW	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZKQCY5YAP5M66E7AK	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573Q4K1EPM813CV1DJA2	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZBWNKA6H14MRMGBDX	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573Q6HGD0CGEW5BMFHBX	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY56ZZ97QDB8R5R659CY3C	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573QXAFYNRH4KMS99EX9	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY5700S60ZXNK9ZN9S15YV	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573Q91FCD3E26TTWVYJ5	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY5700XB2G4GK3RYXGFK9E	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573Q8JXHP6TQKDAE42QY	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY5700G8RFWA7Z6BNB6DVJ	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573RJ63BPACQXAB3YZZD	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
prod_01KXTY5700FZAZ1SR2EGVQM4HY	sp_01KXTY56N8YHHCCQTB752NFN7W	prodsp_01KXTY573RB76JK9CJF9SXDDR5	2026-07-18 08:40:13.300845-07	2026-07-18 08:40:13.300845-07	\N
\.


--
-- Data for Name: product_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_tag (id, value, metadata, created_at, updated_at, deleted_at, external_id) FROM stdin;
\.


--
-- Data for Name: product_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_tags (product_id, product_tag_id) FROM stdin;
\.


--
-- Data for Name: product_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_type (id, value, metadata, created_at, updated_at, deleted_at, external_id) FROM stdin;
\.


--
-- Data for Name: product_variant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant (id, title, sku, barcode, ean, upc, allow_backorder, manage_inventory, hs_code, origin_country, mid_code, material, weight, length, height, width, metadata, variant_rank, product_id, created_at, updated_at, deleted_at, thumbnail) FROM stdin;
variant_01KXTY574SHPQ6XZ61A7H7TBDB	Vintage	OC-1	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZYZN081XY0D7WPFF0K	2026-07-18 08:40:13.343-07	2026-07-18 08:40:13.343-07	\N	\N
variant_01KXTY574T3SNF4Q91R7G9R3RG	Seven Horses Orange Players Edition	OC-2	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ9AGNGFB5772Y95NE	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574TANYGB8TPDWJDBHKZ	MN7	OC-3	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZR0YMF7DXY0AET7PX	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574TJEMJCKG8D7AV2Z37	Original Grade Two	OC-4	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZFVF244PE95K6S1DY	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574T0R1PE1BJXCP5CN6M	Beast Grade 2	OC-5	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZJ281DQBMYY1MC6EA	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574VEFQ4NJJ12V0CZSDK	Stallion	OC-6	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ0DSSSQY5EA2S63RT	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574V4GKG4XT6CETND6QV	Black Edition	OC-7	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZSN0D7Y7WJ7K5KDQG	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574VDAA5WD4Y35HBDQJM	Hulk & County Edition	OC-8	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZM9EBR3YBV0D2HA4H	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574WNT7FNT49QAY5TCDS	Players Edition Pads	OC-9	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZWS0FZ66NT6X8W10S	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574W5S1TS8TH7496RBPR	Academy Pads	OC-10	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ5385W56FTM7337MG	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574WBVV235CW49WPEKKZ	Limited Edition Pads - Black	OC-11	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZYF8ARCCMXBMSTPM5	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574WCN3SD6VJJR073AJJ	Limited Edition Pads - Navy Blue	OC-12	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZMJ4393NXPWFGWHD4	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574X0B76591VR00JQ92Q	Limited Edition Pads - Royal Blue	OC-13	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZFVQPW7BJVC3R0W00	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574XH8D4EQGSD4BRBRGA	Limited Edition Pads - Black & Gold	OC-14	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ3G7Y8PDNMV56KDR8	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574XFNZ6JZ0RQFK3P4QY	Limited Edition Pads - Blue & Gold	OC-15	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ00D1KEQMEPBRGY16	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574XWV1ZGQ9VYD3H47FC	Limited Edition Pads - White & Gold	OC-16	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZKQCY5YAP5M66E7AK	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574XR7X6NHE59WTDWJ3D	Original Gloves - Yellow	OC-17	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZBWNKA6H14MRMGBDX	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574XFQWTT716TBTEYJMT	Original Gloves - Green	OC-18	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY56ZZ97QDB8R5R659CY3C	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574Y16Y7B91QZ20MZZNB	Original Gloves - Blue	OC-19	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY5700S60ZXNK9ZN9S15YV	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574YTNBNTPCR4ED1DKGP	Keeping Gloves - Players Edition	OC-20	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY5700XB2G4GK3RYXGFK9E	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574YD234M5H2DDR0ACRD	Keeping Pads - International Players Edition	OC-21	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY5700G8RFWA7Z6BNB6DVJ	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
variant_01KXTY574YK1NN5Z1SVN23T572	Keeping Pads - Black & Blue	OC-22	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01KXTY5700FZAZ1SR2EGVQM4HY	2026-07-18 08:40:13.344-07	2026-07-18 08:40:13.344-07	\N	\N
\.


--
-- Data for Name: product_variant_inventory_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_inventory_item (variant_id, inventory_item_id, id, required_quantity, created_at, updated_at, deleted_at) FROM stdin;
variant_01KXTY574SHPQ6XZ61A7H7TBDB	iitem_01KXTY575YTWRMK6AX9CT4BYPV	pvitem_01KXTY576MV4VTBHV8RMWB1DR7	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574T3SNF4Q91R7G9R3RG	iitem_01KXTY575Y5QD0Q81CX1AGF20K	pvitem_01KXTY576N4PA10EJJ6ZHDXRPX	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574TANYGB8TPDWJDBHKZ	iitem_01KXTY575Y9AZRVCA15YVEQNTJ	pvitem_01KXTY576NSGJ8KHFR4PB47M1N	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574TJEMJCKG8D7AV2Z37	iitem_01KXTY575YNM2BB0C2NJ30267V	pvitem_01KXTY576NDWKJXWBBCRSVXD83	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574T0R1PE1BJXCP5CN6M	iitem_01KXTY575YXMRXV492Y2X4SM6X	pvitem_01KXTY576NS79YKT643XZB58VH	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574VEFQ4NJJ12V0CZSDK	iitem_01KXTY575Z7KR8V1E0S828WMJS	pvitem_01KXTY576NG48FASXP04PRV4AD	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574V4GKG4XT6CETND6QV	iitem_01KXTY575Z7G2TW5GVMWX9QDMN	pvitem_01KXTY576PHFGJYCH1NVT71B09	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574VDAA5WD4Y35HBDQJM	iitem_01KXTY575ZGPW4SJDHBNNZ9CNE	pvitem_01KXTY576PVSHMFZF1BSHR7PTZ	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574WNT7FNT49QAY5TCDS	iitem_01KXTY575Z1S0TMV8XBHWYGGD2	pvitem_01KXTY576PV8R32AV2EE0VTTZ9	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574W5S1TS8TH7496RBPR	iitem_01KXTY575Z1Y2X9K9VRVGWSTC1	pvitem_01KXTY576PNPFEXDVB2H182D2Z	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574WBVV235CW49WPEKKZ	iitem_01KXTY575Z808C1YZZDNGA5VAR	pvitem_01KXTY576PFJNS3TS7VZ4P8H20	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574WCN3SD6VJJR073AJJ	iitem_01KXTY575ZRZV5NM202690W7TK	pvitem_01KXTY576PV87J4ECTVKV26V4A	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574X0B76591VR00JQ92Q	iitem_01KXTY575ZZ33BDARV4R0MHC20	pvitem_01KXTY576P00SXWPNZ7RH6WSY0	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574XH8D4EQGSD4BRBRGA	iitem_01KXTY575ZXAED39PHXAR4GMB6	pvitem_01KXTY576PV7W1SMF2VWNCT7N5	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574XFNZ6JZ0RQFK3P4QY	iitem_01KXTY5760S64MHMDJ1F8JVKTX	pvitem_01KXTY576QGH21K223DGK2N9W0	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574XWV1ZGQ9VYD3H47FC	iitem_01KXTY5760SHEKQ5WRWXSJ2TFW	pvitem_01KXTY576QDP4RZAF5AV8NXK9D	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574XR7X6NHE59WTDWJ3D	iitem_01KXTY57604Q07RBPEGE5HKAT0	pvitem_01KXTY576QHMVDPAHZBCBZBY6W	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574XFQWTT716TBTEYJMT	iitem_01KXTY5760ENC2AGHPA5EAD5AJ	pvitem_01KXTY576Q5ME4KSBHS3ZQSCNA	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574Y16Y7B91QZ20MZZNB	iitem_01KXTY5760BYZGHG88DXTQ2Y6W	pvitem_01KXTY576QMP9832FAW4KS8DEY	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574YTNBNTPCR4ED1DKGP	iitem_01KXTY57602JDFYZ7R1GZMKJ4Q	pvitem_01KXTY576QQZJ5170798QWJ0TA	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574YD234M5H2DDR0ACRD	iitem_01KXTY5760610GHKN9DSSNG6ES	pvitem_01KXTY576QGM4AYXZBZZMY8FKW	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
variant_01KXTY574YK1NN5Z1SVN23T572	iitem_01KXTY57608B4YYCMVWFHW69H2	pvitem_01KXTY576QBWKAZQ1K39ZEA7VE	1	2026-07-18 08:40:13.396466-07	2026-07-18 08:40:13.396466-07	\N
\.


--
-- Data for Name: product_variant_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_option (variant_id, option_value_id) FROM stdin;
variant_01KXTY574SHPQ6XZ61A7H7TBDB	optval_01KXTY5702SXKXQ40G2YGKXMTN
variant_01KXTY574T3SNF4Q91R7G9R3RG	optval_01KXTY5704MTXNH6NVDCSG9BZF
variant_01KXTY574TANYGB8TPDWJDBHKZ	optval_01KXTY5705JQGXAPA86CTXMM8Z
variant_01KXTY574TJEMJCKG8D7AV2Z37	optval_01KXTY57053Q8TAYJXQ2PSBKN8
variant_01KXTY574T0R1PE1BJXCP5CN6M	optval_01KXTY5706WJGN9K8ZR98N042N
variant_01KXTY574VEFQ4NJJ12V0CZSDK	optval_01KXTY5707PFS1PTX6B758TR40
variant_01KXTY574V4GKG4XT6CETND6QV	optval_01KXTY570731GCPQ4EPS94PASV
variant_01KXTY574VDAA5WD4Y35HBDQJM	optval_01KXTY5708TEAPXPTFQKDV4EQ2
variant_01KXTY574WNT7FNT49QAY5TCDS	optval_01KXTY57086QCQ866KZPCQF6A9
variant_01KXTY574W5S1TS8TH7496RBPR	optval_01KXTY570AW4A2RV7YFKHZHDYP
variant_01KXTY574WBVV235CW49WPEKKZ	optval_01KXTY570A1FS3H8QTRCNMN6YH
variant_01KXTY574WCN3SD6VJJR073AJJ	optval_01KXTY570BJ7F18M2FK4SMCWW4
variant_01KXTY574X0B76591VR00JQ92Q	optval_01KXTY570BW6HWNFG3NJ750ET2
variant_01KXTY574XH8D4EQGSD4BRBRGA	optval_01KXTY570CR0C0J6YCE5AQHM28
variant_01KXTY574XFNZ6JZ0RQFK3P4QY	optval_01KXTY570CR8V08R62K8WGPQ6J
variant_01KXTY574XWV1ZGQ9VYD3H47FC	optval_01KXTY570D52FV8B9XYRVF7NNW
variant_01KXTY574XR7X6NHE59WTDWJ3D	optval_01KXTY570EHAQD07BQE5TD2WAV
variant_01KXTY574XFQWTT716TBTEYJMT	optval_01KXTY570ED86AJSRH5FPCJT31
variant_01KXTY574Y16Y7B91QZ20MZZNB	optval_01KXTY570FH9C1KEAC9TH49YNA
variant_01KXTY574YTNBNTPCR4ED1DKGP	optval_01KXTY570F64CV04821GAJ2JBQ
variant_01KXTY574YD234M5H2DDR0ACRD	optval_01KXTY570GZMA1FYCFB2YQGP2D
variant_01KXTY574YK1NN5Z1SVN23T572	optval_01KXTY570GAANQFFTKX0WZVEJY
\.


--
-- Data for Name: product_variant_price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_price_set (variant_id, price_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
variant_01KXTY574SHPQ6XZ61A7H7TBDB	pset_01KXTY5772PMCXGWDTEQ210CJA	pvps_01KXTY578AD0E5N4S2NE5FZGKX	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574T3SNF4Q91R7G9R3RG	pset_01KXTY5772YD0VHAV4Y08T7MZM	pvps_01KXTY578A7876RF6JH786CKFK	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574TANYGB8TPDWJDBHKZ	pset_01KXTY57731DATKST5GR0K0FKA	pvps_01KXTY578AQ3XR1DJGJKK2CXDK	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574TJEMJCKG8D7AV2Z37	pset_01KXTY57736NKFEMYTETKA8P8D	pvps_01KXTY578BYTX87BS6JCE9GVWG	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574T0R1PE1BJXCP5CN6M	pset_01KXTY57738Y30MGWFPAJMW7Q2	pvps_01KXTY578BEAGWBP77K90WBQZY	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574VEFQ4NJJ12V0CZSDK	pset_01KXTY5774C4PEHT3GSERVPP9B	pvps_01KXTY578BNJ8XV9RY6C1Q3JVR	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574V4GKG4XT6CETND6QV	pset_01KXTY57746F7NFZ7E4D7Q66GY	pvps_01KXTY578B9GW802W2S3KA7G5Z	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574VDAA5WD4Y35HBDQJM	pset_01KXTY5774VK2SAEQ2MV5GJAFA	pvps_01KXTY578BK391A7VBKV471DY7	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574WNT7FNT49QAY5TCDS	pset_01KXTY57754AJARD2GQ36SY7K5	pvps_01KXTY578BP1G8H6Y0ZM1EDJWK	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574W5S1TS8TH7496RBPR	pset_01KXTY5775VAJ9QPAB4DTT260Y	pvps_01KXTY578BW5BVN9NRVCEAH9H7	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574WBVV235CW49WPEKKZ	pset_01KXTY57758VNP696FEJR10886	pvps_01KXTY578BNNS6P4KB0HFRWENH	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574WCN3SD6VJJR073AJJ	pset_01KXTY57751J3G0RM2NVBA9T1Q	pvps_01KXTY578C0H0CHG6Y6YN6Q604	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574X0B76591VR00JQ92Q	pset_01KXTY577538QPRHE5DSHMNV5H	pvps_01KXTY578CFTQZZW3TV32YY0A3	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574XH8D4EQGSD4BRBRGA	pset_01KXTY5776DGBMX1GF0HZQZCVA	pvps_01KXTY578CAM6E4NVFB1Y69WT0	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574XFNZ6JZ0RQFK3P4QY	pset_01KXTY5776NX7NE7Q6QBJD2612	pvps_01KXTY578C3G5P30WPAPBSDPAE	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574XWV1ZGQ9VYD3H47FC	pset_01KXTY5776X3WCJCY3QFYFGCED	pvps_01KXTY578CN6BN6T7GT9CNDE8N	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574XR7X6NHE59WTDWJ3D	pset_01KXTY57764KFJAWMPQYJDNJR3	pvps_01KXTY578C5JH9NFP11FK7MXX6	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574XFQWTT716TBTEYJMT	pset_01KXTY5776B6PSYEJ30SKV772G	pvps_01KXTY578CW2WWQA4F2MCP5M80	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574Y16Y7B91QZ20MZZNB	pset_01KXTY57774YT6TFP7RRPQQHVM	pvps_01KXTY578C193NEC6C0FTZG00J	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574YTNBNTPCR4ED1DKGP	pset_01KXTY5777ZV2VHM9HAFD0523M	pvps_01KXTY578C47GQC7PDCHE3MPJ6	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574YD234M5H2DDR0ACRD	pset_01KXTY5777HKRZX7HXWEK86Y6D	pvps_01KXTY578CV07PK3D2N12GHYZZ	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
variant_01KXTY574YK1NN5Z1SVN23T572	pset_01KXTY5777WJPYGKEN710DKGH3	pvps_01KXTY578D04G8K6F2MDET4QYC	2026-07-18 08:40:13.449933-07	2026-07-18 08:40:13.449933-07	\N
\.


--
-- Data for Name: product_variant_product_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_product_image (id, variant_id, image_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion (id, code, campaign_id, is_automatic, type, created_at, updated_at, deleted_at, status, is_tax_inclusive, "limit", used, metadata) FROM stdin;
\.


--
-- Data for Name: promotion_application_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_application_method (id, value, raw_value, max_quantity, apply_to_quantity, buy_rules_min_quantity, type, target_type, allocation, promotion_id, created_at, updated_at, deleted_at, currency_code) FROM stdin;
\.


--
-- Data for Name: promotion_campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_campaign (id, name, description, campaign_identifier, starts_at, ends_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion_campaign_budget; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_campaign_budget (id, type, campaign_id, "limit", raw_limit, used, raw_used, created_at, updated_at, deleted_at, currency_code, attribute) FROM stdin;
\.


--
-- Data for Name: promotion_campaign_budget_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_campaign_budget_usage (id, attribute_value, used, budget_id, raw_used, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion_promotion_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_promotion_rule (promotion_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: promotion_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_rule (id, description, attribute, operator, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion_rule_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promotion_rule_value (id, promotion_rule_id, value, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: property_label; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.property_label (id, entity, property, label, description, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: provider_identity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_identity (id, entity_id, provider, auth_identity_id, user_metadata, provider_metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: publishable_api_key_sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.publishable_api_key_sales_channel (publishable_key_id, sales_channel_id, id, created_at, updated_at, deleted_at) FROM stdin;
apk_01KXTY56QD07ZFTYD3K4Z8XMT1	sc_01KXTY56Q47ATGPEMAKJ32XAGN	pksc_01KXTY56QVZZ55KZK7FVCTBP36	2026-07-18 08:40:12.922443-07	2026-07-18 08:40:12.922443-07	\N
\.


--
-- Data for Name: refund; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund (id, amount, raw_amount, payment_id, created_at, updated_at, deleted_at, created_by, metadata, refund_reason_id, note) FROM stdin;
\.


--
-- Data for Name: refund_reason; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refund_reason (id, label, description, metadata, created_at, updated_at, deleted_at, code) FROM stdin;
refr_01KXTY4ZWNVJF7APKA2DPMP5AA	Shipping Issue	Refund due to lost, delayed, or misdelivered shipment	\N	2026-07-18 08:40:05.781593-07	2026-07-18 08:40:05.781593-07	\N	shipping_issue
refr_01KXTY4ZWNPPBPAFCZRNJEPMNR	Customer Care Adjustment	Refund given as goodwill or compensation for inconvenience	\N	2026-07-18 08:40:05.781593-07	2026-07-18 08:40:05.781593-07	\N	customer_care_adjustment
refr_01KXTY4ZWN9K8RZ59XDNF4ANJ7	Pricing Error	Refund to correct an overcharge, missing discount, or incorrect price	\N	2026-07-18 08:40:05.781593-07	2026-07-18 08:40:05.781593-07	\N	pricing_error
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.region (id, name, currency_code, metadata, created_at, updated_at, deleted_at, automatic_taxes) FROM stdin;
reg_01KXTY56S0Q5CK3WYP4X1MCP4B	India	inr	\N	2026-07-18 08:40:12.968-07	2026-07-18 08:40:12.968-07	\N	t
\.


--
-- Data for Name: region_country; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.region_country (iso_2, iso_3, num_code, name, display_name, region_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
af	afg	004	AFGHANISTAN	Afghanistan	\N	\N	2026-07-18 08:40:11.454-07	2026-07-18 08:40:11.454-07	\N
al	alb	008	ALBANIA	Albania	\N	\N	2026-07-18 08:40:11.455-07	2026-07-18 08:40:11.455-07	\N
dz	dza	012	ALGERIA	Algeria	\N	\N	2026-07-18 08:40:11.455-07	2026-07-18 08:40:11.455-07	\N
as	asm	016	AMERICAN SAMOA	American Samoa	\N	\N	2026-07-18 08:40:11.455-07	2026-07-18 08:40:11.455-07	\N
ad	and	020	ANDORRA	Andorra	\N	\N	2026-07-18 08:40:11.455-07	2026-07-18 08:40:11.455-07	\N
ao	ago	024	ANGOLA	Angola	\N	\N	2026-07-18 08:40:11.455-07	2026-07-18 08:40:11.455-07	\N
ai	aia	660	ANGUILLA	Anguilla	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
aq	ata	010	ANTARCTICA	Antarctica	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ag	atg	028	ANTIGUA AND BARBUDA	Antigua and Barbuda	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ar	arg	032	ARGENTINA	Argentina	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
am	arm	051	ARMENIA	Armenia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
aw	abw	533	ARUBA	Aruba	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
au	aus	036	AUSTRALIA	Australia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
at	aut	040	AUSTRIA	Austria	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
az	aze	031	AZERBAIJAN	Azerbaijan	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bs	bhs	044	BAHAMAS	Bahamas	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bh	bhr	048	BAHRAIN	Bahrain	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bd	bgd	050	BANGLADESH	Bangladesh	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bb	brb	052	BARBADOS	Barbados	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
by	blr	112	BELARUS	Belarus	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
be	bel	056	BELGIUM	Belgium	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bz	blz	084	BELIZE	Belize	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bj	ben	204	BENIN	Benin	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bm	bmu	060	BERMUDA	Bermuda	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bt	btn	064	BHUTAN	Bhutan	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bo	bol	068	BOLIVIA	Bolivia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bq	bes	535	BONAIRE, SINT EUSTATIUS AND SABA	Bonaire, Sint Eustatius and Saba	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ba	bih	070	BOSNIA AND HERZEGOVINA	Bosnia and Herzegovina	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bw	bwa	072	BOTSWANA	Botswana	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bv	bvd	074	BOUVET ISLAND	Bouvet Island	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
br	bra	076	BRAZIL	Brazil	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
io	iot	086	BRITISH INDIAN OCEAN TERRITORY	British Indian Ocean Territory	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bn	brn	096	BRUNEI DARUSSALAM	Brunei Darussalam	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bg	bgr	100	BULGARIA	Bulgaria	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bf	bfa	854	BURKINA FASO	Burkina Faso	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
bi	bdi	108	BURUNDI	Burundi	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
kh	khm	116	CAMBODIA	Cambodia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cm	cmr	120	CAMEROON	Cameroon	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ca	can	124	CANADA	Canada	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cv	cpv	132	CAPE VERDE	Cape Verde	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ky	cym	136	CAYMAN ISLANDS	Cayman Islands	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cf	caf	140	CENTRAL AFRICAN REPUBLIC	Central African Republic	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
td	tcd	148	CHAD	Chad	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cl	chl	152	CHILE	Chile	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cn	chn	156	CHINA	China	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cx	cxr	162	CHRISTMAS ISLAND	Christmas Island	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cc	cck	166	COCOS (KEELING) ISLANDS	Cocos (Keeling) Islands	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
co	col	170	COLOMBIA	Colombia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
km	com	174	COMOROS	Comoros	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cg	cog	178	CONGO	Congo	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cd	cod	180	CONGO, THE DEMOCRATIC REPUBLIC OF THE	Congo, the Democratic Republic of the	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ck	cok	184	COOK ISLANDS	Cook Islands	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cr	cri	188	COSTA RICA	Costa Rica	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
ci	civ	384	COTE D'IVOIRE	Cote D'Ivoire	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
hr	hrv	191	CROATIA	Croatia	\N	\N	2026-07-18 08:40:11.456-07	2026-07-18 08:40:11.456-07	\N
cu	cub	192	CUBA	Cuba	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
cw	cuw	531	CURAÇAO	Curaçao	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
cy	cyp	196	CYPRUS	Cyprus	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
cz	cze	203	CZECH REPUBLIC	Czech Republic	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
dk	dnk	208	DENMARK	Denmark	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
dj	dji	262	DJIBOUTI	Djibouti	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
dm	dma	212	DOMINICA	Dominica	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
do	dom	214	DOMINICAN REPUBLIC	Dominican Republic	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ec	ecu	218	ECUADOR	Ecuador	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
eg	egy	818	EGYPT	Egypt	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
sv	slv	222	EL SALVADOR	El Salvador	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gq	gnq	226	EQUATORIAL GUINEA	Equatorial Guinea	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
er	eri	232	ERITREA	Eritrea	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ee	est	233	ESTONIA	Estonia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
et	eth	231	ETHIOPIA	Ethiopia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
fk	flk	238	FALKLAND ISLANDS (MALVINAS)	Falkland Islands (Malvinas)	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
fo	fro	234	FAROE ISLANDS	Faroe Islands	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
fj	fji	242	FIJI	Fiji	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
fi	fin	246	FINLAND	Finland	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
fr	fra	250	FRANCE	France	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gf	guf	254	FRENCH GUIANA	French Guiana	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
pf	pyf	258	FRENCH POLYNESIA	French Polynesia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
tf	atf	260	FRENCH SOUTHERN TERRITORIES	French Southern Territories	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ga	gab	266	GABON	Gabon	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gm	gmb	270	GAMBIA	Gambia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ge	geo	268	GEORGIA	Georgia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
de	deu	276	GERMANY	Germany	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gh	gha	288	GHANA	Ghana	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gi	gib	292	GIBRALTAR	Gibraltar	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gr	grc	300	GREECE	Greece	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gl	grl	304	GREENLAND	Greenland	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gd	grd	308	GRENADA	Grenada	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gp	glp	312	GUADELOUPE	Guadeloupe	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gu	gum	316	GUAM	Guam	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gt	gtm	320	GUATEMALA	Guatemala	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gg	ggy	831	GUERNSEY	Guernsey	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gn	gin	324	GUINEA	Guinea	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gw	gnb	624	GUINEA-BISSAU	Guinea-Bissau	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
gy	guy	328	GUYANA	Guyana	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ht	hti	332	HAITI	Haiti	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
hm	hmd	334	HEARD ISLAND AND MCDONALD ISLANDS	Heard Island And Mcdonald Islands	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
va	vat	336	HOLY SEE (VATICAN CITY STATE)	Holy See (Vatican City State)	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
hn	hnd	340	HONDURAS	Honduras	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
hk	hkg	344	HONG KONG	Hong Kong	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
hu	hun	348	HUNGARY	Hungary	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
is	isl	352	ICELAND	Iceland	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
id	idn	360	INDONESIA	Indonesia	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ir	irn	364	IRAN, ISLAMIC REPUBLIC OF	Iran, Islamic Republic of	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
iq	irq	368	IRAQ	Iraq	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ie	irl	372	IRELAND	Ireland	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
im	imn	833	ISLE OF MAN	Isle Of Man	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
il	isr	376	ISRAEL	Israel	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
it	ita	380	ITALY	Italy	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
jm	jam	388	JAMAICA	Jamaica	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
jp	jpn	392	JAPAN	Japan	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
je	jey	832	JERSEY	Jersey	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
jo	jor	400	JORDAN	Jordan	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
kz	kaz	398	KAZAKHSTAN	Kazakhstan	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ke	ken	404	KENYA	Kenya	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
ki	kir	296	KIRIBATI	Kiribati	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
kp	prk	408	KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF	Korea, Democratic People's Republic of	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
kr	kor	410	KOREA, REPUBLIC OF	Korea, Republic of	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
xk	xkx	900	KOSOVO	Kosovo	\N	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:11.457-07	\N
kw	kwt	414	KUWAIT	Kuwait	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
kg	kgz	417	KYRGYZSTAN	Kyrgyzstan	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
la	lao	418	LAO PEOPLE'S DEMOCRATIC REPUBLIC	Lao People's Democratic Republic	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lv	lva	428	LATVIA	Latvia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lb	lbn	422	LEBANON	Lebanon	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ls	lso	426	LESOTHO	Lesotho	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lr	lbr	430	LIBERIA	Liberia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ly	lby	434	LIBYA	Libya	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
li	lie	438	LIECHTENSTEIN	Liechtenstein	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lt	ltu	440	LITHUANIA	Lithuania	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lu	lux	442	LUXEMBOURG	Luxembourg	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mo	mac	446	MACAO	Macao	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mg	mdg	450	MADAGASCAR	Madagascar	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mw	mwi	454	MALAWI	Malawi	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
my	mys	458	MALAYSIA	Malaysia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mv	mdv	462	MALDIVES	Maldives	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ml	mli	466	MALI	Mali	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mt	mlt	470	MALTA	Malta	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mh	mhl	584	MARSHALL ISLANDS	Marshall Islands	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mq	mtq	474	MARTINIQUE	Martinique	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mr	mrt	478	MAURITANIA	Mauritania	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mu	mus	480	MAURITIUS	Mauritius	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
yt	myt	175	MAYOTTE	Mayotte	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mx	mex	484	MEXICO	Mexico	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
fm	fsm	583	MICRONESIA, FEDERATED STATES OF	Micronesia, Federated States of	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
md	mda	498	MOLDOVA, REPUBLIC OF	Moldova, Republic of	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mc	mco	492	MONACO	Monaco	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mn	mng	496	MONGOLIA	Mongolia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
me	mne	499	MONTENEGRO	Montenegro	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ms	msr	500	MONTSERRAT	Montserrat	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ma	mar	504	MOROCCO	Morocco	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mz	moz	508	MOZAMBIQUE	Mozambique	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mm	mmr	104	MYANMAR	Myanmar	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
na	nam	516	NAMIBIA	Namibia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nr	nru	520	NAURU	Nauru	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
np	npl	524	NEPAL	Nepal	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nl	nld	528	NETHERLANDS	Netherlands	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nc	ncl	540	NEW CALEDONIA	New Caledonia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nz	nzl	554	NEW ZEALAND	New Zealand	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ni	nic	558	NICARAGUA	Nicaragua	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ne	ner	562	NIGER	Niger	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ng	nga	566	NIGERIA	Nigeria	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nu	niu	570	NIUE	Niue	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
nf	nfk	574	NORFOLK ISLAND	Norfolk Island	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mk	mkd	807	NORTH MACEDONIA	North Macedonia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mp	mnp	580	NORTHERN MARIANA ISLANDS	Northern Mariana Islands	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
no	nor	578	NORWAY	Norway	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
om	omn	512	OMAN	Oman	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pk	pak	586	PAKISTAN	Pakistan	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pw	plw	585	PALAU	Palau	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ps	pse	275	PALESTINIAN TERRITORY, OCCUPIED	Palestinian Territory, Occupied	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pa	pan	591	PANAMA	Panama	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pg	png	598	PAPUA NEW GUINEA	Papua New Guinea	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
py	pry	600	PARAGUAY	Paraguay	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pe	per	604	PERU	Peru	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ph	phl	608	PHILIPPINES	Philippines	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pn	pcn	612	PITCAIRN	Pitcairn	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pl	pol	616	POLAND	Poland	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pt	prt	620	PORTUGAL	Portugal	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pr	pri	630	PUERTO RICO	Puerto Rico	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
qa	qat	634	QATAR	Qatar	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
re	reu	638	REUNION	Reunion	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ro	rom	642	ROMANIA	Romania	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ru	rus	643	RUSSIAN FEDERATION	Russian Federation	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
rw	rwa	646	RWANDA	Rwanda	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
bl	blm	652	SAINT BARTHÉLEMY	Saint Barthélemy	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
sh	shn	654	SAINT HELENA	Saint Helena	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
kn	kna	659	SAINT KITTS AND NEVIS	Saint Kitts and Nevis	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
lc	lca	662	SAINT LUCIA	Saint Lucia	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
mf	maf	663	SAINT MARTIN (FRENCH PART)	Saint Martin (French part)	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
pm	spm	666	SAINT PIERRE AND MIQUELON	Saint Pierre and Miquelon	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
vc	vct	670	SAINT VINCENT AND THE GRENADINES	Saint Vincent and the Grenadines	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
ws	wsm	882	SAMOA	Samoa	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
sm	smr	674	SAN MARINO	San Marino	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
st	stp	678	SAO TOME AND PRINCIPE	Sao Tome and Principe	\N	\N	2026-07-18 08:40:11.458-07	2026-07-18 08:40:11.458-07	\N
sa	sau	682	SAUDI ARABIA	Saudi Arabia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sn	sen	686	SENEGAL	Senegal	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
rs	srb	688	SERBIA	Serbia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sc	syc	690	SEYCHELLES	Seychelles	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sl	sle	694	SIERRA LEONE	Sierra Leone	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sg	sgp	702	SINGAPORE	Singapore	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sx	sxm	534	SINT MAARTEN	Sint Maarten	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sk	svk	703	SLOVAKIA	Slovakia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
si	svn	705	SLOVENIA	Slovenia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sb	slb	090	SOLOMON ISLANDS	Solomon Islands	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
so	som	706	SOMALIA	Somalia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
za	zaf	710	SOUTH AFRICA	South Africa	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
gs	sgs	239	SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS	South Georgia and the South Sandwich Islands	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ss	ssd	728	SOUTH SUDAN	South Sudan	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
es	esp	724	SPAIN	Spain	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
lk	lka	144	SRI LANKA	Sri Lanka	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sd	sdn	729	SUDAN	Sudan	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sr	sur	740	SURINAME	Suriname	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sj	sjm	744	SVALBARD AND JAN MAYEN	Svalbard and Jan Mayen	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sz	swz	748	SWAZILAND	Swaziland	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
se	swe	752	SWEDEN	Sweden	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ch	che	756	SWITZERLAND	Switzerland	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
sy	syr	760	SYRIAN ARAB REPUBLIC	Syrian Arab Republic	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tw	twn	158	TAIWAN, PROVINCE OF CHINA	Taiwan, Province of China	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tj	tjk	762	TAJIKISTAN	Tajikistan	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tz	tza	834	TANZANIA, UNITED REPUBLIC OF	Tanzania, United Republic of	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
th	tha	764	THAILAND	Thailand	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tl	tls	626	TIMOR LESTE	Timor Leste	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tg	tgo	768	TOGO	Togo	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tk	tkl	772	TOKELAU	Tokelau	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
to	ton	776	TONGA	Tonga	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tt	tto	780	TRINIDAD AND TOBAGO	Trinidad and Tobago	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tn	tun	788	TUNISIA	Tunisia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tr	tur	792	TURKEY	Turkey	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tm	tkm	795	TURKMENISTAN	Turkmenistan	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tc	tca	796	TURKS AND CAICOS ISLANDS	Turks and Caicos Islands	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
tv	tuv	798	TUVALU	Tuvalu	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ug	uga	800	UGANDA	Uganda	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ua	ukr	804	UKRAINE	Ukraine	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ae	are	784	UNITED ARAB EMIRATES	United Arab Emirates	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
gb	gbr	826	UNITED KINGDOM	United Kingdom	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
us	usa	840	UNITED STATES	United States	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
um	umi	581	UNITED STATES MINOR OUTLYING ISLANDS	United States Minor Outlying Islands	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
uy	ury	858	URUGUAY	Uruguay	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
uz	uzb	860	UZBEKISTAN	Uzbekistan	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
vu	vut	548	VANUATU	Vanuatu	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ve	ven	862	VENEZUELA	Venezuela	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
vn	vnm	704	VIET NAM	Viet Nam	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
vg	vgb	092	VIRGIN ISLANDS, BRITISH	Virgin Islands, British	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
vi	vir	850	VIRGIN ISLANDS, U.S.	Virgin Islands, U.S.	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
wf	wlf	876	WALLIS AND FUTUNA	Wallis and Futuna	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
eh	esh	732	WESTERN SAHARA	Western Sahara	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ye	yem	887	YEMEN	Yemen	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
zm	zmb	894	ZAMBIA	Zambia	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
zw	zwe	716	ZIMBABWE	Zimbabwe	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
ax	ala	248	ÅLAND ISLANDS	Åland Islands	\N	\N	2026-07-18 08:40:11.459-07	2026-07-18 08:40:11.459-07	\N
in	ind	356	INDIA	India	reg_01KXTY56S0Q5CK3WYP4X1MCP4B	\N	2026-07-18 08:40:11.457-07	2026-07-18 08:40:12.968-07	\N
\.


--
-- Data for Name: region_payment_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.region_payment_provider (region_id, payment_provider_id, id, created_at, updated_at, deleted_at) FROM stdin;
reg_01KXTY56S0Q5CK3WYP4X1MCP4B	pp_system_default	regpp_01KXTY56SS5F15ZVRR8J4R8TFM	2026-07-18 08:40:12.984625-07	2026-07-18 08:40:12.984625-07	\N
\.


--
-- Data for Name: reservation_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reservation_item (id, created_at, updated_at, deleted_at, line_item_id, location_id, quantity, external_id, description, created_by, metadata, inventory_item_id, allow_backorder, raw_quantity) FROM stdin;
\.


--
-- Data for Name: return; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return (id, order_id, claim_id, exchange_id, order_version, display_id, status, no_notification, refund_amount, raw_refund_amount, metadata, created_at, updated_at, deleted_at, received_at, canceled_at, location_id, requested_at, created_by) FROM stdin;
\.


--
-- Data for Name: return_fulfillment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_fulfillment (return_id, fulfillment_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: return_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_item (id, return_id, reason_id, item_id, quantity, raw_quantity, received_quantity, raw_received_quantity, note, metadata, created_at, updated_at, deleted_at, damaged_quantity, raw_damaged_quantity) FROM stdin;
\.


--
-- Data for Name: return_reason; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_reason (id, value, label, description, metadata, parent_return_reason_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sales_channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_channel (id, name, description, is_disabled, metadata, created_at, updated_at, deleted_at) FROM stdin;
sc_01KXTY56Q47ATGPEMAKJ32XAGN	Online Store	onecurve.in web storefront	f	\N	2026-07-18 08:40:12.9-07	2026-07-18 08:40:12.9-07	\N
sc_01KXTY56Q4N0G59MDZSHFDFW60	POS	In-store point of sale	f	\N	2026-07-18 08:40:12.9-07	2026-07-18 08:40:12.9-07	\N
\.


--
-- Data for Name: sales_channel_stock_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_channel_stock_location (sales_channel_id, stock_location_id, id, created_at, updated_at, deleted_at) FROM stdin;
sc_01KXTY56Q47ATGPEMAKJ32XAGN	sloc_01KXTY56TP4V94XCQYG8RD9SMM	scloc_01KXTY56YKKRC7VEV1Q7955SYQ	2026-07-18 08:40:13.139305-07	2026-07-18 08:40:13.139305-07	\N
sc_01KXTY56Q4N0G59MDZSHFDFW60	sloc_01KXTY56TP4V94XCQYG8RD9SMM	scloc_01KXTY56YMF6X51CS3KAJMY5Z7	2026-07-18 08:40:13.139305-07	2026-07-18 08:40:13.139305-07	\N
\.


--
-- Data for Name: script_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.script_migrations (id, script_name, created_at, finished_at) FROM stdin;
1	migrate-normalize-currency-codes-normalization.js	2026-07-18 08:40:11.87598-07	2026-07-18 08:40:11.917619-07
2	migrate-product-shipping-profile.js	2026-07-18 08:40:12.823099-07	2026-07-18 08:40:12.847923-07
3	migrate-tax-region-provider.js	2026-07-18 08:40:12.850822-07	2026-07-18 08:40:12.857645-07
4	reconcile-inventory-reserved-quantity.js	2026-07-18 08:40:12.860612-07	2026-07-18 08:40:12.866849-07
5	initial-data-seed.ts	2026-07-18 08:40:12.891406-07	2026-07-18 08:40:13.504411-07
6	seed-products-v2.ts	2026-07-18 08:40:13.508485-07	2026-07-18 08:40:13.520812-07
\.


--
-- Data for Name: service_zone; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_zone (id, name, metadata, fulfillment_set_id, created_at, updated_at, deleted_at) FROM stdin;
serzo_01KXTY56VAX8GW1RSP5CHCQA44	India	\N	fuset_01KXTY56VA5ME38VF19FAAEZ4M	2026-07-18 08:40:13.035-07	2026-07-18 08:40:13.035-07	\N
\.


--
-- Data for Name: shipping_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_option (id, name, price_type, service_zone_id, shipping_profile_id, provider_id, data, metadata, shipping_option_type_id, created_at, updated_at, deleted_at) FROM stdin;
so_01KXTY56X01R5229BC5G980N0M	Standard Shipping	flat	serzo_01KXTY56VAX8GW1RSP5CHCQA44	sp_01KXTY56N8YHHCCQTB752NFN7W	manual_manual	\N	\N	sotype_01KXTY56X02KM1YASBWTB33AE8	2026-07-18 08:40:13.089-07	2026-07-18 08:40:13.089-07	\N
\.


--
-- Data for Name: shipping_option_price_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_option_price_set (shipping_option_id, price_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
so_01KXTY56X01R5229BC5G980N0M	pset_01KXTY56XGYTWCKQYM650MA4ER	sops_01KXTY56YB69KM1A8VB7V5E06J	2026-07-18 08:40:13.130797-07	2026-07-18 08:40:13.130797-07	\N
\.


--
-- Data for Name: shipping_option_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_option_rule (id, attribute, operator, value, shipping_option_id, created_at, updated_at, deleted_at) FROM stdin;
sorul_01KXTY56X06A0JSRAGHBQWYKD1	enabled_in_store	eq	"true"	so_01KXTY56X01R5229BC5G980N0M	2026-07-18 08:40:13.089-07	2026-07-18 08:40:13.089-07	\N
sorul_01KXTY56X0Z18YM4SYB93GXVAJ	is_return	eq	"false"	so_01KXTY56X01R5229BC5G980N0M	2026-07-18 08:40:13.089-07	2026-07-18 08:40:13.089-07	\N
\.


--
-- Data for Name: shipping_option_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_option_type (id, label, description, code, created_at, updated_at, deleted_at) FROM stdin;
sotype_01KXTY56X02KM1YASBWTB33AE8	Standard	Delivered in 3-5 business days.	standard	2026-07-18 08:40:13.089-07	2026-07-18 08:40:13.089-07	\N
\.


--
-- Data for Name: shipping_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_profile (id, name, type, metadata, created_at, updated_at, deleted_at) FROM stdin;
sp_01KXTY56N8YHHCCQTB752NFN7W	Default Shipping Profile	default	\N	2026-07-18 08:40:12.841-07	2026-07-18 08:40:12.841-07	\N
\.


--
-- Data for Name: stock_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_location (id, created_at, updated_at, deleted_at, name, address_id, metadata) FROM stdin;
sloc_01KXTY56TP4V94XCQYG8RD9SMM	2026-07-18 08:40:13.015-07	2026-07-18 08:40:13.015-07	\N	OneCurve Store	laddr_01KXTY56TPHPHF9147399R63DG	\N
\.


--
-- Data for Name: stock_location_address; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_location_address (id, created_at, updated_at, deleted_at, address_1, address_2, company, city, country_code, phone, province, postal_code, metadata) FROM stdin;
laddr_01KXTY56TPHPHF9147399R63DG	2026-07-18 08:40:13.014-07	2026-07-18 08:40:13.014-07	\N		\N	\N		IN	\N	\N	\N	\N
\.


--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store (id, name, default_sales_channel_id, default_region_id, default_location_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
store_01KXTY56RA0SD2V90WVPZGXKFD	OneCurve Sports	sc_01KXTY56Q47ATGPEMAKJ32XAGN	\N	\N	\N	2026-07-18 08:40:12.936075-07	2026-07-18 08:40:12.936075-07	\N
\.


--
-- Data for Name: store_currency; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_currency (id, currency_code, is_default, store_id, created_at, updated_at, deleted_at) FROM stdin;
stocur_01KXTY56RFSPT73SP887714GBJ	inr	t	store_01KXTY56RA0SD2V90WVPZGXKFD	2026-07-18 08:40:12.936075-07	2026-07-18 08:40:12.936075-07	\N
\.


--
-- Data for Name: store_locale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_locale (id, locale_code, store_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: tax_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
tp_system	t	2026-07-18 08:40:11.533-07	2026-07-18 08:40:11.533-07	\N
\.


--
-- Data for Name: tax_rate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_rate (id, rate, code, name, is_default, is_combinable, tax_region_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: tax_rate_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_rate_rule (id, tax_rate_id, reference_id, reference, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: tax_region; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_region (id, provider_id, country_code, province_code, parent_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
txreg_01KXTY56TBNESNMQ7NXK9DG9T8	tp_system	in	\N	\N	\N	2026-07-18 08:40:13.004-07	2026-07-18 08:40:13.004-07	\N	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, first_name, last_name, email, avatar_url, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_preference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preference (id, user_id, key, value, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_rbac_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_rbac_role (user_id, rbac_role_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: view_configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.view_configuration (id, entity, name, user_id, is_system_default, configuration, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: workflow_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_execution (id, workflow_id, transaction_id, execution, context, state, created_at, updated_at, deleted_at, retention_time, run_id) FROM stdin;
\.


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.link_module_migrations_id_seq', 20, true);


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mikro_orm_migrations_id_seq', 164, true);


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_change_action_ordering_seq', 1, false);


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_claim_display_id_seq', 1, false);


--
-- Name: order_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_display_id_seq', 1, false);


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_exchange_display_id_seq', 1, false);


--
-- Name: return_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.return_display_id_seq', 1, false);


--
-- Name: script_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.script_migrations_id_seq', 6, true);


--
-- Name: account_holder account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_holder
    ADD CONSTRAINT account_holder_pkey PRIMARY KEY (id);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: application_method_buy_rules application_method_buy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_pkey PRIMARY KEY (application_method_id, promotion_rule_id);


--
-- Name: application_method_target_rules application_method_target_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_pkey PRIMARY KEY (application_method_id, promotion_rule_id);


--
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY (id);


--
-- Name: auth_mfa_factor auth_mfa_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_mfa_factor
    ADD CONSTRAINT auth_mfa_factor_pkey PRIMARY KEY (id);


--
-- Name: auth_mfa_recovery_code auth_mfa_recovery_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_mfa_recovery_code
    ADD CONSTRAINT auth_mfa_recovery_code_pkey PRIMARY KEY (id);


--
-- Name: auth_verification_token auth_verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_verification_token
    ADD CONSTRAINT auth_verification_token_pkey PRIMARY KEY (id);


--
-- Name: capture capture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capture
    ADD CONSTRAINT capture_pkey PRIMARY KEY (id);


--
-- Name: cart_address cart_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_address
    ADD CONSTRAINT cart_address_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item_adjustment
    ADD CONSTRAINT cart_line_item_adjustment_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item cart_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item
    ADD CONSTRAINT cart_line_item_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item_tax_line
    ADD CONSTRAINT cart_line_item_tax_line_pkey PRIMARY KEY (id);


--
-- Name: cart_payment_collection cart_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_payment_collection
    ADD CONSTRAINT cart_payment_collection_pkey PRIMARY KEY (cart_id, payment_collection_id);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- Name: cart_promotion cart_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_promotion
    ADD CONSTRAINT cart_promotion_pkey PRIMARY KEY (cart_id, promotion_id);


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method_adjustment
    ADD CONSTRAINT cart_shipping_method_adjustment_pkey PRIMARY KEY (id);


--
-- Name: cart_shipping_method cart_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method
    ADD CONSTRAINT cart_shipping_method_pkey PRIMARY KEY (id);


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method_tax_line
    ADD CONSTRAINT cart_shipping_method_tax_line_pkey PRIMARY KEY (id);


--
-- Name: credit_line credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_line
    ADD CONSTRAINT credit_line_pkey PRIMARY KEY (id);


--
-- Name: currency currency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.currency
    ADD CONSTRAINT currency_pkey PRIMARY KEY (code);


--
-- Name: customer_account_holder customer_account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_account_holder
    ADD CONSTRAINT customer_account_holder_pkey PRIMARY KEY (customer_id, account_holder_id);


--
-- Name: customer_address customer_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_address
    ADD CONSTRAINT customer_address_pkey PRIMARY KEY (id);


--
-- Name: customer_group_customer customer_group_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_pkey PRIMARY KEY (id);


--
-- Name: customer_group customer_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_group
    ADD CONSTRAINT customer_group_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_address fulfillment_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_address
    ADD CONSTRAINT fulfillment_address_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_item fulfillment_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_item
    ADD CONSTRAINT fulfillment_item_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_label fulfillment_label_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_label
    ADD CONSTRAINT fulfillment_label_pkey PRIMARY KEY (id);


--
-- Name: fulfillment fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_provider fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_provider
    ADD CONSTRAINT fulfillment_provider_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_set fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_set
    ADD CONSTRAINT fulfillment_set_pkey PRIMARY KEY (id);


--
-- Name: geo_zone geo_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geo_zone
    ADD CONSTRAINT geo_zone_pkey PRIMARY KEY (id);


--
-- Name: image image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_pkey PRIMARY KEY (id);


--
-- Name: inventory_item inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT inventory_item_pkey PRIMARY KEY (id);


--
-- Name: inventory_level inventory_level_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_level
    ADD CONSTRAINT inventory_level_pkey PRIMARY KEY (id);


--
-- Name: invite invite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite
    ADD CONSTRAINT invite_pkey PRIMARY KEY (id);


--
-- Name: invite_rbac_role invite_rbac_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invite_rbac_role
    ADD CONSTRAINT invite_rbac_role_pkey PRIMARY KEY (invite_id, rbac_role_id);


--
-- Name: link_module_migrations link_module_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_module_migrations
    ADD CONSTRAINT link_module_migrations_pkey PRIMARY KEY (id);


--
-- Name: link_module_migrations link_module_migrations_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.link_module_migrations
    ADD CONSTRAINT link_module_migrations_table_name_key UNIQUE (table_name);


--
-- Name: location_fulfillment_provider location_fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_fulfillment_provider
    ADD CONSTRAINT location_fulfillment_provider_pkey PRIMARY KEY (stock_location_id, fulfillment_provider_id);


--
-- Name: location_fulfillment_set location_fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_fulfillment_set
    ADD CONSTRAINT location_fulfillment_set_pkey PRIMARY KEY (stock_location_id, fulfillment_set_id);


--
-- Name: mikro_orm_migrations mikro_orm_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mikro_orm_migrations
    ADD CONSTRAINT mikro_orm_migrations_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_provider notification_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_provider
    ADD CONSTRAINT notification_provider_pkey PRIMARY KEY (id);


--
-- Name: order_address order_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_address
    ADD CONSTRAINT order_address_pkey PRIMARY KEY (id);


--
-- Name: order_cart order_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_cart
    ADD CONSTRAINT order_cart_pkey PRIMARY KEY (order_id, cart_id);


--
-- Name: order_change_action order_change_action_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_change_action
    ADD CONSTRAINT order_change_action_pkey PRIMARY KEY (id);


--
-- Name: order_change order_change_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_change
    ADD CONSTRAINT order_change_pkey PRIMARY KEY (id);


--
-- Name: order_claim_item_image order_claim_item_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_claim_item_image
    ADD CONSTRAINT order_claim_item_image_pkey PRIMARY KEY (id);


--
-- Name: order_claim_item order_claim_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_claim_item
    ADD CONSTRAINT order_claim_item_pkey PRIMARY KEY (id);


--
-- Name: order_claim order_claim_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_claim
    ADD CONSTRAINT order_claim_pkey PRIMARY KEY (id);


--
-- Name: order_credit_line order_credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_credit_line
    ADD CONSTRAINT order_credit_line_pkey PRIMARY KEY (id);


--
-- Name: order_exchange_item order_exchange_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_exchange_item
    ADD CONSTRAINT order_exchange_item_pkey PRIMARY KEY (id);


--
-- Name: order_exchange order_exchange_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_exchange
    ADD CONSTRAINT order_exchange_pkey PRIMARY KEY (id);


--
-- Name: order_fulfillment order_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_fulfillment
    ADD CONSTRAINT order_fulfillment_pkey PRIMARY KEY (order_id, fulfillment_id);


--
-- Name: order_item order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_pkey PRIMARY KEY (id);


--
-- Name: order_line_item_adjustment order_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item_adjustment
    ADD CONSTRAINT order_line_item_adjustment_pkey PRIMARY KEY (id);


--
-- Name: order_line_item order_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item
    ADD CONSTRAINT order_line_item_pkey PRIMARY KEY (id);


--
-- Name: order_line_item_tax_line order_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item_tax_line
    ADD CONSTRAINT order_line_item_tax_line_pkey PRIMARY KEY (id);


--
-- Name: order_payment_collection order_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_payment_collection
    ADD CONSTRAINT order_payment_collection_pkey PRIMARY KEY (order_id, payment_collection_id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: order_promotion order_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_promotion
    ADD CONSTRAINT order_promotion_pkey PRIMARY KEY (order_id, promotion_id);


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping_method_adjustment
    ADD CONSTRAINT order_shipping_method_adjustment_pkey PRIMARY KEY (id);


--
-- Name: order_shipping_method order_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping_method
    ADD CONSTRAINT order_shipping_method_pkey PRIMARY KEY (id);


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping_method_tax_line
    ADD CONSTRAINT order_shipping_method_tax_line_pkey PRIMARY KEY (id);


--
-- Name: order_shipping order_shipping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping
    ADD CONSTRAINT order_shipping_pkey PRIMARY KEY (id);


--
-- Name: order_summary order_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_summary
    ADD CONSTRAINT order_summary_pkey PRIMARY KEY (id);


--
-- Name: order_transaction order_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_transaction
    ADD CONSTRAINT order_transaction_pkey PRIMARY KEY (id);


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_pkey PRIMARY KEY (payment_collection_id, payment_provider_id);


--
-- Name: payment_collection payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_collection
    ADD CONSTRAINT payment_collection_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: payment_provider payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_provider
    ADD CONSTRAINT payment_provider_pkey PRIMARY KEY (id);


--
-- Name: payment_session payment_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_session
    ADD CONSTRAINT payment_session_pkey PRIMARY KEY (id);


--
-- Name: price_list price_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_list
    ADD CONSTRAINT price_list_pkey PRIMARY KEY (id);


--
-- Name: price_list_rule price_list_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_list_rule
    ADD CONSTRAINT price_list_rule_pkey PRIMARY KEY (id);


--
-- Name: price price_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_pkey PRIMARY KEY (id);


--
-- Name: price_preference price_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_preference
    ADD CONSTRAINT price_preference_pkey PRIMARY KEY (id);


--
-- Name: price_rule price_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_rule
    ADD CONSTRAINT price_rule_pkey PRIMARY KEY (id);


--
-- Name: price_set price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_set
    ADD CONSTRAINT price_set_pkey PRIMARY KEY (id);


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_pkey PRIMARY KEY (id);


--
-- Name: product_category_product product_category_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_pkey PRIMARY KEY (product_id, product_category_id);


--
-- Name: product_collection product_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_collection
    ADD CONSTRAINT product_collection_pkey PRIMARY KEY (id);


--
-- Name: product_option product_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_option
    ADD CONSTRAINT product_option_pkey PRIMARY KEY (id);


--
-- Name: product_option_value product_option_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_option_value
    ADD CONSTRAINT product_option_value_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: product_sales_channel product_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_sales_channel
    ADD CONSTRAINT product_sales_channel_pkey PRIMARY KEY (product_id, sales_channel_id);


--
-- Name: product_shipping_profile product_shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_shipping_profile
    ADD CONSTRAINT product_shipping_profile_pkey PRIMARY KEY (product_id, shipping_profile_id);


--
-- Name: product_tag product_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tag
    ADD CONSTRAINT product_tag_pkey PRIMARY KEY (id);


--
-- Name: product_tags product_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_pkey PRIMARY KEY (product_id, product_tag_id);


--
-- Name: product_type product_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type
    ADD CONSTRAINT product_type_pkey PRIMARY KEY (id);


--
-- Name: product_variant_inventory_item product_variant_inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_inventory_item
    ADD CONSTRAINT product_variant_inventory_item_pkey PRIMARY KEY (variant_id, inventory_item_id);


--
-- Name: product_variant_option product_variant_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_pkey PRIMARY KEY (variant_id, option_value_id);


--
-- Name: product_variant product_variant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant
    ADD CONSTRAINT product_variant_pkey PRIMARY KEY (id);


--
-- Name: product_variant_price_set product_variant_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_price_set
    ADD CONSTRAINT product_variant_price_set_pkey PRIMARY KEY (variant_id, price_set_id);


--
-- Name: product_variant_product_image product_variant_product_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_product_image
    ADD CONSTRAINT product_variant_product_image_pkey PRIMARY KEY (id);


--
-- Name: promotion_application_method promotion_application_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_application_method
    ADD CONSTRAINT promotion_application_method_pkey PRIMARY KEY (id);


--
-- Name: promotion_campaign_budget promotion_campaign_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_campaign_budget
    ADD CONSTRAINT promotion_campaign_budget_pkey PRIMARY KEY (id);


--
-- Name: promotion_campaign_budget_usage promotion_campaign_budget_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_campaign_budget_usage
    ADD CONSTRAINT promotion_campaign_budget_usage_pkey PRIMARY KEY (id);


--
-- Name: promotion_campaign promotion_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_campaign
    ADD CONSTRAINT promotion_campaign_pkey PRIMARY KEY (id);


--
-- Name: promotion promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT promotion_pkey PRIMARY KEY (id);


--
-- Name: promotion_promotion_rule promotion_promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_pkey PRIMARY KEY (promotion_id, promotion_rule_id);


--
-- Name: promotion_rule promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_rule
    ADD CONSTRAINT promotion_rule_pkey PRIMARY KEY (id);


--
-- Name: promotion_rule_value promotion_rule_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_rule_value
    ADD CONSTRAINT promotion_rule_value_pkey PRIMARY KEY (id);


--
-- Name: property_label property_label_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_label
    ADD CONSTRAINT property_label_pkey PRIMARY KEY (id);


--
-- Name: provider_identity provider_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_identity
    ADD CONSTRAINT provider_identity_pkey PRIMARY KEY (id);


--
-- Name: publishable_api_key_sales_channel publishable_api_key_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publishable_api_key_sales_channel
    ADD CONSTRAINT publishable_api_key_sales_channel_pkey PRIMARY KEY (publishable_key_id, sales_channel_id);


--
-- Name: refund refund_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund
    ADD CONSTRAINT refund_pkey PRIMARY KEY (id);


--
-- Name: refund_reason refund_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_reason
    ADD CONSTRAINT refund_reason_pkey PRIMARY KEY (id);


--
-- Name: region_country region_country_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_country
    ADD CONSTRAINT region_country_pkey PRIMARY KEY (iso_2);


--
-- Name: region_payment_provider region_payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_payment_provider
    ADD CONSTRAINT region_payment_provider_pkey PRIMARY KEY (region_id, payment_provider_id);


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region
    ADD CONSTRAINT region_pkey PRIMARY KEY (id);


--
-- Name: reservation_item reservation_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservation_item
    ADD CONSTRAINT reservation_item_pkey PRIMARY KEY (id);


--
-- Name: return_fulfillment return_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_fulfillment
    ADD CONSTRAINT return_fulfillment_pkey PRIMARY KEY (return_id, fulfillment_id);


--
-- Name: return_item return_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_item
    ADD CONSTRAINT return_item_pkey PRIMARY KEY (id);


--
-- Name: return return_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return
    ADD CONSTRAINT return_pkey PRIMARY KEY (id);


--
-- Name: return_reason return_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_reason
    ADD CONSTRAINT return_reason_pkey PRIMARY KEY (id);


--
-- Name: sales_channel sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT sales_channel_pkey PRIMARY KEY (id);


--
-- Name: sales_channel_stock_location sales_channel_stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_channel_stock_location
    ADD CONSTRAINT sales_channel_stock_location_pkey PRIMARY KEY (sales_channel_id, stock_location_id);


--
-- Name: script_migrations script_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.script_migrations
    ADD CONSTRAINT script_migrations_pkey PRIMARY KEY (id);


--
-- Name: service_zone service_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zone
    ADD CONSTRAINT service_zone_pkey PRIMARY KEY (id);


--
-- Name: shipping_option shipping_option_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_pkey PRIMARY KEY (id);


--
-- Name: shipping_option_price_set shipping_option_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option_price_set
    ADD CONSTRAINT shipping_option_price_set_pkey PRIMARY KEY (shipping_option_id, price_set_id);


--
-- Name: shipping_option_rule shipping_option_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option_rule
    ADD CONSTRAINT shipping_option_rule_pkey PRIMARY KEY (id);


--
-- Name: shipping_option_type shipping_option_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option_type
    ADD CONSTRAINT shipping_option_type_pkey PRIMARY KEY (id);


--
-- Name: shipping_profile shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_profile
    ADD CONSTRAINT shipping_profile_pkey PRIMARY KEY (id);


--
-- Name: stock_location_address stock_location_address_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_location_address
    ADD CONSTRAINT stock_location_address_pkey PRIMARY KEY (id);


--
-- Name: stock_location stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_location
    ADD CONSTRAINT stock_location_pkey PRIMARY KEY (id);


--
-- Name: store_currency store_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_currency
    ADD CONSTRAINT store_currency_pkey PRIMARY KEY (id);


--
-- Name: store_locale store_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_locale
    ADD CONSTRAINT store_locale_pkey PRIMARY KEY (id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: tax_provider tax_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_provider
    ADD CONSTRAINT tax_provider_pkey PRIMARY KEY (id);


--
-- Name: tax_rate tax_rate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate
    ADD CONSTRAINT tax_rate_pkey PRIMARY KEY (id);


--
-- Name: tax_rate_rule tax_rate_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_rule
    ADD CONSTRAINT tax_rate_rule_pkey PRIMARY KEY (id);


--
-- Name: tax_region tax_region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT tax_region_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_preference user_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preference
    ADD CONSTRAINT user_preference_pkey PRIMARY KEY (id);


--
-- Name: user_rbac_role user_rbac_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_rbac_role
    ADD CONSTRAINT user_rbac_role_pkey PRIMARY KEY (user_id, rbac_role_id);


--
-- Name: view_configuration view_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.view_configuration
    ADD CONSTRAINT view_configuration_pkey PRIMARY KEY (id);


--
-- Name: workflow_execution workflow_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_execution
    ADD CONSTRAINT workflow_execution_pkey PRIMARY KEY (workflow_id, transaction_id, run_id);


--
-- Name: IDX_account_holder_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_account_holder_deleted_at" ON public.account_holder USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_account_holder_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_account_holder_id_5cb3a0c0" ON public.customer_account_holder USING btree (account_holder_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_account_holder_provider_id_external_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_account_holder_provider_id_external_id_unique" ON public.account_holder USING btree (provider_id, external_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_deleted_at" ON public.api_key USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_redacted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_redacted" ON public.api_key USING btree (redacted) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_revoked_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_revoked_at" ON public.api_key USING btree (revoked_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_token_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_api_key_token_unique" ON public.api_key USING btree (token);


--
-- Name: IDX_api_key_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_api_key_type" ON public.api_key USING btree (type);


--
-- Name: IDX_application_method_allocation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_allocation" ON public.promotion_application_method USING btree (allocation);


--
-- Name: IDX_application_method_target_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_target_type" ON public.promotion_application_method USING btree (target_type);


--
-- Name: IDX_application_method_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_application_method_type" ON public.promotion_application_method USING btree (type);


--
-- Name: IDX_auth_identity_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_identity_deleted_at" ON public.auth_identity USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_mfa_factor_auth_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_mfa_factor_auth_identity_id" ON public.auth_mfa_factor USING btree (auth_identity_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_mfa_factor_auth_identity_provider_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_auth_mfa_factor_auth_identity_provider_active" ON public.auth_mfa_factor USING btree (auth_identity_id, provider) WHERE ((deleted_at IS NULL) AND (status = ANY (ARRAY['pending'::text, 'enabled'::text])));


--
-- Name: IDX_auth_mfa_factor_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_mfa_factor_deleted_at" ON public.auth_mfa_factor USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_mfa_recovery_code_auth_identity_code_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_auth_mfa_recovery_code_auth_identity_code_hash" ON public.auth_mfa_recovery_code USING btree (auth_identity_id, code_hash) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_mfa_recovery_code_auth_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_mfa_recovery_code_auth_identity_id" ON public.auth_mfa_recovery_code USING btree (auth_identity_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_mfa_recovery_code_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_mfa_recovery_code_deleted_at" ON public.auth_mfa_recovery_code USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_verification_token_auth_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_verification_token_auth_identity_id" ON public.auth_verification_token USING btree (auth_identity_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_verification_token_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_verification_token_deleted_at" ON public.auth_verification_token USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_verification_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_verification_token_expires_at" ON public.auth_verification_token USING btree (expires_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_verification_token_provider_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_verification_token_provider_identity_id" ON public.auth_verification_token USING btree (provider_identity_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_auth_verification_token_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_auth_verification_token_token_hash" ON public.auth_verification_token USING btree (token_hash) WHERE (deleted_at IS NULL);


--
-- Name: IDX_campaign_budget_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_campaign_budget_type" ON public.promotion_campaign_budget USING btree (type);


--
-- Name: IDX_capture_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_capture_deleted_at" ON public.capture USING btree (deleted_at);


--
-- Name: IDX_capture_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_capture_payment_id" ON public.capture USING btree (payment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_address_deleted_at" ON public.cart_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_billing_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_billing_address_id" ON public.cart USING btree (billing_address_id) WHERE ((deleted_at IS NULL) AND (billing_address_id IS NOT NULL));


--
-- Name: IDX_cart_credit_line_reference_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_credit_line_reference_reference_id" ON public.credit_line USING btree (reference, reference_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_currency_code" ON public.cart USING btree (currency_code);


--
-- Name: IDX_cart_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_customer_id" ON public.cart USING btree (customer_id) WHERE ((deleted_at IS NULL) AND (customer_id IS NOT NULL));


--
-- Name: IDX_cart_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_deleted_at" ON public.cart USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-4a39f6c9" ON public.cart_payment_collection USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-71069c16" ON public.order_cart USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_id_-a9d4a70b" ON public.cart_promotion USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_line_item_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_adjustment_deleted_at" ON public.cart_line_item_adjustment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_adjustment_item_id" ON public.cart_line_item_adjustment USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_line_item_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_cart_id" ON public.cart_line_item USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_line_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_deleted_at" ON public.cart_line_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_tax_line_deleted_at" ON public.cart_line_item_tax_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_line_item_tax_line_item_id" ON public.cart_line_item_tax_line USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_region_id" ON public.cart USING btree (region_id) WHERE ((deleted_at IS NULL) AND (region_id IS NOT NULL));


--
-- Name: IDX_cart_sales_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_sales_channel_id" ON public.cart USING btree (sales_channel_id) WHERE ((deleted_at IS NULL) AND (sales_channel_id IS NOT NULL));


--
-- Name: IDX_cart_shipping_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_address_id" ON public.cart USING btree (shipping_address_id) WHERE ((deleted_at IS NULL) AND (shipping_address_id IS NOT NULL));


--
-- Name: IDX_cart_shipping_method_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_deleted_at" ON public.cart_shipping_method_adjustment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_shipping_method_id" ON public.cart_shipping_method_adjustment USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_shipping_method_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_cart_id" ON public.cart_shipping_method USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_shipping_method_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_deleted_at" ON public.cart_shipping_method USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_deleted_at" ON public.cart_shipping_method_tax_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_shipping_method_id" ON public.cart_shipping_method_tax_line USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_category_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_category_handle_unique" ON public.product_category USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_collection_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_collection_handle_unique" ON public.product_collection USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_credit_line_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_credit_line_cart_id" ON public.credit_line USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_credit_line_deleted_at" ON public.credit_line USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_address_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_address_customer_id" ON public.customer_address USING btree (customer_id);


--
-- Name: IDX_customer_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_address_deleted_at" ON public.customer_address USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_address_unique_customer_billing; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_billing" ON public.customer_address USING btree (customer_id) WHERE (is_default_billing = true);


--
-- Name: IDX_customer_address_unique_customer_shipping; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_shipping" ON public.customer_address USING btree (customer_id) WHERE (is_default_shipping = true);


--
-- Name: IDX_customer_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_deleted_at" ON public.customer USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_email_has_account_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_email_has_account_unique" ON public.customer USING btree (email, has_account) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_customer_customer_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_customer_group_id" ON public.customer_group_customer USING btree (customer_group_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_customer_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_customer_id" ON public.customer_group_customer USING btree (customer_id);


--
-- Name: IDX_customer_group_customer_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_customer_deleted_at" ON public.customer_group_customer USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_group_deleted_at" ON public.customer_group USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_customer_group_name_unique" ON public.customer_group USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_customer_id_5cb3a0c0" ON public.customer_account_holder USING btree (customer_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_deleted_at_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-1e5992737" ON public.location_fulfillment_provider USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-31ea43a" ON public.return_fulfillment USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-4a39f6c9" ON public.cart_payment_collection USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-71069c16" ON public.order_cart USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-71518339" ON public.order_promotion USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-85069d44" ON public.invite_rbac_role USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-a9d4a70b" ON public.cart_promotion USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-e88adb96" ON public.location_fulfillment_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_-e8d2543e" ON public.order_fulfillment USING btree (deleted_at);


--
-- Name: IDX_deleted_at_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_17a262437" ON public.product_shipping_profile USING btree (deleted_at);


--
-- Name: IDX_deleted_at_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_17b4c4e35" ON public.product_variant_inventory_item USING btree (deleted_at);


--
-- Name: IDX_deleted_at_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_1c934dab0" ON public.region_payment_provider USING btree (deleted_at);


--
-- Name: IDX_deleted_at_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_20b454295" ON public.product_sales_channel USING btree (deleted_at);


--
-- Name: IDX_deleted_at_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_26d06f470" ON public.sales_channel_stock_location USING btree (deleted_at);


--
-- Name: IDX_deleted_at_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_52b23597" ON public.product_variant_price_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_5cb3a0c0" ON public.customer_account_holder USING btree (deleted_at);


--
-- Name: IDX_deleted_at_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_64ff0c4c" ON public.user_rbac_role USING btree (deleted_at);


--
-- Name: IDX_deleted_at_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_ba32fa9c" ON public.shipping_option_price_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_deleted_at_f42b9949" ON public.order_payment_collection USING btree (deleted_at);


--
-- Name: IDX_fulfillment_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_address_deleted_at" ON public.fulfillment_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_deleted_at" ON public.fulfillment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_id_-31ea43a" ON public.return_fulfillment USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_id_-e8d2543e" ON public.order_fulfillment USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_deleted_at" ON public.fulfillment_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_item_fulfillment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_fulfillment_id" ON public.fulfillment_item USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_item_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_inventory_item_id" ON public.fulfillment_item USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_item_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_item_line_item_id" ON public.fulfillment_item USING btree (line_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_label_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_label_deleted_at" ON public.fulfillment_label USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_label_fulfillment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_label_fulfillment_id" ON public.fulfillment_label USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_location_id" ON public.fulfillment USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_provider_deleted_at" ON public.fulfillment_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_provider_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_provider_id_-1e5992737" ON public.location_fulfillment_provider USING btree (fulfillment_provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_set_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_set_deleted_at" ON public.fulfillment_set USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_set_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_set_id_-e88adb96" ON public.location_fulfillment_set USING btree (fulfillment_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_set_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_fulfillment_set_name_unique" ON public.fulfillment_set USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_fulfillment_shipping_option_id" ON public.fulfillment USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_geo_zone_city; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_city" ON public.geo_zone USING btree (city) WHERE ((deleted_at IS NULL) AND (city IS NOT NULL));


--
-- Name: IDX_geo_zone_country_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_country_code" ON public.geo_zone USING btree (country_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_geo_zone_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_deleted_at" ON public.geo_zone USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_geo_zone_province_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_province_code" ON public.geo_zone USING btree (province_code) WHERE ((deleted_at IS NULL) AND (province_code IS NOT NULL));


--
-- Name: IDX_geo_zone_service_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_geo_zone_service_zone_id" ON public.geo_zone USING btree (service_zone_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (id);


--
-- Name: IDX_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-1e5992737" ON public.location_fulfillment_provider USING btree (id);


--
-- Name: IDX_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-31ea43a" ON public.return_fulfillment USING btree (id);


--
-- Name: IDX_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-4a39f6c9" ON public.cart_payment_collection USING btree (id);


--
-- Name: IDX_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-71069c16" ON public.order_cart USING btree (id);


--
-- Name: IDX_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-71518339" ON public.order_promotion USING btree (id);


--
-- Name: IDX_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-85069d44" ON public.invite_rbac_role USING btree (id);


--
-- Name: IDX_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-a9d4a70b" ON public.cart_promotion USING btree (id);


--
-- Name: IDX_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-e88adb96" ON public.location_fulfillment_set USING btree (id);


--
-- Name: IDX_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_-e8d2543e" ON public.order_fulfillment USING btree (id);


--
-- Name: IDX_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_17a262437" ON public.product_shipping_profile USING btree (id);


--
-- Name: IDX_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (id);


--
-- Name: IDX_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_1c934dab0" ON public.region_payment_provider USING btree (id);


--
-- Name: IDX_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_20b454295" ON public.product_sales_channel USING btree (id);


--
-- Name: IDX_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_26d06f470" ON public.sales_channel_stock_location USING btree (id);


--
-- Name: IDX_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_52b23597" ON public.product_variant_price_set USING btree (id);


--
-- Name: IDX_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_5cb3a0c0" ON public.customer_account_holder USING btree (id);


--
-- Name: IDX_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_64ff0c4c" ON public.user_rbac_role USING btree (id);


--
-- Name: IDX_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_ba32fa9c" ON public.shipping_option_price_set USING btree (id);


--
-- Name: IDX_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_id_f42b9949" ON public.order_payment_collection USING btree (id);


--
-- Name: IDX_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_image_deleted_at" ON public.image USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_image_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_image_product_id" ON public.image USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_item_deleted_at" ON public.inventory_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_inventory_item_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_item_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_item_sku; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_inventory_item_sku" ON public.inventory_item USING btree (sku) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_deleted_at" ON public.inventory_level USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_inventory_level_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_inventory_item_id" ON public.inventory_level USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_inventory_level_location_id" ON public.inventory_level USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_location_id_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_inventory_level_location_id_inventory_item_id" ON public.inventory_level USING btree (inventory_item_id, location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_invite_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_deleted_at" ON public.invite USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_invite_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_invite_email_unique" ON public.invite USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: IDX_invite_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_id_-85069d44" ON public.invite_rbac_role USING btree (invite_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_invite_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_invite_token" ON public.invite USING btree (token) WHERE (deleted_at IS NULL);


--
-- Name: IDX_line_item_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_adjustment_promotion_id" ON public.cart_line_item_adjustment USING btree (promotion_id) WHERE ((deleted_at IS NULL) AND (promotion_id IS NOT NULL));


--
-- Name: IDX_line_item_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_product_id" ON public.cart_line_item USING btree (product_id) WHERE ((deleted_at IS NULL) AND (product_id IS NOT NULL));


--
-- Name: IDX_line_item_product_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_product_type_id" ON public.order_line_item USING btree (product_type_id) WHERE ((deleted_at IS NULL) AND (product_type_id IS NOT NULL));


--
-- Name: IDX_line_item_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_tax_line_tax_rate_id" ON public.cart_line_item_tax_line USING btree (tax_rate_id) WHERE ((deleted_at IS NULL) AND (tax_rate_id IS NOT NULL));


--
-- Name: IDX_line_item_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_line_item_variant_id" ON public.cart_line_item USING btree (variant_id) WHERE ((deleted_at IS NULL) AND (variant_id IS NOT NULL));


--
-- Name: IDX_notification_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_deleted_at" ON public.notification USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_idempotency_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_notification_idempotency_key_unique" ON public.notification USING btree (idempotency_key) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_provider_deleted_at" ON public.notification_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_provider_id" ON public.notification USING btree (provider_id);


--
-- Name: IDX_notification_receiver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_notification_receiver_id" ON public.notification USING btree (receiver_id);


--
-- Name: IDX_option_product_id_title_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_option_product_id_title_unique" ON public.product_option USING btree (product_id, title) WHERE (deleted_at IS NULL);


--
-- Name: IDX_option_value_option_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_option_value_option_id_unique" ON public.product_option_value USING btree (option_id, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_address_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_address_customer_id" ON public.order_address USING btree (customer_id);


--
-- Name: IDX_order_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_address_deleted_at" ON public.order_address USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_billing_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_billing_address_id" ON public."order" USING btree (billing_address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_action_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_claim_id" ON public.order_change_action USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_action_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_deleted_at" ON public.order_change_action USING btree (deleted_at);


--
-- Name: IDX_order_change_action_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_exchange_id" ON public.order_change_action USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_action_order_change_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_order_change_id" ON public.order_change_action USING btree (order_change_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_action_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_order_id" ON public.order_change_action USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_action_ordering; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_ordering" ON public.order_change_action USING btree (ordering) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_action_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_action_return_id" ON public.order_change_action USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_change_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_change_type" ON public.order_change USING btree (change_type);


--
-- Name: IDX_order_change_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_claim_id" ON public.order_change USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_deleted_at" ON public.order_change USING btree (deleted_at);


--
-- Name: IDX_order_change_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_exchange_id" ON public.order_change USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_order_id" ON public.order_change USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_order_id_version" ON public.order_change USING btree (order_id, version);


--
-- Name: IDX_order_change_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_return_id" ON public.order_change USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_status" ON public.order_change USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_change_version" ON public.order_change USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_deleted_at" ON public.order_claim USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_display_id" ON public.order_claim USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_claim_id" ON public.order_claim_item USING btree (claim_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_deleted_at" ON public.order_claim_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_image_claim_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_image_claim_item_id" ON public.order_claim_item_image USING btree (claim_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_image_deleted_at" ON public.order_claim_item_image USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_claim_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_item_item_id" ON public.order_claim_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_order_id" ON public.order_claim USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_claim_return_id" ON public.order_claim USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_deleted_at" ON public.order_credit_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_credit_line_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_order_id" ON public.order_credit_line USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_credit_line_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_credit_line_order_id_version" ON public.order_credit_line USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_currency_code" ON public."order" USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_custom_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_order_custom_display_id" ON public."order" USING btree (custom_display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_customer_id" ON public."order" USING btree (customer_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_deleted_at" ON public."order" USING btree (deleted_at);


--
-- Name: IDX_order_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_display_id" ON public."order" USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_deleted_at" ON public.order_exchange USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_display_id" ON public.order_exchange USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_deleted_at" ON public.order_exchange_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_exchange_id" ON public.order_exchange_item USING btree (exchange_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_item_item_id" ON public.order_exchange_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_order_id" ON public.order_exchange USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_exchange_return_id" ON public.order_exchange USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_id_-71069c16; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-71069c16" ON public.order_cart USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-71518339" ON public.order_promotion USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_id_-e8d2543e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_-e8d2543e" ON public.order_fulfillment USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_id_f42b9949" ON public.order_payment_collection USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_is_draft_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_is_draft_order" ON public."order" USING btree (is_draft_order) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_deleted_at" ON public.order_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_item_id" ON public.order_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_order_id" ON public.order_item USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_item_order_id_version" ON public.order_item USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_adjustment_item_id" ON public.order_line_item_adjustment USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_product_id" ON public.order_line_item USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_tax_line_item_id" ON public.order_line_item_tax_line USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_line_item_variant_id" ON public.order_line_item USING btree (variant_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_region_id" ON public."order" USING btree (region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_sales_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_sales_channel_id" ON public."order" USING btree (sales_channel_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_address_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_address_id" ON public."order" USING btree (shipping_address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_claim_id" ON public.order_shipping USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_shipping_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_deleted_at" ON public.order_shipping USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_shipping_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_exchange_id" ON public.order_shipping USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_shipping_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_item_id" ON public.order_shipping USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_adjustment_shipping_method_id" ON public.order_shipping_method_adjustment USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_adjustment_version_shipping_method; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_order_shipping_method_adjustment_version_shipping_method" ON public.order_shipping_method_adjustment USING btree (version, shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_shipping_option_id" ON public.order_shipping_method USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_method_tax_line_shipping_method_id" ON public.order_shipping_method_tax_line USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_order_id" ON public.order_shipping USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_order_id_version" ON public.order_shipping USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_return_id" ON public.order_shipping USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_shipping_shipping_method_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_shipping_shipping_method_id" ON public.order_shipping USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_summary_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_summary_deleted_at" ON public.order_summary USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_summary_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_summary_order_id_version" ON public.order_summary USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_claim_id" ON public.order_transaction USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_transaction_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_currency_code" ON public.order_transaction USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_exchange_id" ON public.order_transaction USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_transaction_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_order_id" ON public.order_transaction USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_order_id_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_order_id_version" ON public.order_transaction USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_reference_id" ON public.order_transaction USING btree (reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_order_transaction_return_id" ON public.order_transaction USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_payment_collection_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_deleted_at" ON public.payment_collection USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_payment_collection_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_id_-4a39f6c9" ON public.cart_payment_collection USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_collection_id_f42b9949; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_collection_id_f42b9949" ON public.order_payment_collection USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_deleted_at" ON public.payment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_payment_payment_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_payment_collection_id" ON public.payment USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_payment_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_payment_session_id" ON public.payment USING btree (payment_session_id);


--
-- Name: IDX_payment_payment_session_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_payment_payment_session_id_unique" ON public.payment USING btree (payment_session_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_deleted_at" ON public.payment_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_id" ON public.payment USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_provider_id_1c934dab0" ON public.region_payment_provider USING btree (payment_provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_session_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_session_deleted_at" ON public.payment_session USING btree (deleted_at);


--
-- Name: IDX_payment_session_payment_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_payment_session_payment_collection_id" ON public.payment_session USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_currency_code" ON public.price USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_deleted_at" ON public.price USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_deleted_at" ON public.price_list USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_id_status_starts_at_ends_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_id_status_starts_at_ends_at" ON public.price_list USING btree (id, status, starts_at, ends_at) WHERE ((deleted_at IS NULL) AND (status = 'active'::text));


--
-- Name: IDX_price_list_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_attribute" ON public.price_list_rule USING btree (attribute) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_list_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_deleted_at" ON public.price_list_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_rule_price_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_price_list_id" ON public.price_list_rule USING btree (price_list_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_rule_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_list_rule_value" ON public.price_list_rule USING gin (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_preference_attribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_price_preference_attribute_value" ON public.price_preference USING btree (attribute, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_preference_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_preference_deleted_at" ON public.price_preference USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_price_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_price_list_id" ON public.price USING btree (price_list_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_price_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_price_set_id" ON public.price USING btree (price_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute" ON public.price_rule USING btree (attribute) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_attribute_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute_value" ON public.price_rule USING btree (attribute, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_attribute_value_price_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_attribute_value_price_id" ON public.price_rule USING btree (attribute, value, price_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_deleted_at" ON public.price_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_rule_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_operator" ON public.price_rule USING btree (operator);


--
-- Name: IDX_price_rule_operator_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_operator_value" ON public.price_rule USING btree (operator, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_price_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_rule_price_id" ON public.price_rule USING btree (price_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_price_id_attribute_operator_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_price_rule_price_id_attribute_operator_unique" ON public.price_rule USING btree (price_id, attribute, operator) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_set_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_deleted_at" ON public.price_set USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_set_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_id_52b23597" ON public.product_variant_price_set USING btree (price_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_set_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_price_set_id_ba32fa9c" ON public.shipping_option_price_set USING btree (price_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_category_parent_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_category_parent_category_id" ON public.product_category USING btree (parent_category_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_category_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_category_path" ON public.product_category USING btree (mpath) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_collection_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_collection_deleted_at" ON public.product_collection USING btree (deleted_at);


--
-- Name: IDX_product_collection_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_collection_id" ON public.product USING btree (collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_deleted_at" ON public.product USING btree (deleted_at);


--
-- Name: IDX_product_handle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_handle_unique" ON public.product USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_id_17a262437" ON public.product_shipping_profile USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_id_20b454295" ON public.product_sales_channel USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_image_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_rank" ON public.image USING btree (rank) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_image_rank_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_rank_product_id" ON public.image USING btree (rank, product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_image_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_url" ON public.image USING btree (url) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_image_url_rank_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_image_url_rank_product_id" ON public.image USING btree (url, rank, product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_option_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_deleted_at" ON public.product_option USING btree (deleted_at);


--
-- Name: IDX_product_option_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_product_id" ON public.product_option USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_option_value_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_value_deleted_at" ON public.product_option_value USING btree (deleted_at);


--
-- Name: IDX_product_option_value_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_option_value_option_id" ON public.product_option_value USING btree (option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_status" ON public.product USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_tag_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_tag_deleted_at" ON public.product_tag USING btree (deleted_at);


--
-- Name: IDX_product_type_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_type_deleted_at" ON public.product_type USING btree (deleted_at);


--
-- Name: IDX_product_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_type_id" ON public.product USING btree (type_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_barcode_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_barcode_unique" ON public.product_variant USING btree (barcode) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_deleted_at" ON public.product_variant USING btree (deleted_at);


--
-- Name: IDX_product_variant_ean_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_ean_unique" ON public.product_variant USING btree (ean) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_id_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_id_product_id" ON public.product_variant USING btree (id, product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_id" ON public.product_variant USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_product_image_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_deleted_at" ON public.product_variant_product_image USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_product_image_image_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_image_id" ON public.product_variant_product_image USING btree (image_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_product_image_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_product_variant_product_image_variant_id" ON public.product_variant_product_image USING btree (variant_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_sku_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_sku_unique" ON public.product_variant USING btree (sku) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_upc_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_product_variant_upc_unique" ON public.product_variant USING btree (upc) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_application_method_currency_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_application_method_currency_code" ON public.promotion_application_method USING btree (currency_code) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_promotion_application_method_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_application_method_deleted_at" ON public.promotion_application_method USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_application_method_promotion_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_application_method_promotion_id_unique" ON public.promotion_application_method USING btree (promotion_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_campaign_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_budget_campaign_id_unique" ON public.promotion_campaign_budget USING btree (campaign_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_deleted_at" ON public.promotion_campaign_budget USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_attribute_value_budget_id_u; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_budget_usage_attribute_value_budget_id_u" ON public.promotion_campaign_budget_usage USING btree (attribute_value, budget_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_budget_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_usage_budget_id" ON public.promotion_campaign_budget_usage USING btree (budget_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_usage_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_budget_usage_deleted_at" ON public.promotion_campaign_budget_usage USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_campaign_identifier_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_campaign_identifier_unique" ON public.promotion_campaign USING btree (campaign_identifier) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_deleted_at" ON public.promotion_campaign USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_campaign_id" ON public.promotion USING btree (campaign_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_deleted_at" ON public.promotion USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_id_-71518339; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_id_-71518339" ON public.order_promotion USING btree (promotion_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_id_-a9d4a70b" ON public.cart_promotion USING btree (promotion_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_is_automatic; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_is_automatic" ON public.promotion USING btree (is_automatic) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_attribute; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute" ON public.promotion_rule USING btree (attribute);


--
-- Name: IDX_promotion_rule_attribute_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute_operator" ON public.promotion_rule USING btree (attribute, operator) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_attribute_operator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_attribute_operator_id" ON public.promotion_rule USING btree (operator, attribute, id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_deleted_at" ON public.promotion_rule USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_operator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_operator" ON public.promotion_rule USING btree (operator);


--
-- Name: IDX_promotion_rule_value_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_deleted_at" ON public.promotion_rule_value USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_value_promotion_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_promotion_rule_id" ON public.promotion_rule_value USING btree (promotion_rule_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_value_rule_id_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_rule_id_value" ON public.promotion_rule_value USING btree (promotion_rule_id, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_value_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_rule_value_value" ON public.promotion_rule_value USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_status" ON public.promotion USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_promotion_type" ON public.promotion USING btree (type);


--
-- Name: IDX_property_label_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_property_label_deleted_at" ON public.property_label USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_property_label_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_property_label_entity" ON public.property_label USING btree (entity) WHERE (deleted_at IS NULL);


--
-- Name: IDX_property_label_entity_property_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_property_label_entity_property_unique" ON public.property_label USING btree (entity, property) WHERE (deleted_at IS NULL);


--
-- Name: IDX_provider_identity_auth_identity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_provider_identity_auth_identity_id" ON public.provider_identity USING btree (auth_identity_id);


--
-- Name: IDX_provider_identity_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_provider_identity_deleted_at" ON public.provider_identity USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_provider_identity_provider_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_provider_identity_provider_entity_id" ON public.provider_identity USING btree (entity_id, provider);


--
-- Name: IDX_publishable_key_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_publishable_key_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (publishable_key_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_rbac_role_id_-85069d44; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_rbac_role_id_-85069d44" ON public.invite_rbac_role USING btree (rbac_role_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_rbac_role_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_rbac_role_id_64ff0c4c" ON public.user_rbac_role USING btree (rbac_role_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_refund_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_deleted_at" ON public.refund USING btree (deleted_at);


--
-- Name: IDX_refund_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_payment_id" ON public.refund USING btree (payment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_refund_reason_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_reason_deleted_at" ON public.refund_reason USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_refund_refund_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_refund_refund_reason_id" ON public.refund USING btree (refund_reason_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_country_deleted_at" ON public.region_country USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_country_region_id" ON public.region_country USING btree (region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_region_id_iso_2_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_region_country_region_id_iso_2_unique" ON public.region_country USING btree (region_id, iso_2);


--
-- Name: IDX_region_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_deleted_at" ON public.region USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_region_id_1c934dab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_region_id_1c934dab0" ON public.region_payment_provider USING btree (region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_reservation_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_deleted_at" ON public.reservation_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_reservation_item_inventory_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_inventory_item_id" ON public.reservation_item USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_reservation_item_line_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_line_item_id" ON public.reservation_item USING btree (line_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_reservation_item_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_reservation_item_location_id" ON public.reservation_item USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_claim_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_claim_id" ON public.return USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_return_display_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_display_id" ON public.return USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_exchange_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_exchange_id" ON public.return USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_return_id_-31ea43a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_id_-31ea43a" ON public.return_fulfillment USING btree (return_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_deleted_at" ON public.return_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_item_id" ON public.return_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_reason_id" ON public.return_item USING btree (reason_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_return_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_item_return_id" ON public.return_item USING btree (return_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_order_id" ON public.return USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_reason_parent_return_reason_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_reason_parent_return_reason_id" ON public.return_reason USING btree (parent_return_reason_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_reason_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_return_reason_value" ON public.return_reason USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_sales_channel_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_deleted_at" ON public.sales_channel USING btree (deleted_at);


--
-- Name: IDX_sales_channel_id_-1d67bae40; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (sales_channel_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_sales_channel_id_20b454295; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_20b454295" ON public.product_sales_channel USING btree (sales_channel_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_sales_channel_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_sales_channel_id_26d06f470" ON public.sales_channel_stock_location USING btree (sales_channel_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_service_zone_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_service_zone_deleted_at" ON public.service_zone USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_service_zone_fulfillment_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_service_zone_fulfillment_set_id" ON public.service_zone USING btree (fulfillment_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_service_zone_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_service_zone_name_unique" ON public.service_zone USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_method_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_adjustment_promotion_id" ON public.cart_shipping_method_adjustment USING btree (promotion_id) WHERE ((deleted_at IS NULL) AND (promotion_id IS NOT NULL));


--
-- Name: IDX_shipping_method_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_option_id" ON public.cart_shipping_method USING btree (shipping_option_id) WHERE ((deleted_at IS NULL) AND (shipping_option_id IS NOT NULL));


--
-- Name: IDX_shipping_method_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_method_tax_line_tax_rate_id" ON public.cart_shipping_method_tax_line USING btree (tax_rate_id) WHERE ((deleted_at IS NULL) AND (tax_rate_id IS NOT NULL));


--
-- Name: IDX_shipping_option_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_deleted_at" ON public.shipping_option USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_option_id_ba32fa9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_id_ba32fa9c" ON public.shipping_option_price_set USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_provider_id" ON public.shipping_option USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_rule_deleted_at" ON public.shipping_option_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_option_rule_shipping_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_rule_shipping_option_id" ON public.shipping_option_rule USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_service_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_service_zone_id" ON public.shipping_option USING btree (service_zone_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_shipping_option_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_shipping_option_type_id" ON public.shipping_option USING btree (shipping_option_type_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_shipping_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_shipping_profile_id" ON public.shipping_option USING btree (shipping_profile_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_type_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_option_type_deleted_at" ON public.shipping_option_type USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_profile_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_profile_deleted_at" ON public.shipping_profile USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_profile_id_17a262437; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_shipping_profile_id_17a262437" ON public.product_shipping_profile USING btree (shipping_profile_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_profile_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_shipping_profile_name_unique" ON public.shipping_profile USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_single_default_region; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_single_default_region" ON public.tax_rate USING btree (tax_region_id) WHERE ((is_default = true) AND (deleted_at IS NULL));


--
-- Name: IDX_stock_location_address_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_address_deleted_at" ON public.stock_location_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_stock_location_address_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_stock_location_address_id_unique" ON public.stock_location USING btree (address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_stock_location_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_deleted_at" ON public.stock_location USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_stock_location_id_-1e5992737; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_-1e5992737" ON public.location_fulfillment_provider USING btree (stock_location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_stock_location_id_-e88adb96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_-e88adb96" ON public.location_fulfillment_set USING btree (stock_location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_stock_location_id_26d06f470; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_stock_location_id_26d06f470" ON public.sales_channel_stock_location USING btree (stock_location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_store_currency_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_currency_deleted_at" ON public.store_currency USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_store_currency_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_currency_store_id" ON public.store_currency USING btree (store_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_store_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_deleted_at" ON public.store USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_store_locale_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_locale_deleted_at" ON public.store_locale USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_store_locale_store_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_store_locale_store_id" ON public.store_locale USING btree (store_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tag_value_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tag_value_unique" ON public.product_tag USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_provider_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_provider_deleted_at" ON public.tax_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_deleted_at" ON public.tax_rate USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_deleted_at" ON public.tax_rate_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_reference_id" ON public.tax_rate_rule USING btree (reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_rule_tax_rate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_rule_tax_rate_id" ON public.tax_rate_rule USING btree (tax_rate_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_rule_unique_rate_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_rate_rule_unique_rate_reference" ON public.tax_rate_rule USING btree (tax_rate_id, reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_tax_region_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_rate_tax_region_id" ON public.tax_rate USING btree (tax_region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_region_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_deleted_at" ON public.tax_region USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_region_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_parent_id" ON public.tax_region USING btree (parent_id);


--
-- Name: IDX_tax_region_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_tax_region_provider_id" ON public.tax_region USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_region_unique_country_nullable_province; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_nullable_province" ON public.tax_region USING btree (country_code) WHERE ((province_code IS NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_tax_region_unique_country_province; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_province" ON public.tax_region USING btree (country_code, province_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_type_value_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_type_value_unique" ON public.product_type USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_unique_promotion_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_unique_promotion_code" ON public.promotion USING btree (code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_deleted_at" ON public."user" USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_user_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_user_email_unique" ON public."user" USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_id_64ff0c4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_id_64ff0c4c" ON public.user_rbac_role USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_preference_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_preference_deleted_at" ON public.user_preference USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_preference_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_user_preference_user_id" ON public.user_preference USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_preference_user_id_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_user_preference_user_id_key_unique" ON public.user_preference USING btree (user_id, key) WHERE (deleted_at IS NULL);


--
-- Name: IDX_variant_id_17b4c4e35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_variant_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (variant_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_variant_id_52b23597; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_variant_id_52b23597" ON public.product_variant_price_set USING btree (variant_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_view_configuration_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_deleted_at" ON public.view_configuration USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_view_configuration_entity_is_system_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_entity_is_system_default" ON public.view_configuration USING btree (entity, is_system_default) WHERE (deleted_at IS NULL);


--
-- Name: IDX_view_configuration_entity_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_entity_user_id" ON public.view_configuration USING btree (entity, user_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_view_configuration_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_view_configuration_user_id" ON public.view_configuration USING btree (user_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_deleted_at" ON public.workflow_execution USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_id" ON public.workflow_execution USING btree (id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_retention_time_updated_at_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_retention_time_updated_at_state" ON public.workflow_execution USING btree (retention_time, updated_at, state) WHERE ((deleted_at IS NULL) AND (retention_time IS NOT NULL));


--
-- Name: IDX_workflow_execution_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_run_id" ON public.workflow_execution USING btree (run_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_state" ON public.workflow_execution USING btree (state) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_state_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_state_updated_at" ON public.workflow_execution USING btree (state, updated_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_transaction_id" ON public.workflow_execution USING btree (transaction_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_updated_at_retention_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_updated_at_retention_time" ON public.workflow_execution USING btree (updated_at, retention_time) WHERE ((deleted_at IS NULL) AND (retention_time IS NOT NULL) AND ((state)::text = ANY ((ARRAY['done'::character varying, 'failed'::character varying, 'reverted'::character varying])::text[])));


--
-- Name: IDX_workflow_execution_workflow_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_workflow_id" ON public.workflow_execution USING btree (workflow_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id_transaction_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_workflow_execution_workflow_id_transaction_id" ON public.workflow_execution USING btree (workflow_id, transaction_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id_transaction_id_run_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_workflow_execution_workflow_id_transaction_id_run_id_unique" ON public.workflow_execution USING btree (workflow_id, transaction_id, run_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_script_name_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_script_name_unique ON public.script_migrations USING btree (script_name);


--
-- Name: tax_rate_rule FK_tax_rate_rule_tax_rate_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate_rule
    ADD CONSTRAINT "FK_tax_rate_rule_tax_rate_id" FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rate(id) ON DELETE CASCADE;


--
-- Name: tax_rate FK_tax_rate_tax_region_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_rate
    ADD CONSTRAINT "FK_tax_rate_tax_region_id" FOREIGN KEY (tax_region_id) REFERENCES public.tax_region(id) ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT "FK_tax_region_parent_id" FOREIGN KEY (parent_id) REFERENCES public.tax_region(id) ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_provider_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT "FK_tax_region_provider_id" FOREIGN KEY (provider_id) REFERENCES public.tax_provider(id) ON DELETE SET NULL;


--
-- Name: application_method_buy_rules application_method_buy_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_application_method_id_foreign FOREIGN KEY (application_method_id) REFERENCES public.promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_buy_rules application_method_buy_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_application_method_id_foreign FOREIGN KEY (application_method_id) REFERENCES public.promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auth_mfa_factor auth_mfa_factor_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_mfa_factor
    ADD CONSTRAINT auth_mfa_factor_auth_identity_id_foreign FOREIGN KEY (auth_identity_id) REFERENCES public.auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auth_mfa_recovery_code auth_mfa_recovery_code_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_mfa_recovery_code
    ADD CONSTRAINT auth_mfa_recovery_code_auth_identity_id_foreign FOREIGN KEY (auth_identity_id) REFERENCES public.auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auth_verification_token auth_verification_token_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_verification_token
    ADD CONSTRAINT auth_verification_token_auth_identity_id_foreign FOREIGN KEY (auth_identity_id) REFERENCES public.auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: auth_verification_token auth_verification_token_provider_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_verification_token
    ADD CONSTRAINT auth_verification_token_provider_identity_id_foreign FOREIGN KEY (provider_identity_id) REFERENCES public.provider_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: capture capture_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capture
    ADD CONSTRAINT capture_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_billing_address_id_foreign FOREIGN KEY (billing_address_id) REFERENCES public.cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item_adjustment
    ADD CONSTRAINT cart_line_item_adjustment_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item cart_line_item_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item
    ADD CONSTRAINT cart_line_item_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_line_item_tax_line
    ADD CONSTRAINT cart_line_item_tax_line_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_shipping_address_id_foreign FOREIGN KEY (shipping_address_id) REFERENCES public.cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method_adjustment
    ADD CONSTRAINT cart_shipping_method_adjustment_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method cart_shipping_method_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method
    ADD CONSTRAINT cart_shipping_method_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_shipping_method_tax_line
    ADD CONSTRAINT cart_shipping_method_tax_line_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_line credit_line_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_line
    ADD CONSTRAINT credit_line_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE;


--
-- Name: customer_address customer_address_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_address
    ADD CONSTRAINT customer_address_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_customer_group_id_foreign FOREIGN KEY (customer_group_id) REFERENCES public.customer_group(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_delivery_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_delivery_address_id_foreign FOREIGN KEY (delivery_address_id) REFERENCES public.fulfillment_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment_item fulfillment_item_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_item
    ADD CONSTRAINT fulfillment_item_fulfillment_id_foreign FOREIGN KEY (fulfillment_id) REFERENCES public.fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment_label fulfillment_label_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment_label
    ADD CONSTRAINT fulfillment_label_fulfillment_id_foreign FOREIGN KEY (fulfillment_id) REFERENCES public.fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment fulfillment_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_shipping_option_id_foreign FOREIGN KEY (shipping_option_id) REFERENCES public.shipping_option(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: geo_zone geo_zone_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.geo_zone
    ADD CONSTRAINT geo_zone_service_zone_id_foreign FOREIGN KEY (service_zone_id) REFERENCES public.service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: image image_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_level inventory_level_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_level
    ADD CONSTRAINT inventory_level_inventory_item_id_foreign FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification notification_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.notification_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order order_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_billing_address_id_foreign FOREIGN KEY (billing_address_id) REFERENCES public.order_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order_change_action order_change_action_order_change_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_change_action
    ADD CONSTRAINT order_change_action_order_change_id_foreign FOREIGN KEY (order_change_id) REFERENCES public.order_change(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_change order_change_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_change
    ADD CONSTRAINT order_change_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_credit_line order_credit_line_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_credit_line
    ADD CONSTRAINT order_credit_line_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_adjustment order_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item_adjustment
    ADD CONSTRAINT order_line_item_adjustment_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_tax_line order_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item_tax_line
    ADD CONSTRAINT order_line_item_tax_line_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item order_line_item_totals_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_line_item
    ADD CONSTRAINT order_line_item_totals_id_foreign FOREIGN KEY (totals_id) REFERENCES public.order_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order order_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_shipping_address_id_foreign FOREIGN KEY (shipping_address_id) REFERENCES public.order_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping_method_adjustment
    ADD CONSTRAINT order_shipping_method_adjustment_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping_method_tax_line
    ADD CONSTRAINT order_shipping_method_tax_line_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping order_shipping_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_shipping
    ADD CONSTRAINT order_shipping_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_summary order_summary_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_summary
    ADD CONSTRAINT order_summary_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_transaction order_transaction_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_transaction
    ADD CONSTRAINT order_transaction_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_col_aa276_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_payment_col_aa276_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_pro_2d555_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_payment_pro_2d555_foreign FOREIGN KEY (payment_provider_id) REFERENCES public.payment_provider(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment payment_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_payment_collection_id_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_session payment_session_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_session
    ADD CONSTRAINT payment_session_payment_collection_id_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_list_rule price_list_rule_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_list_rule
    ADD CONSTRAINT price_list_rule_price_list_id_foreign FOREIGN KEY (price_list_id) REFERENCES public.price_list(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_price_list_id_foreign FOREIGN KEY (price_list_id) REFERENCES public.price_list(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_price_set_id_foreign FOREIGN KEY (price_set_id) REFERENCES public.price_set(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_rule price_rule_price_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_rule
    ADD CONSTRAINT price_rule_price_id_foreign FOREIGN KEY (price_id) REFERENCES public.price(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category product_category_parent_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_parent_category_id_foreign FOREIGN KEY (parent_category_id) REFERENCES public.product_category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_product_category_id_foreign FOREIGN KEY (product_category_id) REFERENCES public.product_category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_collection_id_foreign FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_option product_option_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_option
    ADD CONSTRAINT product_option_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_option_value product_option_value_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_option_value
    ADD CONSTRAINT product_option_value_option_id_foreign FOREIGN KEY (option_id) REFERENCES public.product_option(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_tag_id_foreign FOREIGN KEY (product_tag_id) REFERENCES public.product_tag(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_type_id_foreign FOREIGN KEY (type_id) REFERENCES public.product_type(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_variant_option product_variant_option_option_value_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_option_value_id_foreign FOREIGN KEY (option_value_id) REFERENCES public.product_option_value(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant_option product_variant_option_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant product_variant_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant
    ADD CONSTRAINT product_variant_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant_product_image product_variant_product_image_image_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_product_image
    ADD CONSTRAINT product_variant_product_image_image_id_foreign FOREIGN KEY (image_id) REFERENCES public.image(id) ON DELETE CASCADE;


--
-- Name: promotion_application_method promotion_application_method_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_application_method
    ADD CONSTRAINT promotion_application_method_promotion_id_foreign FOREIGN KEY (promotion_id) REFERENCES public.promotion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_campaign_budget promotion_campaign_budget_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_campaign_budget
    ADD CONSTRAINT promotion_campaign_budget_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.promotion_campaign(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_campaign_budget_usage promotion_campaign_budget_usage_budget_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_campaign_budget_usage
    ADD CONSTRAINT promotion_campaign_budget_usage_budget_id_foreign FOREIGN KEY (budget_id) REFERENCES public.promotion_campaign_budget(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion promotion_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT promotion_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.promotion_campaign(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_promotion_id_foreign FOREIGN KEY (promotion_id) REFERENCES public.promotion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_rule_value promotion_rule_value_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promotion_rule_value
    ADD CONSTRAINT promotion_rule_value_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: provider_identity provider_identity_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_identity
    ADD CONSTRAINT provider_identity_auth_identity_id_foreign FOREIGN KEY (auth_identity_id) REFERENCES public.auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refund refund_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund
    ADD CONSTRAINT refund_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: region_country region_country_region_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region_country
    ADD CONSTRAINT region_country_region_id_foreign FOREIGN KEY (region_id) REFERENCES public.region(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reservation_item reservation_item_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reservation_item
    ADD CONSTRAINT reservation_item_inventory_item_id_foreign FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: return_reason return_reason_parent_return_reason_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.return_reason
    ADD CONSTRAINT return_reason_parent_return_reason_id_foreign FOREIGN KEY (parent_return_reason_id) REFERENCES public.return_reason(id);


--
-- Name: service_zone service_zone_fulfillment_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_zone
    ADD CONSTRAINT service_zone_fulfillment_set_id_foreign FOREIGN KEY (fulfillment_set_id) REFERENCES public.fulfillment_set(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipping_option_rule shipping_option_rule_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option_rule
    ADD CONSTRAINT shipping_option_rule_shipping_option_id_foreign FOREIGN KEY (shipping_option_id) REFERENCES public.shipping_option(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_service_zone_id_foreign FOREIGN KEY (service_zone_id) REFERENCES public.service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_option_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_shipping_option_type_id_foreign FOREIGN KEY (shipping_option_type_id) REFERENCES public.shipping_option_type(id) ON UPDATE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_profile_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_shipping_profile_id_foreign FOREIGN KEY (shipping_profile_id) REFERENCES public.shipping_profile(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_location stock_location_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_location
    ADD CONSTRAINT stock_location_address_id_foreign FOREIGN KEY (address_id) REFERENCES public.stock_location_address(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_currency store_currency_store_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_currency
    ADD CONSTRAINT store_currency_store_id_foreign FOREIGN KEY (store_id) REFERENCES public.store(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_locale store_locale_store_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_locale
    ADD CONSTRAINT store_locale_store_id_foreign FOREIGN KEY (store_id) REFERENCES public.store(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict NUnk8fbzesly8BsJmAuF97TbMc8WRScrYhWwXv4eFLzfsmSubEiYPXpFHoaBYyJ

